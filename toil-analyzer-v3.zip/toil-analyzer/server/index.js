#!/usr/bin/env node
/* Toil Analyzer local server — `npm start`, then open http://localhost:7077
 * Zero dependencies. Binds to 127.0.0.1 only: this is a personal cockpit over your clone, not a hosted app. */
'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), url = require('url');
const core = require('../lib/core');
const repo = require('../lib/repo');
const servicenow = require('../lib/servicenow');
const dynatrace = require('../lib/dynatrace');
const jira = require('../lib/jira');

const ROOT = repo.ROOT;
const PORT = +(process.env.PORT || 7077);
const HOST = process.env.HOST || '127.0.0.1';
loadDotEnv();

function loadDotEnv() {
  const f = path.join(ROOT, '.env');
  if (!fs.existsSync(f)) return;
  for (const line of fs.readFileSync(f, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/); if (!m || line.trim().startsWith('#')) continue;
    if (process.env[m[1]] == null) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

const routes = [];
const route = (method, pattern, handler) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:([a-z]+)/g, '(?<$1>[^/]+)') + '$'), handler });
const json = (res, code, body) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(body)); };
const readBody = req => new Promise((resolve, reject) => { let b = ''; req.on('data', d => { b += d; if (b.length > 50e6) reject(new Error('body too large')); }); req.on('end', () => { try { resolve(b ? JSON.parse(b) : {}); } catch (e) { reject(new Error('invalid JSON body')); } }); });

// ---------- status & config ----------
route('GET', '/api/status', async () => ({
  mode: 'connected', version: core.VERSION, root: ROOT, git: repo.gitInfo(), node: process.version,
  claude: { bin: repo.claudeBin() }, glab: !!repo.which('glab'),
  env: { servicenow: !!process.env.SN_INSTANCE && !!(process.env.SN_TOKEN || (process.env.SN_USER && process.env.SN_PASS)), dynatrace: !!process.env.DT_URL && !!process.env.DT_TOKEN, gitlabToken: !!process.env.GITLAB_TOKEN, jira: !!process.env.JIRA_URL && !!process.env.JIRA_TOKEN },
  teams: repo.listTeams().map(t => ({ id: t.id, name: t.name }))
}));
route('GET', '/api/teams', async () => repo.listTeams());
route('GET', '/api/team/:id', async (req, res, p) => repo.readTeam(p.id) || err(404, 'team not found'));
route('PUT', '/api/team/:id', async (req, res, p) => { const team = await readBody(req); if (team.id !== p.id) throw err(400, 'id mismatch'); repo.writeTeam(team); return { ok: true }; });
route('POST', '/api/teams/onboard', async req => {
  const b = await readBody(req), t = b.team;
  if (!t || typeof t !== 'object' || !/^[a-z0-9-]+$/.test(String(t.id || ''))) throw err(400, 'Team id must be lowercase letters, digits and dashes.');
  if (!t.name) throw err(400, 'Team name is required.');
  if (repo.readTeam(t.id)) throw err(409, `Team '${t.id}' already exists on this branch.`);
  if (!((t.servicenow || {}).assignmentGroups || []).length) throw err(400, 'Pick at least one assignment group.');
  const clash = core.ownershipMap(repo.listTeams().concat([t])).conflicts.filter(c => c.teams.includes(t.id));
  if (clash.length) throw err(409, 'Already owned by another team: ' + clash.map(c => `${c.group} (${c.teams.filter(x => x !== t.id).join(', ')})`).join('; '));
  return repo.proposeTeam(t, { openMr: !!b.openMr, codeowner: b.codeowner });
});
route('GET', '/api/signatures', async () => repo.loadCatalog());
route('POST', '/api/signatures/propose', async req => { const b = await readBody(req); if (!b.signature || !b.signature.id) throw err(400, 'signature required'); return repo.proposeSignature(b.signature, { openMr: !!b.openMr }); });

// ---------- data ----------
route('GET', '/api/data', async (req, res, p, q) => repo.listData(q.team));
route('GET', '/api/data/:file', async (req, res, p) => {
  const f = path.join(ROOT, 'data', path.basename(p.file));
  if (!fs.existsSync(f)) throw err(404, 'file not found');
  res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8' }); res.end(fs.readFileSync(f)); return null;
});
route('POST', '/api/pull', async req => {
  const b = await readBody(req); const team = repo.readTeam(b.team); if (!team) throw err(404, 'team not found');
  const r = await servicenow.pullIncidents(team, { days: b.days });
  const name = `${team.id}-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}.csv`;
  fs.mkdirSync(path.join(ROOT, 'data'), { recursive: true }); fs.writeFileSync(path.join(ROOT, 'data', name), r.csv);
  return { ok: true, file: name, rows: r.rows.length, query: r.query };
});

// ---------- ledger & summaries ----------
route('GET', '/api/ledger/:team', async (req, res, p) => repo.readLedger(p.team));
route('PUT', '/api/ledger/:team', async (req, res, p) => { const l = await readBody(req); if (l.team !== p.team) throw err(400, 'team mismatch'); repo.writeLedger(l); return { ok: true, updatedAt: l.updatedAt }; });
route('PUT', '/api/summary/:team', async (req, res, p) => { const s = await readBody(req); repo.writeSummary(p.team, Object.assign({ at: new Date().toISOString() }, s)); return { ok: true }; });
route('GET', '/api/exec', async () => repo.listTeams().map(t => { const ledger = repo.readLedger(t.id); return { team: { id: t.id, name: t.name, bu: t.bu || (t.dynatrace && t.dynatrace.dimensions && t.dynatrace.dimensions.bu) || '' }, summary: repo.readSummary(t.id), ledger: core.ledgerSummary(ledger, t), offenders: Object.values(ledger.offenders).map(o => ({ id: o.id, name: o.name, category: o.category, state: o.state, disposition: o.disposition, jira: o.jira, baseline: o.baseline, latest: o.latest })) }; }));

// ---------- Claude (streams NDJSON) ----------
route('POST', '/api/analyze', async (req, res) => {
  const b = await readBody(req); const team = repo.readTeam(b.team); if (!team) throw err(404, 'team not found');
  if (!b.packet || !b.packet.offender) throw err(400, 'packet required');
  res.writeHead(200, { 'Content-Type': 'application/x-ndjson; charset=utf-8', 'Cache-Control': 'no-store', 'X-Accel-Buffering': 'no' });
  const send = o => res.write(JSON.stringify(o) + '\n');
  send({ type: 'start', model: (team.ai && team.ai.model) || 'sonnet', at: new Date().toISOString() });
  try { const out = await repo.runClaude(team, b.packet, { force: !!b.force, onEvent: ev => send({ type: 'event', event: slimEvent(ev) }) }); send(Object.assign({ type: 'result' }, out)); }
  catch (e) { send({ type: 'error', message: e.message }); }
  res.end(); return null;
});
function slimEvent(ev) {
  if (ev.type === 'assistant' && ev.message && Array.isArray(ev.message.content)) return { type: 'assistant', content: ev.message.content.map(c => c.type === 'text' ? { type: 'text', text: String(c.text).slice(0, 600) } : c.type === 'tool_use' ? { type: 'tool_use', name: c.name, input: JSON.stringify(c.input || {}).slice(0, 200) } : { type: c.type }) };
  if (ev.type === 'user' && ev.message && Array.isArray(ev.message.content)) return { type: 'tool_result', n: ev.message.content.length };
  if (ev.type === 'result') return { type: 'result', cost: ev.total_cost_usd, turns: ev.num_turns, ms: ev.duration_ms, isError: !!ev.is_error };
  if (ev.type === 'system') return { type: 'system', subtype: ev.subtype, model: ev.model };
  return { type: ev.type || 'raw' };
}

// ---------- Dynatrace ----------
route('POST', '/api/metrics/push', async req => {
  const b = await readBody(req); const out = {};
  if (b.lines && b.lines.length) out.metrics = await dynatrace.pushMetrics(b.lines);
  if (b.events && b.events.length) out.bizevents = await dynatrace.pushBizevents(b.events);
  return Object.assign({ ok: true }, out);
});

// ---------- reports & git ----------
route('POST', '/api/report', async req => {
  const b = await readBody(req); const name = String(b.name || `report-${Date.now()}`).replace(/[^a-z0-9_.-]/gi, '_').replace(/\.md$/i, '') + '.md';
  const dir = path.join(ROOT, 'reports', repo.readTeam(b.team) ? b.team : 'misc'); fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, name), String(b.markdown || '')); return { ok: true, file: path.relative(ROOT, path.join(dir, name)) };
});
route('POST', '/api/git/pull', async () => repo.gitPull());
route('POST', '/api/git/commit', async req => { const b = await readBody(req); return repo.gitCommit(b.paths, b.message, !!b.push); });

// ---------- Jira ----------
route('POST', '/api/jira/sync', async req => {
  const b = await readBody(req); const team = repo.readTeam(b.team); if (!team) throw err(404, 'team not found');
  const ledger = repo.readLedger(team.id);
  const r = await jira.syncLedger(ledger);
  if (r.events.length) repo.writeLedger(ledger);
  return { ok: true, checked: r.checked.length, events: r.events.map(e => ({ id: e.offender.id, name: e.offender.name, from: e.from, to: e.to, jira: e.offender.jira })), ledger };
});

// ---------- static ----------
function serveStatic(req, res) {
  const p = url.parse(req.url).pathname;
  const file = p === '/' || p === '/index.html' ? path.join(ROOT, 'ui', 'index.html') : p === '/lib/core.js' ? path.join(ROOT, 'lib', 'core.js') : null;
  if (!file || !fs.existsSync(file)) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
  res.writeHead(200, { 'Content-Type': file.endsWith('.js') ? 'application/javascript' : 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(fs.readFileSync(file));
}
function err(code, message) { const e = new Error(message); e.status = code; return e; }

const server = http.createServer(async (req, res) => {
  const u = url.parse(req.url, true);
  if (!u.pathname.startsWith('/api/')) return serveStatic(req, res);
  if (req.method !== 'GET' && req.headers.origin && !/^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/.test(req.headers.origin)) return json(res, 403, { error: 'cross-origin request refused' });
  for (const r of routes) {
    const m = u.pathname.match(r.re);
    if (!m || r.method !== req.method) continue;
    try { const out = await r.handler(req, res, m.groups || {}, u.query); if (out !== null) json(res, 200, out); }
    catch (e) { if (!res.headersSent) json(res, e.status || 500, { error: e.message }); else res.end(); }
    return;
  }
  json(res, 404, { error: 'no such route' });
});
server.listen(PORT, HOST, () => {
  const g = repo.gitInfo();
  console.log(`Toil Analyzer  http://${HOST}:${PORT}\n  repo    ${ROOT}${g.available ? ` (${g.branch}${g.dirty ? ', uncommitted changes' : ''})` : ' (not a git checkout)'}\n  claude  ${repo.claudeBin() || 'not found on PATH'}\n  servicenow ${process.env.SN_INSTANCE ? 'configured' : 'not configured'}   dynatrace ${process.env.DT_URL ? 'configured' : 'not configured'}   jira ${process.env.JIRA_URL ? 'configured' : 'not configured'}`);
  if (process.env.OPEN !== '0') { const { exec } = require('child_process'); const cmd = process.platform === 'win32' ? `start "" "http://${HOST}:${PORT}"` : process.platform === 'darwin' ? `open http://${HOST}:${PORT}` : `xdg-open http://${HOST}:${PORT}`; exec(cmd, () => {}); }
});
