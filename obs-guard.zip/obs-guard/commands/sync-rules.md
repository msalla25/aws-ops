---
name: sync-rules
description: Read the team's release-readiness skill and derive obs-guard's dev-time rule set from it. Run this once when adopting the plugin, and again whenever the release-readiness skill changes.
---

# Sync obs-guard rules from the release-readiness skill

You are converting an after-the-fact release check into edit-time nudges. The output
is a rules file, not prose. Work through the steps in order and stop at the end.

Arguments: `$ARGUMENTS` should contain the path to the release-readiness skill. If it
is empty, ask for the path in one sentence and stop. Do not guess, do not search the
web, do not invent checks the skill does not contain.

## Step 1 — Read the source once

Read the skill's `SKILL.md` and any reference files it actually points at. Read them
once. Everything downstream quotes from what you already have.

## Step 2 — Classify every check

List every distinct check the skill performs. Put each into exactly one bucket:

| Bucket | Test | Outcome |
| --- | --- | --- |
| `AUTHOR` | Decidable from source or config in the repo, with no running system | becomes a rule |
| `PROXY` | Not decidable, but a code-level precondition is: the check needs a live metric, and whether the code emits that metric at all is visible now | becomes a rule against the precondition |
| `RUNTIME` | Needs telemetry, a deploy window, a baseline, or a live dependency | stays in the release skill, no rule |

Be strict. "Error rate is within baseline" is `RUNTIME`. "The handler emits an error
metric at all" is `PROXY`. Most checks in a good release skill are `RUNTIME` — a short
rule set derived from a long skill is the correct result, not a failure.

## Step 3 — Find out what this repo actually is

Before writing any rule, establish which stacks are present: look for `pom.xml`,
`build.gradle`, `requirements.txt`, `pyproject.toml`, `*.tf`, Kubernetes or OpenShift
manifests, Ansible playbooks, `package.json`. Write rules only for stacks that exist
here. A Java rule in a Terraform-only repo is pure overhead.

## Step 4 — Write candidate rules

Each rule takes one of two shapes in `rules/rules.json`:

- `match`: a regex evaluated against the text just written. Use for things that are
  wrong on sight — a swallowed exception, an inline credential.
- `trigger` + `requires`: `trigger` matches the text just written, `requires` is a list
  of regexes searched in the whole file. The rule fires only when the trigger is present
  and none of `requires` is. Use for "you added X but there is no Y anywhere near it".

Every rule needs: `id`, `files` (globs), `severity` (`high`/`medium`/`low`), `note`,
and `source` (the section of the release skill it came from, so a developer can trace
why it exists).

The `note` is the whole product. Constraints:

- Two lines maximum, written as a factual statement.
- Name the operational consequence, not the policy. "A slow dependency will hold
  threads until the pool is exhausted" — not "timeouts are required by standard."
- Never phrase it as a command to Claude or as a system instruction.

## Step 5 — Apply the noise budget

This step is what keeps the plugin from being ignored. For each candidate rule, run its
regex across the existing repo and count how many files already match.

- More than 15 existing files match, or more than 2% of files of that type: set
  `"enabled": false` and add `"disabled_reason": "matches N existing files"`.
- The rule would fire on generated code, tests, or vendored code: tighten `files`, or
  extend `config.exclude_globs`.

A rule that fires on legacy code everywhere trains developers to ignore every rule.
Report the disabled ones — they are usually a backlog item, not a bad rule.

## Step 6 — Validate and write

- Confirm every regex compiles.
- Confirm the total enabled rule count is 15 or fewer. If it is higher, drop the
  lowest-severity rules until it is not.
- Keep `config` as it is unless the counts are clearly wrong for this repo.
- Set `generated_from` to the skill path and today's date.
- Write the file to the plugin's `rules/rules.json`.

## Step 7 — Report, briefly

Output only:

1. A count line: rules enabled, rules disabled for noise, checks left as `RUNTIME`.
2. The `RUNTIME` list. This is the honest answer to "what still has to happen after
   deploy", and it is what justifies the release skill continuing to exist.
3. Any check you could not classify, with the one question that would settle it.

No summary of the rules themselves — they are in the file.
