#!/usr/bin/env python3
"""obs-guard: dev-time observability / MR-hygiene nudges.

Runs as a Claude Code PostToolUse hook after Write/Edit/MultiEdit.
Design rules, in priority order:

  1. Never block. Never exit non-zero. A bug here must not cost a developer a turn.
  2. Only look at text that was just written, never the whole repo.
  3. Say nothing when there is nothing to say.
  4. Say each thing once per file per session, and stop entirely after a budget.

Output is a JSON object on stdout with hookSpecificOutput.additionalContext, which
Claude Code inserts next to the tool result. Claude folds the fix into the work it
is already doing; the developer is not interrupted with a dialog.
"""

import fnmatch
import json
import os
import re
import sys
import tempfile

MAX_FILE_BYTES = 400_000
IGNORE_TOKEN = "obs-guard:ignore"


# ---------------------------------------------------------------- infrastructure

def bail():
    """Exit quietly. Used for every unexpected condition."""
    sys.exit(0)


def read_event():
    try:
        raw = sys.stdin.read()
        return json.loads(raw) if raw.strip() else {}
    except Exception:
        bail()


def plugin_root():
    return os.environ.get("CLAUDE_PLUGIN_ROOT") or os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))
    )


def state_dir():
    base = os.environ.get("CLAUDE_PLUGIN_DATA") or os.path.join(
        tempfile.gettempdir(), "obs-guard"
    )
    path = os.path.join(base, "state")
    try:
        os.makedirs(path, exist_ok=True)
        return path
    except Exception:
        return None


def load_state(session_id):
    d = state_dir()
    if not d or not session_id:
        return {"seen": [], "count": 0, "summarized": False, "findings": []}, None
    p = os.path.join(d, "%s.json" % re.sub(r"[^A-Za-z0-9_-]", "-", session_id)[:80])
    try:
        with open(p) as fh:
            s = json.load(fh)
    except Exception:
        s = {"seen": [], "count": 0, "summarized": False, "findings": []}
    s.setdefault("seen", [])
    s.setdefault("count", 0)
    s.setdefault("summarized", False)
    s.setdefault("findings", [])
    return s, p


def save_state(state, path):
    if not path:
        return
    try:
        with open(path, "w") as fh:
            json.dump(state, fh)
    except Exception:
        pass


def load_rules():
    try:
        with open(os.path.join(plugin_root(), "rules", "rules.json")) as fh:
            doc = json.load(fh)
    except Exception:
        bail()
    cfg = doc.get("config", {})
    return doc.get("rules", []), cfg


# ---------------------------------------------------------------- event parsing

def extract(event):
    """Return (file_path, added_text). added_text is only what this call wrote."""
    ti = event.get("tool_input") or {}
    path = ti.get("file_path") or ti.get("notebook_path") or ""
    if not path:
        bail()

    chunks = []
    if isinstance(ti.get("content"), str):
        chunks.append(ti["content"])
    if isinstance(ti.get("new_string"), str):
        chunks.append(ti["new_string"])
    for edit in ti.get("edits") or []:
        if isinstance(edit, dict) and isinstance(edit.get("new_string"), str):
            chunks.append(edit["new_string"])

    added = "\n".join(c for c in chunks if c)
    if not added.strip():
        bail()
    return path, added


def path_matches(path, globs):
    base = os.path.basename(path)
    norm = path.replace(os.sep, "/")
    for g in globs or []:
        if fnmatch.fnmatch(base, g) or fnmatch.fnmatch(norm, g) or fnmatch.fnmatch(
            norm, "*/" + g.lstrip("*/")
        ):
            return True
    return False


def read_whole_file(path):
    try:
        if os.path.getsize(path) > MAX_FILE_BYTES:
            return ""
        with open(path, "r", errors="replace") as fh:
            return fh.read()
    except Exception:
        return ""


def search(pattern, text):
    try:
        return re.search(pattern, text, re.MULTILINE) is not None
    except re.error:
        return False


# ---------------------------------------------------------------- evaluation

def evaluate(rules, path, added, whole_lazy):
    hits = []
    for rule in rules:
        if not rule.get("enabled", True):
            continue
        if not path_matches(path, rule.get("files")):
            continue
        if rule.get("unless") and search(rule["unless"], added):
            continue

        if rule.get("match"):
            if not search(rule["match"], added):
                continue
        elif rule.get("trigger"):
            if not search(rule["trigger"], added):
                continue
            requires = rule.get("requires") or []
            if requires:
                whole = whole_lazy()
                if any(search(r, whole) for r in requires):
                    continue
        else:
            continue

        hits.append(rule)
    order = {"high": 0, "medium": 1, "low": 2}
    hits.sort(key=lambda r: order.get(r.get("severity", "medium"), 1))
    return hits


def render(path, hits):
    short = os.path.basename(path)
    lines = ["obs-guard noticed the following in the change just made to %s:" % short]
    for h in hits:
        line = "- %s" % h.get("note", h.get("id", "unnamed rule"))
        src = h.get("source")
        if src:
            line += " (release-readiness: %s)" % src
        lines.append(line)
    lines.append(
        "These are cheap to fix now and are what the release-readiness check looks for "
        "later. Fix them in this change if they apply; if a point does not apply here, "
        "say so briefly and move on."
    )
    return "\n".join(lines)


def emit(payload):
    sys.stdout.write(json.dumps(payload))
    sys.exit(0)


# ---------------------------------------------------------------- modes

def run_stop(event, cfg):
    state, spath = load_state(event.get("session_id"))
    if state.get("summarized") or not state.get("findings"):
        bail()
    if not cfg.get("emit_session_summary", True):
        bail()
    state["summarized"] = True
    save_state(state, spath)
    files = sorted({f.split("::")[0] for f in state["findings"]})
    emit(
        {
            "systemMessage": "obs-guard: %d observability point(s) were raised this "
            "session across %s. Worth a look before the MR."
            % (len(state["findings"]), ", ".join(files[:4]))
        }
    )


def run_check(event, rules, cfg):
    path, added = extract(event)

    if IGNORE_TOKEN in added:
        bail()
    if path_matches(path, cfg.get("exclude_globs")):
        bail()

    state, spath = load_state(event.get("session_id"))
    if state["count"] >= cfg.get("max_notes_per_session", 8):
        bail()

    cache = {}

    def whole_lazy():
        if "v" not in cache:
            cache["v"] = read_whole_file(path)
        return cache["v"]

    hits = evaluate(rules, path, added, whole_lazy)
    if not hits:
        bail()

    fresh = []
    for h in hits:
        key = "%s::%s" % (os.path.basename(path), h.get("id"))
        if key in state["seen"]:
            continue
        fresh.append(h)
        state["seen"].append(key)
        state["findings"].append(key)
    if not fresh:
        bail()

    fresh = fresh[: cfg.get("max_notes_per_edit", 2)]
    state["count"] += len(fresh)
    save_state(state, spath)

    emit(
        {
            "hookSpecificOutput": {
                "hookEventName": "PostToolUse",
                "additionalContext": render(path, fresh),
            }
        }
    )


def main():
    event = read_event()
    rules, cfg = load_rules()
    try:
        if "--stop" in sys.argv:
            run_stop(event, cfg)
        else:
            run_check(event, rules, cfg)
    except SystemExit:
        raise
    except Exception:
        bail()


if __name__ == "__main__":
    main()
