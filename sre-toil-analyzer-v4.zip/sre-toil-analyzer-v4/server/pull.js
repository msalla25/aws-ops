#!/usr/bin/env node
/* Scheduled pull: ServiceNow → data/<team>-<yyyymmdd>.csv. No Claude.
 * usage: node server/pull.js --team example-team [--days 90] [--all] */
'use strict';
const fs = require('fs'), path = require('path');
const repo = require('../lib/repo');
const servicenow = require('../lib/servicenow');
const args = parse(process.argv.slice(2));
(async () => {
  const teams = args.all ? repo.listTeams() : [repo.readTeam(args.team || '')].filter(Boolean);
  if (!teams.length) { console.error('usage: node server/pull.js --team <id> [--days N] | --all'); process.exit(2); }
  for (const team of teams) {
    process.stdout.write(`${team.id}: pulling`);
    const r = await servicenow.pullIncidents(team, { days: args.days ? +args.days : undefined, onPage: n => process.stdout.write(` ${n}`) });
    const name = `${team.id}-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}.csv`;
    fs.mkdirSync(path.join(repo.ROOT, 'data'), { recursive: true });
    fs.writeFileSync(path.join(repo.ROOT, 'data', name), r.csv);
    console.log(`\n${team.id}: ${r.rows.length} incidents → data/${name}`);
  }
})().catch(e => { console.error('pull failed:', e.message); process.exit(1); });
function parse(a) { const o = {}; for (let i = 0; i < a.length; i++) { if (a[i].startsWith('--')) { const k = a[i].slice(2); o[k] = (a[i + 1] && !a[i + 1].startsWith('--')) ? a[++i] : true; } } return o; }
