#!/usr/bin/env node
/* Scheduled progress: latest CSV → analysis → ledger advance (fixed→verified, verified→regressed)
 * → ledger/<team>/summary.json → reports/<team>/<yyyy-Www>.md → optional Dynatrace push. No Claude.
 * usage: node server/report.js --team example-team [--file data/x.csv] [--push] [--no-jira] [--all] [--force]
 * A file that fails the load checks (mostly other teams' incidents, many duplicates, no groups set) is skipped
 * with exit code 3 and nothing written, unless --force is given.
 * With JIRA_URL + JIRA_TOKEN set, Ticketed offenders whose issue is Done move to Fixed first. */
'use strict';
const fs = require('fs'), path = require('path');
const core = require('../lib/core');
const repo = require('../lib/repo');
const dynatrace = require('../lib/dynatrace');
const jira = require('../lib/jira');
const args = parse(process.argv.slice(2));
(async () => {
  const teams = args.all ? repo.listTeams() : [repo.readTeam(args.team || '')].filter(Boolean);
  if (!teams.length) { console.error('usage: node server/report.js --team <id> [--file f.csv] [--push] [--force] | --all'); process.exit(2); }
  const { catalog } = repo.loadCatalog();
  for (const team of teams) {
    const file = args.file ? path.resolve(repo.ROOT, args.file) : latest(team.id);
    if (!file) { console.log(`${team.id}: no data file in data/ — run server/pull.js first`); continue; }
    const parsed = core.parseCSV(fs.readFileSync(file, 'utf8'));
    const mapping = core.detectMapping(parsed.headers);
    // Same load checks as the UI: dedupe by incident number, keep only this team's groups, and refuse a load that looks off.
    const load = core.prepareLoad(core.normalizeIncidents(parsed.rows, mapping), team, repo.listTeams());
    if (load.check.preview && !args.force) { console.log(`${team.id}: skipped ${path.relative(repo.ROOT, file)}. ${load.check.reasons.map(r => r.text).join(' ')} Nothing was written; re-run with --force to accept it.`); process.exitCode = 3; continue; }
    if (load.info.duplicates || load.info.excluded) console.log(`${team.id}: kept ${load.info.kept} of ${load.info.total} rows (${load.info.duplicates} duplicate, ${load.info.excluded} outside the team's groups)`);
    const incidents = load.incidents;
    const analysis = core.analyze(incidents, team, catalog);
    const ledger = repo.readLedger(team.id);
    analysis.clusters.filter(c => c.flags.toil).forEach(c => core.registerOffender(ledger, c, { auto: true, by: 'schedule' }));
    let events = [];
    if (process.env.JIRA_URL && process.env.JIRA_TOKEN && !args['no-jira']) { try { const j = await jira.syncLedger(ledger); events = events.concat(j.events); if (j.checked.length) console.log(`${team.id}: jira checked ${j.checked.length} issue(s)`); } catch (e) { console.error(`${team.id}: jira sync skipped — ${e.message}`); } }
    events = events.concat(core.advanceLedger(ledger, analysis, incidents));
    repo.writeLedger(ledger);
    const ls = core.ledgerSummary(ledger, team);
    repo.writeSummary(team.id, { kpis: analysis.kpis, ledger: ls, byCategory: analysis.byCategory, weeks: analysis.weeks.slice(-12), weeklyTotal: analysis.weeklyTotal.slice(-12), weeklyToil: analysis.weeklyToil.slice(-12), top: analysis.clusters.filter(c => c.flags.toil).slice(0, 10).map(c => ({ id: c.id, name: c.name, category: c.category, count: c.count, perMonth: +c.perMonth.toFixed(2), score: c.score, disposition: c.disposition, hoursPerMonth: c.savings.hoursPerMonth })), source: path.basename(file) });
    const md = core.renderReport(analysis, ledger, team);
    const dir = path.join(repo.ROOT, 'reports', team.id); fs.mkdirSync(dir, { recursive: true });
    const out = path.join(dir, `${core.weekKey(new Date())}.md`); fs.writeFileSync(out, md);
    console.log(`${team.id}: ${analysis.kpis.incidents} incidents, ${analysis.kpis.toilClusters} toil patterns, ledger ${Object.keys(ledger.offenders).length} offenders${events.length ? ' — ' + events.map(e => `${e.offender.name}: ${e.from}→${e.to}`).join('; ') : ''} → ${path.relative(repo.ROOT, out)}`);
    if (args.push) {
      const lines = core.metricsLines(analysis, ledger, team);
      const evs = events.map(e => core.bizevent(team, e.offender, e.from, e.to));
      const m = await dynatrace.pushMetrics(lines); const b = await dynatrace.pushBizevents(evs);
      console.log(`${team.id}: pushed ${m.lines} metric lines, ${b.events} bizevents to Dynatrace`);
    }
  }
})().catch(e => { console.error('report failed:', e.message); process.exit(1); });
function latest(teamId) { const files = repo.listData(teamId).filter(f => f.name.startsWith(teamId + '-')); return files.length ? path.join(repo.ROOT, 'data', files[0].name) : null; }
function parse(a) { const o = {}; for (let i = 0; i < a.length; i++) { if (a[i].startsWith('--')) { const k = a[i].slice(2); o[k] = (a[i + 1] && !a[i + 1].startsWith('--')) ? a[++i] : true; } } return o; }
