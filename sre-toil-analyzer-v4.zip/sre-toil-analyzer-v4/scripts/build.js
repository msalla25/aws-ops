#!/usr/bin/env node
/* Inline the engine, the app script, the signature catalog and the example team into ui/index.html
 * so the same file works from file:// (Lite) and from the local server (Connected).
 * Run after editing lib/core.js, ui/app.js, signatures/ or teams/example-team/team.json.
 *   node scripts/build.js          # rebuild
 *   node scripts/build.js --check  # exit 1 if index.html is out of date (CI) */
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');
const html = path.join(ROOT, 'ui', 'index.html');
const read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const safe = s => s.replace(/<\/script/gi, '<\\/script');
const catalog = fs.readdirSync(path.join(ROOT, 'signatures')).filter(f => f.endsWith('.json')).map(f => JSON.parse(read('signatures/' + f)));
const team = JSON.parse(read('teams/example-team/team.json'));
const blocks = {
  catalog: `<script id="embedded-catalog" type="application/json">${safe(JSON.stringify(catalog))}</script>`,
  team: `<script id="embedded-team" type="application/json">${safe(JSON.stringify(team))}</script>`,
  core: `<script>\n${safe(read('lib/core.js'))}\n</script>`,
  app: `<script>\n${safe(read('ui/app.js'))}\n</script>`
};
let src = fs.readFileSync(html, 'utf8'), out = src;
for (const [name, body] of Object.entries(blocks)) {
  const re = new RegExp(`(<!-- @inline:${name} -->)[\\s\\S]*?(<!-- @endinline:${name} -->)`);
  if (!re.test(out)) { console.error(`marker @inline:${name} missing in ui/index.html`); process.exit(1); }
  out = out.replace(re, (m, a, b) => `${a}\n${body}\n${b}`);
}
if (process.argv.includes('--check')) { if (out !== src) { console.error('ui/index.html is out of date — run: npm run build'); process.exit(1); } console.log('OK — ui/index.html is up to date'); process.exit(0); }
fs.writeFileSync(html, out);
console.log(`built ui/index.html (${(out.length / 1024).toFixed(0)} KB): ${catalog.length} signatures, team ${team.id}, core ${(blocks.core.length / 1024).toFixed(0)} KB, app ${(blocks.app.length / 1024).toFixed(0)} KB`);
