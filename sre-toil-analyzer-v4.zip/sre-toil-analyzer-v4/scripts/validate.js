#!/usr/bin/env node
/* Minimal JSON-schema checker (type/required/properties/items/enum/pattern/minItems) — no dependencies. */
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(__dirname, '..');

function check(schema, value, at, errs) {
  if (!schema) return;
  const t = schema.type;
  const isType = (ty, v) => ty === 'array' ? Array.isArray(v) : ty === 'object' ? (v && typeof v === 'object' && !Array.isArray(v)) : ty === 'number' ? typeof v === 'number' && !isNaN(v) : typeof v === ty;
  if (t && !isType(t, value)) { errs.push(`${at}: expected ${t}`); return; }
  if (schema.enum && !schema.enum.includes(value)) errs.push(`${at}: must be one of ${schema.enum.join(', ')}`);
  if (schema.pattern && typeof value === 'string' && !new RegExp(schema.pattern).test(value)) errs.push(`${at}: does not match ${schema.pattern}`);
  if (t === 'object') {
    for (const r of (schema.required || [])) if (!(r in value)) errs.push(`${at}: missing required '${r}'`);
    for (const [k, sub] of Object.entries(schema.properties || {})) if (k in value) check(sub, value[k], `${at}.${k}`, errs);
  }
  if (t === 'array') {
    if (schema.minItems != null && value.length < schema.minItems) errs.push(`${at}: needs at least ${schema.minItems} item(s)`);
    if (schema.items) value.forEach((v, i) => check(schema.items, v, `${at}[${i}]`, errs));
  }
}
function validateFile(file, schema) {
  const errs = [];
  let data; try { data = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return [`${file}: invalid JSON (${e.message})`]; }
  check(schema, data, path.relative(ROOT, file), errs);
  return errs;
}
function walk(dir, pred) { if (!fs.existsSync(dir)) return []; return fs.readdirSync(dir, { withFileTypes: true }).flatMap(d => d.isDirectory() ? walk(path.join(dir, d.name), pred) : (pred(d.name) ? [path.join(dir, d.name)] : [])); }

const teamSchema = JSON.parse(fs.readFileSync(path.join(ROOT, 'schema/team.schema.json'), 'utf8'));
const sigSchema = JSON.parse(fs.readFileSync(path.join(ROOT, 'schema/signature.schema.json'), 'utf8'));
let errors = [];
const teams = walk(path.join(ROOT, 'teams'), n => n === 'team.json');
for (const f of teams) { errors = errors.concat(validateFile(f, teamSchema)); const id = JSON.parse(fs.readFileSync(f, 'utf8')).id; if (id !== path.basename(path.dirname(f))) errors.push(`${path.relative(ROOT, f)}: id '${id}' must equal folder name`); }
// Ownership: an assignment group belongs to one team only, or its incidents would count twice on the dashboard.
const teamObjs = teams.map(f => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; } }).filter(Boolean);
for (const c of require('../lib/core').ownershipMap(teamObjs).conflicts) errors.push(`assignment group '${c.group}' is claimed by more than one team: ${c.teams.join(', ')}`);
// Components: within a team, a CI sits in one component only.
for (const t of teamObjs) {
  const seen = new Map();
  for (const comp of t.components || []) for (const ci of comp.cis || []) {
    const k = String(ci).trim().toLowerCase();
    if (seen.has(k) && seen.get(k) !== comp.name) errors.push(`teams/${t.id}: CI '${ci}' is in both '${seen.get(k)}' and '${comp.name}'`);
    seen.set(k, comp.name);
  }
}
const sigs = walk(path.join(ROOT, 'signatures'), n => n.endsWith('.json'));
const ids = new Map();
for (const f of sigs) { errors = errors.concat(validateFile(f, sigSchema)); try { const id = JSON.parse(fs.readFileSync(f, 'utf8')).id; if (ids.has(id) && !f.includes('proposed')) errors.push(`duplicate signature id '${id}' in ${path.relative(ROOT, f)} and ${ids.get(id)}`); ids.set(id, path.relative(ROOT, f)); } catch (e) { /* reported above */ } }
if (errors.length) { console.error('Validation failed:\n  ' + errors.join('\n  ')); process.exit(1); }
console.log(`OK — ${teams.length} team(s), ${sigs.length} signature file(s) valid`);
