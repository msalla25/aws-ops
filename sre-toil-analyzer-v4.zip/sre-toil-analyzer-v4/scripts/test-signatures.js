#!/usr/bin/env node
/* CI gate for the shared signature catalog:
 *  1. every sample must be matched by its own signature
 *  2. no sample may be claimed by another (catalog) signature — first match wins by priority, so overlap = silent theft */
const fs = require('fs'), path = require('path');
const core = require('../lib/core');
const ROOT = path.resolve(__dirname, '..');
const dir = path.join(ROOT, 'signatures');
const load = d => fs.existsSync(d) ? fs.readdirSync(d).filter(f => f.endsWith('.json')).map(f => JSON.parse(fs.readFileSync(path.join(d, f), 'utf8'))) : [];
const catalog = load(dir), proposed = load(path.join(dir, 'proposed'));
const all = catalog.concat(proposed);
const matchers = core.buildMatchers(all);
let fail = 0, checks = 0;
for (const sig of all) {
  const m = matchers.find(x => x.sig.id === sig.id);
  if (!m) { console.error(`✗ ${sig.id}: regex does not compile`); fail++; continue; }
  for (const s of sig.samples || []) {
    checks++;
    const inc = { short: s, description: '' };
    if (!m.re.test(inc.short)) { console.error(`✗ ${sig.id}: sample not matched → "${s}"`); fail++; }
    const winner = core.matchCatalog(inc, matchers);
    if (winner && winner.id !== sig.id) { console.error(`✗ ${sig.id}: sample "${s}" is claimed by '${winner.id}' (priority ${winner.priority || 0} ≥ ${sig.priority || 0})`); fail++; }
  }
}
if (fail) { console.error(`\n${fail} problem(s) in ${checks} sample checks`); process.exit(1); }
console.log(`OK — ${all.length} signatures (${proposed.length} proposed), ${checks} samples verified`);
