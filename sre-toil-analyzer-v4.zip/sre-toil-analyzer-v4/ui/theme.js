/* Appearance only. Kept separate from the incident engine and application state. */
(function () {
  'use strict';
  const root = document.documentElement;
  const key = 'ta:theme';
  const system = typeof window.matchMedia === 'function'
    ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  const valid = value => value === 'light' || value === 'dark';
  let saved = null;
  try { saved = localStorage.getItem(key); } catch (e) { /* Storage may be unavailable for local files. */ }
  let chosen = valid(saved);
  const systemTheme = () => system && system.matches ? 'dark' : 'light';

  function syncControl() {
    const button = document.getElementById('btnTheme');
    if (!button) return;
    const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
    const label = 'Switch to ' + next + ' mode';
    button.title = label;
    button.setAttribute('aria-label', label);
    button.querySelector('.theme-label').textContent = next === 'light' ? 'Light mode' : 'Dark mode';
  }

  function apply(theme) {
    root.dataset.theme = theme;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'light' ? '#F6F6F6' : '#100818');
    syncControl();
  }

  // Apply before the stylesheet paints so a saved light theme does not flash dark.
  apply(chosen ? saved : systemTheme());

  function wireTheme() {
    const button = document.getElementById('btnTheme');
    if (!button) return;
    syncControl();
    button.addEventListener('click', () => {
      const theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
      chosen = true;
      apply(theme);
      try { localStorage.setItem(key, theme); } catch (e) { /* The switch still works without persistence. */ }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wireTheme, { once: true });
  else wireTheme();

  if (system && typeof system.addEventListener === 'function') {
    system.addEventListener('change', () => { if (!chosen) apply(systemTheme()); });
  }
  window.addEventListener('storage', event => {
    if (event.key !== key && event.key !== null) return;
    chosen = valid(event.newValue);
    apply(chosen ? event.newValue : systemTheme());
  });
})();
