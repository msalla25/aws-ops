/* Toil Analyzer UI — everything runs here; the server (when present) only lends hands: files, git, Claude, APIs. */
(function () {
  'use strict';
  const C = window.ToilCore;
  const $ = s => document.querySelector(s), $$ = s => Array.from(document.querySelectorAll(s));
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = (n, d) => Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: d == null ? 1 : d });
  const money = n => (S.team && S.team.hoursModel && S.team.hoursModel.currency === 'USD' ? '$' : ((S.team && S.team.hoursModel && S.team.hoursModel.currency) || '') + ' ') + fmt(n, 0);
  const dt = s => s ? String(s).slice(0, 10) : '—';

  const S = { mode: 'lite', status: null, teams: [], team: null, catalog: [], proposed: [], raw: null, mapping: {}, incidents: [], analysis: null, ledger: null, exec: null, view: 'exec', selected: null, sort: { off: ['rank', 1], led: ['state', 1] }, fileName: '', whatIf: 5, norm: [], allIncidents: [], load: null, baseLedger: null, isDemo: false };

  // ---------- boot ----------
  async function boot() {
    const embeddedTeam = safeJSON($('#embedded-team').textContent, null);
    S.catalog = safeJSON($('#embedded-catalog').textContent, []) || [];
    if (location.protocol.startsWith('http')) {
      try { S.status = await api('GET', '/api/status'); S.mode = 'connected'; } catch (e) { S.mode = 'lite'; }
    }
    if (S.mode === 'connected') {
      S.teams = await api('GET', '/api/teams');
      const sig = await api('GET', '/api/signatures'); S.catalog = sig.catalog; S.proposed = sig.proposed;
      $('#modeChip').textContent = 'Connected'; $('#modeChip').className = 'chip lime';
      $('#modeText').textContent = (S.status.git && S.status.git.available ? S.status.git.branch + (S.status.git.dirty ? ' · edits' : '') : 'repo');
      $('#btnSync').classList.remove('hide'); $('#btnCommit').classList.remove('hide'); $('#btnReportSave').classList.remove('hide');
      if (S.status.env.dynatrace) $('#btnPush').classList.remove('hide');
      if (S.status.env.servicenow) $('#btnPull').classList.remove('hide');
      if (S.status.env.jira) $('#btnJira').classList.remove('hide');
      $('#dataSel').classList.remove('hide');
      api('GET', '/api/exec').then(x => { S.exec = x; if (S.view === 'exec') renderExec(); }).catch(() => {});
    } else {
      const local = localTeams();
      S.teams = [embeddedTeam].filter(t => t && t.id).concat(local.filter(t => !embeddedTeam || t.id !== embeddedTeam.id));
      $('#modeText').textContent = 'Runs from this file. Ledger saved in this browser.';
    }
    if (!S.teams.length) S.teams = [{ id: 'my-team', name: 'My team', servicenow: { assignmentGroups: [] }, hoursModel: { rates: { technical: 85, business: 60 } } }];
    renderTeamSelect();
    await selectTeam(localStorage.getItem('ta:lastTeam') || S.teams[0].id);
    wire();
    render();
  }
  function safeJSON(s, fb) { try { return JSON.parse(s); } catch (e) { return fb; } }
  async function api(method, path, body) {
    const res = await fetch(path, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
    const text = await res.text(); let data; try { data = JSON.parse(text); } catch (e) { data = text; }
    if (!res.ok) throw new Error((data && data.error) || ('HTTP ' + res.status));
    return data;
  }
  function localTeams() { return Object.keys(localStorage).filter(k => k.startsWith('ta:team:')).map(k => safeJSON(localStorage.getItem(k), null)).filter(Boolean); }

  async function selectTeam(id) {
    let team = S.teams.find(t => t.id === id) || S.teams[0];
    if (S.mode === 'lite') { const o = safeJSON(localStorage.getItem('ta:team:' + team.id), null); if (o) team = o; }
    S.team = team; localStorage.setItem('ta:lastTeam', team.id);
    $('#teamSel').value = team.id;
    adoptLedger(await readSavedLedger(team.id));
    if (S.mode === 'connected') { try { const files = await api('GET', '/api/data?team=' + team.id); const sel = $('#dataSel'); sel.innerHTML = '<option value="">Open from data/…</option>' + files.map(f => `<option value="${esc(f.name)}">${esc(f.name)} (${fmt(f.size / 1024, 0)} KB)</option>`).join(''); } catch (e) { /* ignore */ } }
    // Loaded data is re-scoped to the new team: its own groups only, and its own check before anything is saved.
    if (S.norm.length) { S.load.confirmed = false; prepare(); runAnalysis(); } else S.analysis = null;
    render();
  }
  function renderTeamSelect() { $('#teamSel').innerHTML = S.teams.map(t => `<option value="${esc(t.id)}">${esc(t.name || t.id)}</option>`).join(''); }

  // ---------- data ----------
  function loadCSVText(text, name, opts) {
    const parsed = C.parseCSV(text);
    if (!parsed.headers.length || !parsed.rows.length) return toast('That file has no rows I can read.', true);
    S.raw = parsed; S.fileName = name || 'incidents.csv'; S.mapping = C.detectMapping(parsed.headers);
    if (!S.mapping.short) toast('Could not find a short description column — set it under Incidents → Column mapping.', true);
    S.isDemo = !!(opts && opts.demo);
    applyMapping();
  }
  function applyMapping() {
    if (isPreview()) S.ledger = clone(S.baseLedger); // an unsaved preview is abandoned by the next load
    S.norm = C.normalizeIncidents(S.raw.rows, S.mapping);
    S.load = { demo: !!S.isDemo, confirmed: false }; S._pendingEvents = []; S._previewEvents = [];
    prepare();
    $('#incSig').innerHTML = '<option value="">All patterns</option>'; $('#offCat').innerHTML = '<option value="">All categories</option>'; runAnalysis(); render();
  }
  /* Dedupe by incident number, keep only the selected team's groups (demo data is kept whole), and decide whether
   * the load needs a look before anything is saved. Ownership comes from every team's groups, not from who loaded it. */
  function prepare() {
    const p = C.prepareLoad(S.norm, S.team, S.teams, { scope: !S.load.demo });
    S.allIncidents = p.all; S.incidents = p.incidents; S.load.info = p.info; S.load.check = p.check;
  }
  /* In preview nothing is written: the ledger is a scratch copy, pushes and syncs wait, events are held. Demo data is always a preview. */
  function isPreview() { return !!(S.load && !S.load.confirmed && (S.load.demo || (S.load.check && S.load.check.preview))); }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function adoptLedger(l) { S.ledger = l; S.baseLedger = clone(l); }
  async function readSavedLedger(id) { return S.mode === 'connected' ? api('GET', '/api/ledger/' + id) : (safeJSON(localStorage.getItem('ta:ledger:' + id), null) || C.newLedger(id)); }
  function runAnalysis() {
    S.analysis = C.analyze(S.incidents, S.team, S.catalog);
    S.analysis.clusters.filter(c => c.flags.toil).forEach(c => C.registerOffender(S.ledger, c, { auto: true }));
    const events = C.advanceLedger(S.ledger, S.analysis, S.incidents);
    if (isPreview()) S._pendingEvents = events; else announce(events);
    saveLedger();
    if (S.mode === 'connected' && !isPreview()) api('PUT', '/api/summary/' + S.team.id, execSummary()).catch(() => {});
  }
  function announce(events) { if (events && events.length) toast(events.map(e => `${e.offender.name}: ${C.STATE_LABEL[e.from]} → ${C.STATE_LABEL[e.to]}`).join(' · ')); }
  function execSummary() { const a = S.analysis; return { kpis: a.kpis, ledger: C.ledgerSummary(S.ledger, S.team), byCategory: a.byCategory, weeks: a.weeks.slice(-12), weeklyTotal: a.weeklyTotal.slice(-12), weeklyToil: a.weeklyToil.slice(-12), top: a.clusters.filter(c => c.flags.toil).slice(0, 10).map(c => ({ id: c.id, name: c.name, category: c.category, count: c.count, perMonth: +c.perMonth.toFixed(2), score: c.score, disposition: c.disposition, hoursPerMonth: c.savings.hoursPerMonth })), source: S.fileName }; }
  const saveTimers = {};
  function saveLedger() {
    if (isPreview()) return;
    S.ledger.updatedAt = new Date().toISOString();
    S.baseLedger = clone(S.ledger);
    const id = S.team.id, body = S.baseLedger;
    if (S.mode === 'connected') { clearTimeout(saveTimers[id]); saveTimers[id] = setTimeout(() => api('PUT', '/api/ledger/' + id, body).catch(e => toast('Ledger not saved: ' + e.message, true)), 400); }
    else localStorage.setItem('ta:ledger:' + id, JSON.stringify(body));
  }
  function saveTeam(team) {
    S.team = team; const i = S.teams.findIndex(t => t.id === team.id); if (i >= 0) S.teams[i] = team; else S.teams.push(team);
    if (S.mode === 'connected') return api('PUT', '/api/team/' + team.id, team);
    localStorage.setItem('ta:team:' + team.id, JSON.stringify(team)); return Promise.resolve({ ok: true });
  }
  function cluster(id) { return S.analysis && S.analysis.clusters.find(c => c.id === id); }
  function download(name, text, type) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: type || 'text/plain' })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); }
  function copy(text) { navigator.clipboard.writeText(text).then(() => toast('Copied'), () => toast('Copy blocked by the browser — select and copy manually', true)); }

  // ---------- rendering ----------
  function render() {
    $$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.view === S.view));
    $$('.view').forEach(v => v.classList.toggle('hide', v.id !== 'view-' + S.view));
    const a = S.analysis;
    const st = loadStatus(); $('#dataStatus').textContent = st; $('#dataStatus').title = st;
    renderLoadBanner();
    $('#nOffenders').textContent = a ? a.kpis.toilClusters : ''; $('#nIncidents').textContent = a ? fmt(a.kpis.incidents, 0) : '';
    $('#nLedger').textContent = Object.keys(S.ledger.offenders).length || ''; $('#nSigs').textContent = S.catalog.length;
    ({ exec: renderExec, offenders: renderOffenders, incidents: renderIncidents, ledger: renderLedger, signatures: renderSignatures, report: renderReport, settings: renderSettings })[S.view]();
  }

  // Executive
  function renderExec() {
    const a = S.analysis, ls = C.ledgerSummary(S.ledger, S.team);
    $('#execTitle').textContent = S.team.name || S.team.id;
    if (!a && !Object.keys(S.ledger.offenders).length) { $('#execSub').textContent = ''; $('#execBody').innerHTML = `<div class="empty"><p>Load a ServiceNow incident export to see where the hours go.</p><button class="btn primary" onclick="document.getElementById('btnLoad').click()">Load CSV</button><button class="btn" onclick="document.getElementById('btnDemo').click()">Try demo data</button></div>`; return; }
    const k = a ? a.kpis : null;
    $('#execSub').textContent = a ? `${fmt(k.incidents, 0)} incidents over ${k.days} days · ${k.toilPct}% toil · generated ${a.generatedAt.slice(0, 16).replace('T', ' ')}` : 'Ledger only — load data to refresh the numbers';
    const st = ls.byState, hrs = st => Object.values(S.ledger.offenders).filter(o => o.state === st && o.baseline).reduce((s, o) => s + o.baseline.perMonth * (o.baseline.techPerInc + o.baseline.bizPerInc) * (C.DISPOSITIONS[o.disposition] || 0), 0);
    const chain = `<div class="killchain">
      ${['detected', 'ticketed', 'fixed', 'verified'].map(s => `<div class="stage ${s}"><div class="n">${st[s] || 0}</div><div class="l">${C.STATE_LABEL[s]}</div><div class="s">${s === 'verified' ? fmt(ls.hoursSavedVerifiedPerMonth) + ' h/mo saved' : fmt(hrs(s)) + ' h/mo in play'}</div></div>`).join('')}
      <div class="stage side"><div><span class="n">${st.regressed || 0}</span><span class="l">regressed</span></div><div><span class="n">${st.accepted || 0}</span><span class="l">accepted</span></div></div>
    </div>`;
    const kpis = k ? `<div class="kpis">
      <div class="kpi"><div class="v">${fmt(k.incidents, 0)}</div><div class="l">Incidents analyzed</div><div class="sub">${k.days} days</div></div>
      <div class="kpi"><div class="v">${fmt(k.toilIncidents, 0)}<em>${k.toilPct}%</em></div><div class="l">Toil candidates</div><div class="sub">${k.toilClusters} patterns</div></div>
      <div class="kpi"><div class="v">${fmt(k.technicalHours, 0)}<em>h</em></div><div class="l">Technical hours</div><div class="sub">${money(k.technicalUsd)} ops effort</div></div>
      <div class="kpi"><div class="v">${fmt(k.businessHours, 0)}<em>h</em></div><div class="l">Business hours</div><div class="sub">${money(k.businessUsd)} waiting / manual</div></div>
      <div class="kpi"><div class="v">${fmt(k.projectedSavedHoursPerMonth, 0)}<em>h/mo</em></div><div class="l">Projected savings</div><div class="sub">${money(k.projectedSavedUsdPerYear)}/yr if all candidates land</div></div>
      <div class="kpi"><div class="v">${fmt(ls.hoursSavedVerifiedPerMonth, 0)}<em>h/mo</em></div><div class="l">Verified savings</div><div class="sub">${money(ls.usdSavedVerifiedPerYear)}/yr, proven by data</div></div>
      <div class="kpi"><div class="v">${money(ls.aiCostUsd)}</div><div class="l">AI spend this month</div><div class="sub">${ls.aiRuns} analyses · ${money(ls.aiLifetimeCostUsd)} lifetime</div></div>
    </div>` : '';
    const proj = k ? k.projectedSavedHoursPerMonth : 0, max = Math.max(proj, ls.hoursSavedProjectedPerMonth, ls.hoursSavedVerifiedPerMonth, 1);
    const ladder = `<div class="panel"><h3>Savings ladder (hours per month)</h3><div class="ladder">
      <div>Projected</div><div class="bar"><i class="tint" style="width:${100 * proj / max}%"></i></div><div class="r num">${fmt(proj, 0)} h</div>
      <div>Committed</div><div class="bar"><i style="width:${100 * ls.hoursSavedProjectedPerMonth / max}%"></i></div><div class="r num">${fmt(ls.hoursSavedProjectedPerMonth, 0)} h</div>
      <div>Verified</div><div class="bar"><i class="lime" style="width:${100 * ls.hoursSavedVerifiedPerMonth / max}%"></i></div><div class="r num">${fmt(ls.hoursSavedVerifiedPerMonth, 0)} h</div>
    </div><div class="hint">Projected = every toil candidate at its disposition factor. Committed = ticketed, fixed or verified. Verified = incidents actually stopped in the data.</div></div>`;
    const weekly = a && a.weeks.length ? `<div class="panel"><h3>Weekly incidents</h3>${svgWeekly(a)}<div class="legend"><span><i style="background:var(--tint-3)"></i>All incidents</span><span><i style="background:var(--plum)"></i>Toil candidates</span></div></div>` : '';
    const cands = a ? a.clusters.filter(c => c.flags.toil).slice().sort((x, y) => y.savings.hoursPerMonth - x.savings.hoursPerMonth) : [];
    const n = Math.min(S.whatIf, cands.length), pick = cands.slice(0, n);
    const wi = cands.length ? `<div class="panel whatif"><h3>What if we fix the top <span id="wiN">${n}</span>?</h3><input type="range" id="whatIf" min="1" max="${cands.length}" value="${n}"><div class="row between"><div><div class="big" id="wiH">${fmt(pick.reduce((s, c) => s + c.savings.hoursPerMonth, 0), 0)} h/mo</div><div class="muted small" id="wiU">${money(pick.reduce((s, c) => s + c.savings.usdPerYear, 0))} per year</div></div><div class="small muted" id="wiL" style="max-width:55%">${pick.map(c => esc(c.name)).join(' · ')}</div></div></div>` : '';
    const top = cands.slice(0, 10);
    const topT = top.length ? `<div class="panel"><h3>Top offenders</h3><table><thead><tr><th>Pattern</th><th>Category</th><th class="r">Count</th><th class="r">/mo</th><th>Disposition</th><th>State</th><th class="r">Saves h/mo</th></tr></thead><tbody>${top.map(c => { const o = S.ledger.offenders[c.id]; return `<tr class="click" data-id="${esc(c.id)}"><td class="name">${esc(c.name)}</td><td>${esc(c.category)}</td><td class="r num">${c.count}</td><td class="r num">${fmt(c.perMonth)}</td><td>${C.DISPOSITION_LABEL[c.disposition] || c.disposition}</td><td>${o ? stateTag(o.state) : ''}</td><td class="r num">${fmt(c.savings.hoursPerMonth)}</td></tr>`; }).join('')}</tbody></table></div>` : '';
    const teams = S.mode === 'connected' && S.exec && S.exec.length > 1 ? `<div class="panel"><h3>All teams</h3><table><thead><tr><th>Team</th><th class="r">Incidents</th><th class="r">Toil</th><th class="r">Committed h/mo</th><th class="r">Verified h/mo</th><th class="r">AI spend</th><th>Updated</th></tr></thead><tbody>${S.exec.map(t => `<tr><td>${esc(t.team.name)}</td><td class="r num">${t.summary ? fmt(t.summary.kpis.incidents, 0) : '—'}</td><td class="r num">${t.summary ? t.summary.kpis.toilPct + '%' : '—'}</td><td class="r num">${fmt(t.ledger.hoursSavedProjectedPerMonth, 0)}</td><td class="r num">${fmt(t.ledger.hoursSavedVerifiedPerMonth, 0)}</td><td class="r num">$${fmt(t.ledger.aiCostUsd, 2)}</td><td class="small muted">${t.summary ? dt(t.summary.at) : '—'}</td></tr>`).join('')}</tbody></table></div>` : '';
    const hoursTable = (title, map) => { const rows = Object.entries(map || {}).sort((x, y) => (y[1].technical + y[1].business) - (x[1].technical + x[1].business)).slice(0, 8); const max = Math.max.apply(null, rows.map(r => r[1].technical + r[1].business).concat([1])); return rows.length ? `<div class="panel"><h3>${title}</h3><div class="ladder" style="grid-template-columns:140px 1fr 130px">${rows.map(([k2, b]) => `<div class="name" title="${esc(k2)}">${esc(k2)}</div><div class="bar"><i style="width:${100 * b.technical / max}%;display:inline-block"></i><i class="tint" style="width:${100 * b.business / max}%;display:inline-block"></i></div><div class="r num small">${fmt(b.technical, 0)} + ${fmt(b.business, 0)} h</div>`).join('')}</div><div class="legend"><span><i style="background:var(--plum)"></i>Technical</span><span><i style="background:var(--tint-3)"></i>Business</span></div></div>` : ''; };
    const hasComp = a && Object.keys(a.byComponent || {}).some(k2 => k2 !== 'unassigned');
    const where = a ? `<div class="cols">${hoursTable('Where the hours go, by category', a.byCategory)}${hasComp ? hoursTable('By component', a.byComponent) : ''}</div>` : '';
    $('#execBody').innerHTML = chain + kpis + `<div class="cols">${ladder}${weekly || wi}</div>` + (weekly && wi ? `<div class="cols">${wi}${topT}</div>` : topT) + where + teams;
    const r = $('#whatIf'); if (r) r.oninput = e => { S.whatIf = +e.target.value; const p = cands.slice(0, S.whatIf); $('#wiN').textContent = S.whatIf; $('#wiH').textContent = fmt(p.reduce((s, c) => s + c.savings.hoursPerMonth, 0), 0) + ' h/mo'; $('#wiU').textContent = money(p.reduce((s, c) => s + c.savings.usdPerYear, 0)) + ' per year'; $('#wiL').textContent = p.map(c => c.name).join(' · '); };
    $$('#execBody tr.click').forEach(tr => tr.onclick = () => openOffender(tr.dataset.id));
  }
  function svgWeekly(a) {
    const W = 520, H = 130, pad = 22, n = a.weeks.length, max = Math.max.apply(null, a.weeklyTotal.concat([1]));
    const bw = Math.max(2, (W - pad * 2) / n - 2);
    let s = `<svg viewBox="0 0 ${W} ${H}" width="100%" height="${H}" role="img" aria-label="weekly incidents">`;
    a.weeks.forEach((w, i) => { const x = pad + i * ((W - pad * 2) / n); const ht = (H - 30) * a.weeklyTotal[i] / max, hl = (H - 30) * a.weeklyToil[i] / max; s += `<rect x="${x}" y="${H - 20 - ht}" width="${bw}" height="${ht}" fill="var(--tint-3)"/><rect x="${x}" y="${H - 20 - hl}" width="${bw}" height="${hl}" fill="var(--plum)"><title>${w}: ${a.weeklyTotal[i]} incidents, ${a.weeklyToil[i]} toil</title></rect>`; if (i === 0 || i === n - 1 || i % Math.ceil(n / 6) === 0) s += `<text x="${x}" y="${H - 6}" font-size="10" fill="var(--ink-2)">${w.slice(5)}</text>`; });
    s += `<text x="${pad}" y="12" font-size="10" fill="var(--ink-2)">${max}/wk</text></svg>`;
    return s;
  }
  function spark(vals, w, h) { w = w || 90; h = h || 22; if (!vals || !vals.length) return ''; const max = Math.max.apply(null, vals.concat([1])); const pts = vals.map((v, i) => `${(i / Math.max(1, vals.length - 1) * (w - 2) + 1).toFixed(1)},${(h - 1 - (h - 2) * v / max).toFixed(1)}`).join(' '); return `<svg class="spark" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><polyline points="${pts}" fill="none" stroke="var(--plum)" stroke-width="1.5"/></svg>`; }
  function stateTag(st) { return `<span class="tag st-${st}">${C.STATE_LABEL[st] || st}</span>`; }

  // Offenders
  function renderOffenders() {
    const a = S.analysis; const t = $('#offTable');
    if (!a) { t.innerHTML = `<tbody><tr><td class="empty">Load data to see patterns.</td></tr></tbody>`; return; }
    const catSel = $('#offCat'); if (catSel.options.length <= 1) catSel.innerHTML = '<option value="">All categories</option>' + Object.keys(a.byCategory).sort().map(c => `<option>${esc(c)}</option>`).join('');
    const stSel = $('#offState'); if (stSel.options.length <= 2) stSel.innerHTML += C.STATES.map(s => `<option value="${s}">${C.STATE_LABEL[s]}</option>`).join('');
    const q = $('#offSearch').value.toLowerCase(), cat = catSel.value, stv = stSel.value, toilOnly = $('#offToil').checked, unk = $('#offUnknown').checked;
    let rows = a.clusters.filter(c => (!toilOnly || c.flags.toil) && (!unk || !c.known) && (!cat || c.category === cat) && (!q || c.name.toLowerCase().includes(q) || c.masked.includes(q)) && (!stv || (stv === 'untracked' ? !S.ledger.offenders[c.id] : (S.ledger.offenders[c.id] || {}).state === stv)));
    const [key, dir] = S.sort.off;
    const val = c => ({ rank: a.clusters.indexOf(c) * -1, name: c.name, category: c.category, count: c.count, perMonth: c.perMonth, score: c.score, saves: c.savings.hoursPerMonth, state: (S.ledger.offenders[c.id] || {}).state || '' })[key];
    rows.sort((x, y) => { const p = val(x), q2 = val(y); return (typeof p === 'number' ? p - q2 : String(p).localeCompare(String(q2))) * (key === 'rank' ? -1 : 1) * dir; });
    S._offRows = rows;
    const th = (k, l, cls) => `<th class="${cls || ''} ${key === k ? 'sorted' : ''}" data-k="${k}">${l}${key === k ? (dir > 0 ? ' ↑' : ' ↓') : ''}</th>`;
    t.innerHTML = `<thead><tr>${th('rank', '#')}${th('name', 'Pattern')}${th('category', 'Category')}${th('count', 'Count', 'r')}${th('perMonth', '/mo', 'r')}<th>Trend</th>${th('score', 'Score', 'r')}<th>Disposition</th>${th('state', 'State')}${th('saves', 'Saves h/mo', 'r')}</tr></thead><tbody>${rows.map(c => { const o = S.ledger.offenders[c.id]; return `<tr class="click ${S.selected === c.id ? 'sel' : ''}" data-id="${esc(c.id)}"><td class="num muted">${a.clusters.indexOf(c) + 1}</td><td class="name" title="${esc(c.masked)}">${esc(c.name)} ${c.known ? '' : '<span class="tag unknown">unknown</span>'}</td><td>${esc(c.category)}</td><td class="r num">${c.count}</td><td class="r num">${fmt(c.perMonth)}</td><td>${spark(c.weekly.slice(-12))}</td><td class="r num"><span class="scorebar"><i style="width:${c.score}%"></i></span> ${c.score}</td><td>${C.DISPOSITION_LABEL[c.disposition] || c.disposition}</td><td>${o ? stateTag(o.state) : '<span class="muted small">—</span>'}</td><td class="r num">${fmt(c.savings.hoursPerMonth)}</td></tr>`; }).join('') || '<tr><td colspan="10" class="muted">Nothing matches these filters.</td></tr>'}</tbody>`;
    $$('#offTable th[data-k]').forEach(h => h.onclick = () => { const k = h.dataset.k; S.sort.off = [k, S.sort.off[0] === k ? -S.sort.off[1] : 1]; renderOffenders(); });
    $$('#offTable tr.click').forEach(tr => tr.onclick = () => openOffender(tr.dataset.id));
  }

  // Incidents
  function renderIncidents() {
    const t = $('#incTable'); const a = S.analysis;
    if (!S.raw) { t.innerHTML = `<tbody><tr><td class="empty">Load data first.</td></tr></tbody>`; $('#mapping').innerHTML = ''; $('#incMeta').textContent = ''; return; }
    $('#mapping').innerHTML = C.FIELDS.map(f => `<div><label class="f">${C.FIELD_LABEL[f]}</label><select data-f="${f}"><option value="">—</option>${S.raw.headers.map(h => `<option ${S.mapping[f] === h ? 'selected' : ''}>${esc(h)}</option>`).join('')}</select></div>`).join('');
    const sigSel = $('#incSig'); if (a && sigSel.options.length <= 1) sigSel.innerHTML = '<option value="">All patterns</option>' + a.clusters.map(c => `<option value="${esc(c.id)}">${esc(c.name.slice(0, 70))} (${c.count})</option>`).join('');
    const q = $('#incSearch').value.toLowerCase(), sid = sigSel.value;
    const rows = S.incidents.filter(i => (!sid || i._sig === sid) && (!q || (i.short + ' ' + i.description + ' ' + i.number + ' ' + i.ci + ' ' + i.group).toLowerCase().includes(q)));
    S._incRows = rows;
    $('#incMeta').textContent = `${fmt(rows.length, 0)} of ${fmt(S.incidents.length, 0)} shown${rows.length > 500 ? ' (first 500 rendered)' : ''}`;
    t.innerHTML = `<thead><tr><th>Number</th><th>Opened</th><th>Short description</th><th>Pattern</th><th>CI</th><th>Group</th><th class="r">Tech h</th><th class="r">Biz h</th></tr></thead><tbody>${rows.slice(0, 500).map(i => `<tr class="click" data-id="${esc(i._sig || '')}"><td class="mono">${esc(i.number)}</td><td class="small">${i.opened ? esc(i.opened.toISOString().slice(0, 16).replace('T', ' ')) : ''}</td><td class="name" title="${esc(i.description)}">${esc(i.short)}</td><td class="small muted">${esc((cluster(i._sig) || {}).name || '').slice(0, 50)}</td><td class="small">${esc(i.ci)}</td><td class="small">${esc(i.group)}</td><td class="r num">${fmt(i._tech, 2)}</td><td class="r num">${fmt(i._biz, 1)}</td></tr>`).join('')}</tbody>`;
    $$('#incTable tr.click').forEach(tr => tr.onclick = () => tr.dataset.id && openOffender(tr.dataset.id));
  }

  // Ledger
  function renderLedger() {
    const t = $('#ledgerTable'); const os = Object.values(S.ledger.offenders);
    if (!os.length) { t.innerHTML = `<tbody><tr><td class="empty">Nothing tracked yet. Toil candidates register here automatically when data is analyzed.</td></tr></tbody>`; return; }
    const [key, dir] = S.sort.led;
    const savesOf = o => o.baseline ? o.baseline.perMonth * (o.baseline.techPerInc + o.baseline.bizPerInc) * (C.DISPOSITIONS[o.disposition] || 0) : 0;
    const val = o => ({ state: C.STATES.indexOf(o.state), name: o.name, disposition: o.disposition, jira: o.jira, baseline: o.baseline ? o.baseline.perMonth : 0, latest: o.latest ? o.latest.perMonth : 0, saves: savesOf(o), updated: o.history[o.history.length - 1].at })[key];
    os.sort((x, y) => { const p = val(x), q = val(y); return (typeof p === 'number' ? p - q : String(p).localeCompare(String(q))) * dir; });
    const th = (k, l, cls) => `<th class="${cls || ''} ${key === k ? 'sorted' : ''}" data-k="${k}">${l}${key === k ? (dir > 0 ? ' ↑' : ' ↓') : ''}</th>`;
    t.innerHTML = `<thead><tr>${th('state', 'State')}${th('name', 'Pattern')}${th('disposition', 'Disposition')}${th('jira', 'Jira')}<th>Owner</th>${th('baseline', 'Baseline /mo', 'r')}${th('latest', 'Latest /mo', 'r')}${th('saves', 'Saves h/mo', 'r')}${th('updated', 'Updated')}</tr></thead><tbody>${os.map(o => `<tr class="click" data-id="${esc(o.id)}"><td>${stateTag(o.state)}</td><td class="name">${esc(o.name)}</td><td>${C.DISPOSITION_LABEL[o.disposition] || o.disposition}</td><td class="mono">${esc(o.jira)}</td><td class="small">${esc(o.owner)}</td><td class="r num">${o.baseline ? fmt(o.baseline.perMonth) : '—'}</td><td class="r num">${o.latest ? fmt(o.latest.perMonth) : '—'}</td><td class="r num">${fmt(savesOf(o))}</td><td class="small muted">${dt(o.history[o.history.length - 1].at)}</td></tr>`).join('')}</tbody>`;
    $$('#ledgerTable th[data-k]').forEach(h => h.onclick = () => { const k = h.dataset.k; S.sort.led = [k, S.sort.led[0] === k ? -S.sort.led[1] : 1]; renderLedger(); });
    $$('#ledgerTable tr.click').forEach(tr => tr.onclick = () => openOffender(tr.dataset.id));
  }

  // Signatures
  function renderSignatures() {
    const a = S.analysis; const hits = id => a ? ((a.clusters.find(c => c.id === id) || {}).count || 0) : '—';
    $('#sigTable').innerHTML = `<thead><tr><th>Id</th><th>Name</th><th>Category</th><th class="r">Hits in data</th><th>Disposition</th><th>Regex</th><th>Owner</th></tr></thead><tbody>${S.catalog.map(s => `<tr><td class="mono">${esc(s.id)}</td><td>${esc(s.name)}</td><td>${esc(s.category)}</td><td class="r num">${hits(s.id)}</td><td>${C.DISPOSITION_LABEL[s.disposition] || esc(s.disposition || '')}</td><td class="mono" style="max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(s.match.regex)}">${esc(s.match.regex)}</td><td class="small">${esc(s.owner || '')}</td></tr>`).join('')}</tbody>`;
    $('#proposedList').innerHTML = S.proposed.length ? `<table><thead><tr><th>Id</th><th>Name</th><th>From</th><th>Regex</th><th>Evidence</th></tr></thead><tbody>${S.proposed.map(s => `<tr><td class="mono">${esc(s.id)}</td><td>${esc(s.name)}</td><td>${esc(s.proposedFrom || '')}</td><td class="mono">${esc(s.match.regex)}</td><td class="small">${s.evidence ? `${s.evidence.count} incidents, ${s.evidence.perMonth}/mo` : ''}</td></tr>`).join('')}</tbody></table>` : (S.mode === 'connected' ? 'None pending. Propose one from an unknown offender.' : 'Proposals are written to the repo in Connected mode; in Lite mode they download as JSON to attach to an MR.');
  }

  // Report
  function renderReport() {
    if (!S.analysis) { $('#reportMd').textContent = 'Load data to generate a report.'; $('#reportMeta').textContent = ''; $('#metricsPreview').textContent = ''; return; }
    const md = C.renderReport(S.analysis, S.ledger, S.team); S._report = md;
    $('#reportMd').textContent = md; $('#reportMeta').textContent = `${S.team.name} · ${S.fileName} · ${C.weekKey(new Date())}`;
    S._lines = C.metricsLines(S.analysis, S.ledger, S.team); $('#metricsPreview').textContent = S._lines.join('\n');
  }

  // Settings
  function renderSettings() {
    const hm = S.team.hoursModel || {};
    $('#setRateT').value = (hm.rates || {}).technical || 85; $('#setRateB').value = (hm.rates || {}).business || 60;
    $('#setThreshold').value = (S.team.toil || {}).threshold || 60; $('#setRepMin').value = (S.team.toil || {}).repetitiveMin || 5;
    $('#teamJson').value = JSON.stringify(S.team, null, 2); $('#teamMsg').textContent = '';
    $('#teamSrc').textContent = S.mode === 'connected' ? `teams/${S.team.id}/team.json — saved to the repo, share by merge request.` : 'Edits stay in this browser. Download and add to teams/<id>/team.json to share.';
    $('#obIntro').textContent = S.mode === 'connected' ? 'Pick groups and CIs from a loaded export, preview the team\'s top offenders, then open a merge request that adds the team.' : 'Pick groups and CIs from a loaded export, preview the team\'s top offenders, then download team.json to add through a merge request.';
    const st = S.status;
    $('#runInfo').innerHTML = S.mode === 'connected' ? `<div>Server ${esc(st.root)} · Node ${esc(st.node)} · branch ${esc((st.git || {}).branch || '?')}</div><div>Claude CLI: ${st.claude.bin ? esc(st.claude.bin) : '<b>not found</b> (set CLAUDE_BIN)'}</div><div>ServiceNow: ${st.env.servicenow ? 'configured' : 'not configured (SN_INSTANCE + SN_TOKEN or SN_USER/SN_PASS in .env)'}</div><div>Dynatrace: ${st.env.dynatrace ? 'configured' : 'not configured (DT_URL + DT_TOKEN in .env)'}</div><div>GitLab MRs: ${st.env.gitlabToken ? 'API token' : st.glab ? 'glab CLI' : 'link only (set GITLAB_TOKEN)'}</div><div>Jira sync: ${st.env.jira ? 'configured' : 'not configured (JIRA_URL + JIRA_TOKEN in .env)'}</div>` : `<div>Lite mode: opened as a file. Claude, ServiceNow, Dynatrace and git actions need <span class="mono">npm start</span> in the repo clone.</div><div>Catalog: ${S.catalog.length} signatures embedded at build time.</div>`;
  }

  // ---------- Drawer ----------
  function openOffender(id) {
    const c = cluster(id); const o = S.ledger.offenders[id];
    if (!c && !o) return;
    S.selected = id;
    const name = c ? c.name : o.name, cat = c ? c.category : o.category, disp = (o && o.disposition) || (c && c.disposition);
    const parts = c ? Object.entries(c.scoreParts).map(([k, v]) => `<div>${k}</div><div class="bar"><i style="width:${v * 100}%"></i></div><div class="num">${Math.round(v * 100)}</div>`).join('') : '';
    const sav = c ? C.projectSavings(c, S.team, disp) : null;
    const next = { detected: ['ticketed', 'accepted'], ticketed: ['fixed', 'accepted', 'detected'], fixed: ['verified', 'regressed', 'ticketed'], verified: ['regressed'], regressed: ['ticketed', 'accepted'], accepted: ['detected'] }[o ? o.state : 'detected'] || [];
    const ai = o && o.ai && o.ai.lastVerdict ? verdictHtml(o.ai.lastVerdict, o.ai) : '';
    $('#drawerBody').innerHTML = `
      <h2>${esc(name)}</h2>
      <div class="row" style="margin:6px 0 10px"><span class="tag">${esc(cat)}</span>${c && c.component && c.component !== 'unassigned' ? `<span class="tag">${esc(c.component)}</span>` : ''}${c && !c.known ? '<span class="tag unknown">unknown pattern</span>' : c ? `<span class="tag">${esc(c.catalogId)}</span>` : ''}${o ? stateTag(o.state) : '<span class="tag">not tracked</span>'}${c ? `<span class="muted small">${c.count} incidents · ${fmt(c.perMonth)}/mo · first ${dt(c.firstSeen)} · last ${dt(c.lastSeen)}</span>` : ''}</div>
      ${c ? `<div class="section"><div class="row between"><div><h3>Toil score ${c.score}</h3><div class="parts">${parts}</div></div><div>${spark(c.weekly.slice(-16), 160, 44)}<div class="small muted">last 16 weeks</div></div></div>${c.automationHint ? `<p class="small" style="margin-top:8px"><b>Catalog hint:</b> ${esc(c.automationHint)}</p>` : ''}</div>` : ''}
      <div class="section"><h3>Disposition and value</h3>
        <div class="row"><select id="dDisp">${Object.keys(C.DISPOSITIONS).map(d => `<option value="${d}" ${disp === d ? 'selected' : ''}>${C.DISPOSITION_LABEL[d]} (${Math.round(C.DISPOSITIONS[d] * 100)}%)</option>`).join('')}</select>
        ${sav ? `<span class="num"><b>${fmt(sav.hoursPerMonth)}</b> h/mo · <b>${money(sav.usdPerYear)}</b>/yr</span>` : ''}</div>
        ${c ? `<div class="small muted" style="margin-top:6px">Per incident: ${fmt(c.hours.techPerInc, 2)} h technical, ${fmt(c.hours.bizPerInc, 1)} h business${c.hours.elapsedSamples ? ` (business from opened→resolved on ${c.hours.elapsedSamples} incidents)` : ' (team defaults)'}</div>` : ''}
        ${o && o.baseline ? `<div class="row small" style="margin-top:8px"><span class="muted">Savings measured against a baseline of ${fmt(o.baseline.perMonth)} a month, set ${dt(o.baseline.at)}${o.baseline.rebaselined ? ' by a rebaseline' : ''}</span>${c ? '<button class="btn sm" id="dRebase">Rebaseline</button>' : ''}</div>` : ''}
      </div>
      <div class="section"><h3>Kill chain</h3>
        <div class="grid2"><div><label class="f">Jira</label><input type="text" id="dJira" value="${esc(o ? o.jira : '')}" placeholder="${esc(((S.team.jira || {}).projectKey || 'SRE') + '-123')}"></div><div><label class="f">Owner</label><input type="text" id="dOwner" value="${esc(o ? o.owner : '')}"></div></div>
        <label class="f" style="margin-top:6px">Note for this move</label><input type="text" id="dNote" style="width:100%">
        <div class="states">${o ? next.map(s => `<button class="btn sm" data-st="${s}">${s === 'accepted' ? 'Accept as is' : 'Mark ' + C.STATE_LABEL[s]}</button>`).join('') : '<button class="btn sm primary" data-st="track">Track this pattern</button>'}</div>
        ${o && o.windows && o.windows.length ? `<div class="small muted" style="margin-top:8px">Since fix: ${o.windows.map(w => `${dt(w.start)} ${w.count}`).join(' · ')} (need 2 clean weeks)</div>` : ''}
        ${o ? `<details style="margin-top:8px"><summary class="small">History (${o.history.length})</summary>${o.history.map(h => `<div class="small">${h.at.slice(0, 16).replace('T', ' ')} · ${h.action === 'rebaseline' ? 'Baseline changed' : (h.from ? C.STATE_LABEL[h.from] + ' → ' : '') + C.STATE_LABEL[h.state]} · ${esc(h.by)}${h.note ? ' · ' + esc(h.note) : ''}</div>`).join('')}</details>` : ''}
      </div>
      <div class="section"><h3>Analysis${o && o.ai && o.ai.runs ? ` <span class="muted small">(${o.ai.runs} run${o.ai.runs > 1 ? 's' : ''}, $${fmt(o.ai.costUsd, 2)})</span>` : ''}</h3>
        <div class="row">${S.mode === 'connected' && c ? `<button class="btn primary sm" id="dAnalyze">Analyze with Claude</button><label class="check small"><input type="checkbox" id="dForce"> ignore cache</label>` : ''}${c ? `<button class="btn sm" id="dPacket">Copy packet</button>` : ''}<button class="btn sm" id="dPaste">Paste verdict</button></div>
        <div id="dLive" class="live ${S._live[id] ? '' : 'hide'}" style="margin-top:8px">${S._live[id] || ''}</div>
        <div id="dVerdict" style="margin-top:8px">${ai}</div>
      </div>
      ${c ? `<div class="section"><h3>Samples</h3><label class="check small"><input type="checkbox" id="dMasked"> show masked</label>${c.samples.map(s => `<div class="sample"><span class="mono">${esc(s.number)}</span> <span class="muted small">${dt(s.opened)}${s.ci ? ' · ' + esc(s.ci) : ''}</span><div class="raw">${esc(s.short)}</div><div class="m hide">${esc(s.masked)}</div>${s.notes ? `<div class="small muted">↳ ${esc(s.notes)}</div>` : ''}</div>`).join('')}
        <div class="small muted" style="margin-top:8px">Groups: ${Object.entries(c.groups).map(([g, n]) => `${esc(g)} (${n})`).join(', ') || '—'}<br>CIs: ${Object.entries(c.cis).slice(0, 6).map(([g, n]) => `${esc(g)} (${n})`).join(', ') || '—'}</div></div>
      <div class="section"><div class="row"><button class="btn sm" id="dExport">Export ${c.count} incidents</button>${!c.known ? `<button class="btn sm lime" id="dPropose">Propose signature</button>` : ''}</div></div>` : ''}`;
    $('#drawer').classList.add('open');
    // wiring
    if ($('#dRebase')) $('#dRebase').onclick = () => rebaselineModal(id);
    $('#dDisp').onchange = e => { if (o) { o.disposition = e.target.value; saveLedger(); } if (c) { c.disposition = e.target.value; c.savings = C.projectSavings(c, S.team, c.disposition); } openOffender(id); render(); };
    $$('#drawerBody [data-st]').forEach(b => b.onclick = () => {
      const st = b.dataset.st, jira = $('#dJira').value.trim(), owner = $('#dOwner').value.trim(), note = $('#dNote').value.trim();
      if (st === 'track') { C.registerOffender(S.ledger, c, { by: 'ui', note: note || 'tracked manually' }); }
      else { if (st === 'ticketed' && !jira && !confirm('No Jira key entered. Mark Ticketed anyway?')) return; const ev = C.transition(S.ledger, id, st, { jira, owner, note, by: 'ui' }); queueBizevent(ev); }
      saveLedger(); openOffender(id); render(); toast(st === 'track' ? 'Tracking' : 'Marked ' + C.STATE_LABEL[st]);
    });
    const jiraEl = $('#dJira'), ownerEl = $('#dOwner'); [jiraEl, ownerEl].forEach(el => el.onchange = () => { if (o) { o.jira = jiraEl.value.trim(); o.owner = ownerEl.value.trim(); saveLedger(); render(); } });
    if ($('#dMasked')) $('#dMasked').onchange = e => $$('#drawerBody .sample').forEach(s => { s.querySelector('.raw').classList.toggle('hide', e.target.checked); s.querySelector('.m').classList.toggle('hide', !e.target.checked); });
    if ($('#dPacket')) $('#dPacket').onclick = () => copy(JSON.stringify(C.buildPacket(c, S.team, S.analysis), null, 2));
    if ($('#dExport')) $('#dExport').onclick = () => download(`${S.team.id}-${id}.csv`, C.toCSV(c.incidents.map(i => S.incidents[i].raw), S.raw.headers), 'text/csv');
    if ($('#dPropose')) $('#dPropose').onclick = () => proposeModal(c);
    if ($('#dAnalyze')) $('#dAnalyze').onclick = () => analyzeWithClaude(c, $('#dForce').checked);
    $('#dPaste').onclick = () => {
      const root = $('#modalRoot');
      root.innerHTML = `<div class="overlay"><div class="modal"><h2>Paste a verdict</h2><p class="muted small">Run <span class="mono">/toil-analyzer:offender</span> in Claude Code with the copied packet and paste its JSON here. Fences are fine.</p><textarea id="pvText" class="mono" style="min-height:220px" placeholder='{"disposition":"automate", ...}'></textarea><div class="row" style="margin-top:10px"><button class="btn primary" id="pvApply">Apply verdict</button><button class="btn" id="pvCancel">Cancel</button><span id="pvMsg" class="small muted"></span></div></div></div>`;
      $('#pvCancel').onclick = () => root.innerHTML = '';
      $('#pvApply').onclick = () => { const v = C.parseVerdict($('#pvText').value); if (!v || !v.disposition) { $('#pvMsg').textContent = 'That is not a verdict JSON (needs at least "disposition").'; return; } root.innerHTML = ''; applyVerdict(id, v, { usd: 0, turns: 0, model: 'manual' }); toast('Verdict applied'); };
      $('#pvText').focus();
    };
    if (o && o.ai && o.ai.lastVerdict) wireVerdict(id, o.ai.lastVerdict);
    $('#drawerBody').scrollTop = 0;
  }
  function verdictHtml(v, ai) {
    return `<div class="verdict"><div class="row between"><b>${C.DISPOSITION_LABEL[v.disposition] || esc(v.disposition)} · ${Math.round((v.confidence || 0) * 100)}% confidence</b><span class="small muted">${ai && ai.at ? dt(ai.at) : ''}${ai && ai.model ? ' · ' + esc(ai.model) : ''}</span></div>
      <dl><dt>Root cause</dt><dd>${esc(v.root_cause)}</dd><dt>Fix (${esc(v.fix_type)}${v.hours_est ? ', ~' + fmt(v.hours_est, 0) + ' h' : ''})</dt><dd>${esc(v.fix_summary)}</dd>${v.evidence && v.evidence.length ? `<dt>Evidence</dt><dd>${v.evidence.map(e => '• ' + esc(e)).join('<br>')}</dd>` : ''}${v.risks && v.risks.length ? `<dt>Risks</dt><dd>${v.risks.map(e => '• ' + esc(e)).join('<br>')}</dd>` : ''}</dl>
      <div class="row" style="margin-top:8px"><button class="btn sm" id="vApply">Use disposition</button><button class="btn sm" id="vJira">Copy Jira text</button></div></div>`;
  }
  function applyVerdict(id, v, cost) {
    const o = S.ledger.offenders[id] || (cluster(id) && C.registerOffender(S.ledger, cluster(id), { by: 'ui', note: 'tracked after analysis' }));
    if (!o) return;
    o.ai = o.ai || { runs: 0, costUsd: 0 }; o.ai.lastVerdict = v; o.ai.at = new Date().toISOString(); o.ai.model = cost.model;
    if (S.mode === 'lite' || isPreview()) { o.ai.runs++; o.ai.costUsd = +(o.ai.costUsd + (cost.usd || 0)).toFixed(4); }
    saveLedger(); openOffender(id);
  }
  function wireVerdict(id, v) {
    const c = cluster(id), o = S.ledger.offenders[id];
    if ($('#vApply')) $('#vApply').onclick = () => { if (o) o.disposition = v.disposition; if (c) { c.disposition = v.disposition; c.savings = C.projectSavings(c, S.team, v.disposition); } saveLedger(); openOffender(id); render(); toast('Disposition set to ' + C.DISPOSITION_LABEL[v.disposition]); };
    if ($('#vJira')) $('#vJira').onclick = () => copy(`${v.jira_title || o.name}\n\n${v.jira_description || v.fix_summary}\n\nRoot cause: ${v.root_cause}\nDisposition: ${v.disposition} (${Math.round((v.confidence || 0) * 100)}%)\nPattern: ${o ? o.name : id}${c ? `\nVolume: ${c.count} incidents, ${fmt(c.perMonth)}/month, saves ~${fmt(c.savings.hoursPerMonth)} h/month` : ''}\nSource: toil-analyzer`);
  }
  function liveAppend(id, html) { S._live[id] = (S._live[id] || '') + html; const el = $('#dLive'); if (el && S.selected === id) { el.classList.remove('hide'); el.innerHTML = S._live[id]; el.scrollTop = el.scrollHeight; } }
  async function analyzeWithClaude(c, force) {
    S._live[c.id] = ''; liveAppend(c.id, '<span class="t">starting claude…</span>\n'); $('#dAnalyze').disabled = true;
    if (!S.ledger.offenders[c.id]) { C.registerOffender(S.ledger, c, { by: 'ui', note: 'tracked for analysis' }); saveLedger(); }
    const packet = C.buildPacket(c, S.team, S.analysis);
    try {
      const res = await fetch('/api/analyze', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ team: S.team.id, packet, force }) });
      const reader = res.body.getReader(), dec = new TextDecoder(); let buf = '', final = null;
      while (true) {
        const { value, done } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true }); let i;
        while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (!line) continue; const m = safeJSON(line, null); if (!m) continue;
          if (m.type === 'event') liveAppend(c.id, liveLine(m.event)); else if (m.type === 'result') final = m; else if (m.type === 'error') liveAppend(c.id, `<span class="t">error:</span> ${esc(m.message)}\n`); else if (m.type === 'start') liveAppend(c.id, `<span class="t">model ${esc(m.model)}</span>\n`); }
      }
      if (final) {
        liveAppend(c.id, `<span class="t">${final.cached ? 'from cache' : `done · $${fmt(final.cost.usd, 3)} · ${final.cost.turns} turns · ${fmt(final.cost.durationMs / 1000, 0)}s`}</span>\n`);
        { const disk = await api('GET', '/api/ledger/' + S.team.id); if (isPreview()) S.ledger.ai = disk.ai; else adoptLedger(disk); }
        if (final.verdict) { applyVerdict(c.id, final.verdict, final.cost); toast('Analysis ready'); } else toast('Claude answered but not with a JSON verdict — see the live pane.', true);
        if (!final.verdict && final.raw) liveAppend(c.id, esc(final.raw) + '\n');
      }
    } catch (e) { liveAppend(c.id, `<span class="t">failed:</span> ${esc(e.message)}\n`); toast(e.message, true); }
    const b = $('#dAnalyze'); if (b) b.disabled = false; render();
  }
  function liveLine(ev) {
    if (ev.type === 'assistant') return ev.content.map(c => c.type === 'text' ? esc(c.text) + '\n' : c.type === 'tool_use' ? `<span class="t">→ ${esc(c.name)}</span> ${esc(c.input)}\n` : '').join('');
    if (ev.type === 'tool_result') return `<span class="t">← tool result</span>\n`;
    if (ev.type === 'system') return `<span class="t">session ${esc(ev.subtype || '')}</span>\n`;
    return '';
  }

  // ---------- Load checks: status line, preview banner, save or discard ----------
  function loadStatus() {
    const a = S.analysis; if (!a || !S.load) return 'No data loaded';
    const i = S.load.info || {}, parts = [`${S.load.demo ? 'Demo data' : S.fileName} · ${fmt(a.kpis.incidents, 0)} incidents · ${dt(a.kpis.from)} to ${dt(a.kpis.to)}`];
    if (S.load.demo) parts.push('not saved');
    else {
      if (i.excluded) parts.push(`${fmt(i.excluded, 0)} not this team's`);
      if (i.duplicates) parts.push(`${fmt(i.duplicates, 0)} duplicates dropped`);
      if (isPreview()) parts.push('not saved yet');
    }
    return parts.join(' · ');
  }
  function renderLoadBanner() {
    const el = $('#loadBanner'); if (!el) return;
    const show = isPreview() && !S.load.demo;
    el.classList.toggle('hide', !show);
    if (!show) { el.innerHTML = ''; return; }
    const i = S.load.info, who = esc(S.team.name || S.team.id), none = i.scoped && i.kept === 0;
    const onboard = S.load.check.reasons.some(r => r.code === 'unscoped') || (i.unowned > 0 && i.unowned >= 0.25 * i.unique);
    el.innerHTML = `<h3>Nothing from this load is saved yet</h3>${S.load.check.reasons.map(r => `<p class="small">${esc(r.text)}</p>`).join('')}
      <p class="small muted">${none ? `None of these incidents belong to ${who}. Pick the owning team from the team list, or onboard a new team.` : `Check the numbers, then save the kept incidents to ${who}'s ledger or discard the load.`}</p>
      <div class="row">${none ? '' : '<button class="btn primary" id="lbSave">Save to ledger</button>'}<button class="btn" id="lbDiscard">Discard load</button>${onboard ? '<button class="btn" id="lbOnboard">Onboard a team from this data</button>' : ''}</div>`;
    if ($('#lbSave')) $('#lbSave').onclick = confirmLoad;
    $('#lbDiscard').onclick = discardLoad;
    if ($('#lbOnboard')) $('#lbOnboard').onclick = () => onboardModal();
  }
  function confirmLoad() {
    if (!S.load) return;
    S.load.confirmed = true;
    S._events = S._events.concat(S._previewEvents || []); S._previewEvents = [];
    announce(S._pendingEvents); S._pendingEvents = [];
    saveLedger();
    if (S.mode === 'connected' && S.analysis) api('PUT', '/api/summary/' + S.team.id, execSummary()).catch(() => {});
    render(); toast(`Saved to ${S.team.name || S.team.id}'s ledger`);
  }
  function discardLoad() {
    S.ledger = clone(S.baseLedger);
    S.raw = null; S.norm = []; S.allIncidents = []; S.incidents = []; S.analysis = null; S.load = null; S.fileName = '';
    S._pendingEvents = []; S._previewEvents = [];
    $('#drawer').classList.remove('open'); S.selected = null;
    render(); toast('Load discarded. Nothing was saved.');
  }
  function blockedByPreview() {
    if (!isPreview()) return false;
    toast(S.load.demo ? 'Demo data is never saved, so this is off while it is loaded.' : 'Save or discard this load first.', true);
    return true;
  }

  // ---------- Rebaseline ----------
  function rebaselineModal(id) {
    const o = S.ledger.offenders[id]; if (!o) return;
    const r = C.baselineFrom(o, S.analysis, S.incidents), b = o.baseline, root = $('#modalRoot');
    root.innerHTML = `<div class="overlay"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="rbTitle"><h2 id="rbTitle">Rebaseline ${esc(o.name)}</h2>
      <p class="muted small">Savings are measured against the baseline, which is set the first time a pattern is tracked. If that load was wrong, for example stitched exports or another team's incidents, set it again from the data loaded now.</p>
      <div class="grid2">
        <div><label class="f">Current baseline</label><div><b class="num">${b ? fmt(b.perMonth) : 'None'}</b>${b ? ' a month' : ''}</div><div class="small muted">${b ? `Set ${dt(b.at)} from ${fmt(b.count, 0)} incidents` : 'Not set yet'}</div></div>
        <div><label class="f">From this load</label>${r.error ? `<div class="small">${esc(r.error)}</div>` : `<div><b class="num">${fmt(r.baseline.perMonth)}</b> a month</div><div class="small muted">${fmt(r.baseline.count, 0)} incidents, ${dt(r.window.from)} to ${dt(r.window.to)}${r.window.preFix ? ', before the fix' : ''}</div>`}</div>
      </div>
      ${r.error ? '' : '<label class="f" for="rbNote" style="margin-top:14px">Reason, kept in the history</label><input type="text" id="rbNote" style="width:100%" placeholder="First load had overlapping exports">'}
      <div class="row" style="margin-top:12px">${r.error ? '' : '<button class="btn primary" id="rbGo">Rebaseline</button>'}<button class="btn" id="rbCancel">Cancel</button></div>
      <div id="rbOut" class="small warnline" style="margin-top:8px"></div></div></div>`;
    $('#rbCancel').onclick = () => { root.innerHTML = ''; };
    if (!$('#rbGo')) return;
    $('#rbGo').onclick = () => {
      const note = $('#rbNote').value.trim();
      if (!note) { $('#rbOut').textContent = 'Add a reason first.'; $('#rbNote').focus(); return; }
      try {
        const res = C.rebaseline(S.ledger, id, S.analysis, S.incidents, { note, by: 'ui' });
        saveLedger(); root.innerHTML = ''; openOffender(id); render();
        toast(`Baseline set to ${fmt(res.baseline.perMonth)} a month${isPreview() ? '. Save the load to keep it.' : ''}`);
      } catch (e) { $('#rbOut').textContent = e.message; }
    };
    $('#rbNote').focus();
  }

  // ---------- Onboard a team ----------
  const SN_FIELDS = ['number', 'short_description', 'description', 'opened_at', 'resolved_at', 'assignment_group', 'cmdb_ci', 'category', 'priority', 'close_notes', 'state'];
  const OWNER_RE = /^@[\w.\-/]+(\s+@[\w.\-/]+)*$/;
  const byLine = s => String(s || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  const uniq = arr => arr.filter((x, i) => arr.findIndex(y => y.toLowerCase() === x.toLowerCase()) === i);
  const slug = s => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48);
  function tally(incs, key) { const m = new Map(); for (const i of incs) { const v = String(i[key] || '').trim(); if (v) m.set(v, (m.get(v) || 0) + 1); } return Array.from(m.entries()).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])); }
  function onboardModal() {
    const src = S.allIncidents || [], owners = C.ownershipMap(S.teams).byGroup, connected = S.mode === 'connected', ciSel = {};
    const rates = (S.team.hoursModel && S.team.hoursModel.rates) || {};
    const root = $('#modalRoot');
    root.innerHTML = `<div class="overlay"><div class="modal" role="dialog" aria-modal="true" aria-labelledby="obTitle"><h2 id="obTitle">Onboard a team</h2>
      <p class="muted small">${connected ? 'Creates teams/&lt;id&gt;/team.json on its own branch and opens a merge request for review.' : 'Builds team.json for you to add as teams/&lt;id&gt;/team.json through a merge request.'} ${src.length ? `Groups and CIs below come from the loaded ${S.load && S.load.demo ? 'demo data' : 'file'} (${fmt(src.length, 0)} incidents).` : 'Load an incident export first to pick groups and CIs from your own data, or type them below.'} No credentials go in this file.</p>
      <div class="grid2">
        <div><label class="f" for="obName">Team name</label><input type="text" id="obName" autocomplete="off"></div>
        <div><label class="f" for="obId">Team id, used as the folder name</label><input type="text" id="obId" class="mono" autocomplete="off"></div>
        <div><label class="f" for="obBu">Business unit</label><input type="text" id="obBu" value="${esc(S.team.bu || '')}"></div>
        <div><label class="f" for="obApps">Apps, comma separated</label><input type="text" id="obApps"></div>
        <div><label class="f" for="obLead">Team lead</label><input type="text" id="obLead"></div>
        <div><label class="f" for="obOwner">GitLab code owner for the team folder</label><input type="text" id="obOwner" class="mono" placeholder="@payments-sre"></div>
        <div><label class="f" for="obJira">Jira project key</label><input type="text" id="obJira" class="mono" placeholder="SRE"></div>
        <div><label class="f" for="obDays">Days to pull from ServiceNow</label><input type="number" id="obDays" value="90" min="7" max="365"></div>
        <div><label class="f" for="obRateT">Technical rate per hour</label><input type="number" id="obRateT" value="${esc(rates.technical || 85)}" min="0"></div>
        <div><label class="f" for="obRateB">Business rate per hour</label><input type="number" id="obRateB" value="${esc(rates.business || 60)}" min="0"></div>
      </div>
      <div class="section"><h3>Assignment groups</h3><p class="small muted">Incidents in these groups count for this team. A group can belong to one team only.</p>
        <div class="ob-list" id="obGroups">${tally(src, 'group').map(([g, n]) => { const o = owners.get(g.toLowerCase()); return `<label class="check"${o ? ` title="Already belongs to ${esc(o.team)}"` : ''}><input type="checkbox" data-g="${esc(g)}"${o ? ' disabled' : ''}> ${esc(g)} <span class="muted">${fmt(n, 0)}${o ? `, belongs to ${esc(o.team)}` : ''}</span></label>`; }).join('') || '<div class="empty-note">No groups in the loaded data.</div>'}</div>
        <label class="f" for="obGroupsExtra">Other groups, one per line</label><textarea id="obGroupsExtra" style="min-height:56px"></textarea></div>
      <div class="section"><h3>Components and CIs</h3><p class="small muted">Components roll your CIs up for the dashboard. A CI you leave unmapped shows as unmapped rather than being guessed from incident text.</p>
        <label class="f" for="obComps">Components, one per line</label><textarea id="obComps" style="min-height:56px" placeholder="Batch&#10;JBoss&#10;Payments AWS"></textarea>
        <div class="ob-list" id="obCis"></div>
        <label class="f" for="obCisExtra">Other CIs, one per line as Component: CI name</label><textarea id="obCisExtra" style="min-height:56px"></textarea></div>
      <div class="section"><h3>Preview</h3><div id="obPreview" class="small"></div><div id="obChecks" class="small" style="margin-top:8px"></div>
        <div class="row" style="margin-top:12px">${connected ? '<button class="btn primary" id="obMr">Open merge request</button><button class="btn" id="obSave">Save to this clone only</button>' : '<button class="btn primary" id="obDl">Download team.json</button>'}<button class="btn" id="obCancel">Cancel</button></div>
        <div id="obOut" class="small" style="margin-top:8px"></div></div>
    </div></div>`;
    const val = id => $('#' + id).value.trim();
    const groups = () => uniq($$('#obGroups input[data-g]:checked').map(x => x.dataset.g).concat(byLine($('#obGroupsExtra').value)));
    const comps = () => uniq(byLine($('#obComps').value));
    const extraCis = () => { const out = [], bad = []; for (const l of byLine($('#obCisExtra').value)) { const m = l.match(/^([^:]+):\s*(.+)$/); if (m) out.push([m[1].trim(), m[2].trim()]); else bad.push(l); } return { out, bad }; };
    function renderCis() {
      const gs = new Set(groups().map(g => g.toLowerCase())), names = comps();
      const rows = gs.size ? tally(src.filter(i => gs.has(String(i.group || '').trim().toLowerCase())), 'ci') : [];
      $('#obCis').innerHTML = !gs.size ? '<div class="empty-note">Pick groups to see their CIs.</div>' : !rows.length ? '<div class="empty-note">No CIs on these groups\' incidents in the loaded data.</div>'
        : rows.map(([ci, n]) => `<div class="ob-ci"><span title="${esc(ci)}">${esc(ci)} <span class="muted">${fmt(n, 0)}</span></span><select data-ci="${esc(ci)}" aria-label="Component for ${esc(ci)}"><option value="">Not mapped</option>${names.map(c => `<option${ciSel[ci] === c ? ' selected' : ''}>${esc(c)}</option>`).join('')}</select></div>`).join('');
      $$('#obCis select[data-ci]').forEach(sel => { sel.onchange = () => { ciSel[sel.dataset.ci] = sel.value; refresh(); }; });
    }
    function draft() {
      const name = val('obName'), bu = val('obBu'), names = comps(), map = {};
      for (const [ci, c] of Object.entries(ciSel)) if (c && names.includes(c)) map[ci] = c;
      for (const [c, ci] of extraCis().out) if (names.includes(c) && !map[ci]) map[ci] = c;
      return clone({
        $schema: '../../schema/team.schema.json', id: val('obId') || slug(name), name, bu: bu || undefined,
        apps: val('obApps').split(',').map(x => x.trim()).filter(Boolean),
        components: names.map(c => { const cis = Object.keys(map).filter(ci => map[ci] === c); return cis.length ? { name: c, cis } : { name: c }; }),
        servicenow: { assignmentGroups: groups(), ciFilter: [], days: Math.max(7, Math.min(365, +val('obDays') || 90)), fields: SN_FIELDS.slice() },
        hoursModel: { technicalPerIncident: 0.75, byCategory: { batch: 0.5, access: 0.5, certificate: 2, platform: 1, database: 2, other: 1 }, elapsedCapHours: 8, businessPerIncident: 1.5, rates: { technical: +val('obRateT') || 85, business: +val('obRateB') || 60 }, currency: 'USD' },
        toil: { threshold: 60, repetitiveMin: 5 },
        ai: { model: 'sonnet', maxTurns: 4, allowedTools: ['Read', 'Grep', 'Glob'], budgetUsdPerRun: 0.5, budgetUsdPerMonth: 25, timeoutSec: 180 },
        dynatrace: { dimensions: Object.assign(bu ? { bu } : {}, { env: 'prod' }), pushMetrics: true, pushBizevents: true },
        jira: { projectKey: val('obJira') || 'SRE', issueType: 'Story', labels: ['toil'] },
        runbooks: [],
        contacts: Object.assign({ lead: val('obLead') }, val('obOwner') ? { codeowner: val('obOwner') } : {})
      });
    }
    function problems(t) {
      const p = [], names = comps(), x = extraCis();
      if (!t.name) p.push('Add a team name.');
      if (!/^[a-z0-9-]+$/.test(t.id)) p.push('Team id can only use lowercase letters, digits and dashes.');
      else if (S.teams.some(y => y.id === t.id)) p.push(`Team id ${t.id} is already taken.`);
      if (!t.servicenow.assignmentGroups.length) p.push('Pick at least one assignment group.');
      for (const g of t.servicenow.assignmentGroups) { const o = owners.get(g.toLowerCase()); if (o && o.team !== t.id) p.push(`${g} already belongs to ${o.team}.`); }
      x.bad.forEach(l => p.push(`Write "${l}" as Component: CI name.`));
      x.out.forEach(([c, ci]) => { if (!names.includes(c)) p.push(`"${c}" is not one of the components listed above.`); else if (ciSel[ci] && names.includes(ciSel[ci]) && ciSel[ci] !== c) p.push(`${ci} is mapped to both ${ciSel[ci]} and ${c}.`); });
      if (val('obOwner') && !OWNER_RE.test(val('obOwner'))) p.push('Code owner must look like @user or @group/subgroup.');
      if (val('obJira') && !/^[A-Z][A-Z0-9_]+$/.test(val('obJira'))) p.push('Jira project key is capital letters and digits, like SRE.');
      return p;
    }
    let timer = null;
    const refresh = () => { clearTimeout(timer); timer = setTimeout(update, 200); };
    function update() {
      const t = draft(), p = problems(t), el = $('#obPreview');
      if (!el) return;
      $('#obChecks').innerHTML = p.map(x => `<p class="warnline">${esc(x)}</p>`).join('');
      ['obMr', 'obSave', 'obDl'].forEach(id => { const b = $('#' + id); if (b && !b.dataset.done) b.disabled = p.length > 0; });
      if (!t.servicenow.assignmentGroups.length) { el.textContent = 'Pick at least one group to preview this team.'; return; }
      if (!src.length) { el.textContent = 'Load an incident export to preview this team\'s offenders.'; return; }
      const load = C.prepareLoad(src, t, S.teams.filter(y => y.id !== t.id).concat([t]));
      const a = C.analyze(load.incidents, t, S.catalog), top = a.clusters.filter(c => c.flags.toil).slice(0, 5);
      const unmapped = t.components.some(c => c.cis) ? a.clusters.filter(c => c.component === 'unmapped').reduce((n, c) => n + c.count, 0) : 0;
      el.innerHTML = `<p>${fmt(a.kpis.incidents, 0)} incidents in these groups and ${a.kpis.toilClusters} toil patterns, about ${fmt(a.kpis.projectedSavedHoursPerMonth, 0)} hours a month that could be saved.${unmapped ? ` ${fmt(unmapped, 0)} incidents sit on CIs no component claims.` : ''}</p>${top.length ? `<div style="margin-top:6px">${top.map(c => `<div class="ob-top"><span title="${esc(c.name)}">${esc(c.name)}</span><span class="num">${fmt(c.count, 0)} incidents, ${fmt(c.perMonth)} a month${t.components.length ? `, ${esc(c.component)}` : ''}</span></div>`).join('')}</div>` : ''}`;
    }
    async function send(openMr) {
      const t = draft(); if (problems(t).length) return;
      const btns = ['obMr', 'obSave'].map(id => $('#' + id)).filter(Boolean);
      btns.forEach(b => { b.disabled = true; });
      $('#obOut').textContent = openMr ? 'Creating the branch and merge request…' : 'Saving…';
      try {
        const r = await api('POST', '/api/teams/onboard', { team: t, codeowner: val('obOwner'), openMr });
        btns.forEach(b => { b.dataset.done = '1'; });
        $('#obOut').innerHTML = `Saved ${esc(r.file)}${r.branch ? ` on branch ${esc(r.branch)}${r.pushed ? ' and pushed it' : ''}` : ''}${r.codeowners ? ', with a CODEOWNERS line for the folder' : ''}.${r.mrUrl ? ` <a href="${esc(r.mrUrl)}" target="_blank" rel="noopener">Open the merge request</a>.` : ''}${r.notes.length ? '<br>' + r.notes.map(esc).join('<br>') : ''}<br>${openMr ? 'The team shows up in the team list once the merge request is merged and you sync the repo.' : 'The team is in this clone now and in the team list.'}`;
        if (!openMr) { S.teams = await api('GET', '/api/teams'); renderTeamSelect(); $('#teamSel').value = S.team.id; }
      } catch (e) { $('#obOut').textContent = e.message; btns.forEach(b => { b.disabled = false; }); }
    }
    $('#obName').oninput = () => { if (!$('#obId').dataset.touched) $('#obId').value = slug(val('obName')); refresh(); };
    $('#obId').oninput = () => { $('#obId').dataset.touched = '1'; refresh(); };
    ['obBu', 'obApps', 'obLead', 'obOwner', 'obJira', 'obDays', 'obRateT', 'obRateB', 'obCisExtra'].forEach(id => { $('#' + id).oninput = refresh; });
    $('#obComps').oninput = () => { renderCis(); refresh(); };
    $('#obGroupsExtra').oninput = () => { renderCis(); refresh(); };
    $$('#obGroups input[data-g]').forEach(x => { x.onchange = () => { renderCis(); refresh(); }; });
    $('#obCancel').onclick = () => { root.innerHTML = ''; };
    if ($('#obMr')) $('#obMr').onclick = () => send(true);
    if ($('#obSave')) $('#obSave').onclick = () => send(false);
    if ($('#obDl')) $('#obDl').onclick = () => {
      const t = draft(); if (problems(t).length) return;
      download('team.json', JSON.stringify(t, null, 2) + '\n', 'application/json');
      localStorage.setItem('ta:team:' + t.id, JSON.stringify(t));
      if (!S.teams.some(y => y.id === t.id)) S.teams.push(t);
      renderTeamSelect(); $('#teamSel').value = S.team.id;
      const owner = val('obOwner');
      $('#obOut').innerHTML = `Downloaded team.json. Add it to the repo as <span class="mono">teams/${esc(t.id)}/team.json</span> in a merge request${owner ? `, and add <span class="mono">/teams/${esc(t.id)}/ ${esc(owner)}</span> to CODEOWNERS` : ''}. It is also in this browser's team list, so you can use it now.`;
    };
    renderCis(); update(); $('#obName').focus();
  }

  // ---------- Propose signature ----------
  function proposeModal(c) {
    const sig = C.proposeSignature(c, S.team, S.team.id);
    const root = $('#modalRoot');
    root.innerHTML = `<div class="overlay"><div class="modal"><h2>Propose a shared signature</h2><p class="muted small">Merged signatures make this pattern known to every team. Keep the regex specific: CI checks that your samples match and that no other signature claims them.</p>
      <div class="grid2"><div><label class="f">Id</label><input type="text" id="pId" value="${esc(sig.id)}"></div><div><label class="f">Name</label><input type="text" id="pName" value="${esc(sig.name)}"></div>
      <div><label class="f">Category</label><select id="pCat">${['batch', 'certificate', 'access', 'messaging', 'platform', 'database', 'file-transfer', 'api', 'other'].map(x => `<option ${x === sig.category ? 'selected' : ''}>${x}</option>`).join('')}</select></div><div><label class="f">Disposition</label><select id="pDisp">${['eliminate', 'automate', 'selfheal', 'tune', 'accept'].map(x => `<option value="${x}" ${x === sig.disposition ? 'selected' : ''}>${C.DISPOSITION_LABEL[x]}</option>`).join('')}</select></div></div>
      <label class="f" style="margin-top:8px">Regex (case-insensitive, tested on short description + description)</label><input type="text" id="pRe" class="mono" value="${esc(sig.match.regex)}" style="width:100%">
      <div id="pTest" class="small" style="margin:6px 0"></div>
      <label class="f">Samples (one per line)</label><textarea id="pSamples" style="min-height:80px">${esc(sig.samples.join('\n'))}</textarea>
      <label class="f">Automation hint</label><input type="text" id="pHint" style="width:100%" placeholder="How would this be automated or eliminated?">
      <div class="row" style="margin-top:12px">${S.mode === 'connected' ? `<button class="btn primary" id="pMr">Save and open merge request</button><button class="btn" id="pSave">Save to signatures/proposed only</button>` : `<button class="btn primary" id="pDl">Download proposal JSON</button>`}<button class="btn" id="pCancel">Cancel</button></div><div id="pOut" class="small" style="margin-top:8px"></div></div></div>`;
    const test = () => { let re; try { re = new RegExp($('#pRe').value, 'i'); } catch (e) { $('#pTest').textContent = 'Invalid regex: ' + e.message; return; } const m = S.incidents.filter(i => re.test(i.short + '\n' + i.description)); const own = c.incidents.filter(i => re.test(S.incidents[i].short + '\n' + S.incidents[i].description)).length; const others = S.catalog.filter(s => { try { return new RegExp(s.match.regex, 'i').test($('#pSamples').value.split('\n')[0] || ''); } catch (e) { return false; } }); $('#pTest').innerHTML = `Matches <b>${m.length}</b> loaded incidents (${own} of this pattern's ${c.count})${m.length > c.count * 1.5 ? ' — too broad?' : ''}${others.length ? ` · <b>overlaps</b> ${others.map(s => esc(s.id)).join(', ')}` : ''}`; };
    $('#pRe').oninput = test; test();
    const build = () => Object.assign(sig, { id: $('#pId').value.trim(), name: $('#pName').value.trim(), category: $('#pCat').value, disposition: $('#pDisp').value, match: { regex: $('#pRe').value, flags: 'i', fields: ['short', 'description'] }, samples: $('#pSamples').value.split('\n').map(s => s.trim()).filter(Boolean), automationHint: $('#pHint').value.trim() });
    $('#pCancel').onclick = () => root.innerHTML = '';
    if ($('#pDl')) $('#pDl').onclick = () => { const s = build(); download(`${s.id}.json`, JSON.stringify(s, null, 2), 'application/json'); root.innerHTML = ''; toast('Add the file under signatures/proposed/ in a merge request'); };
    const send = async openMr => { const s = build(); if (!/^[a-z0-9-]+$/.test(s.id)) return toast('Id must be lowercase letters, digits and dashes', true); $('#pOut').textContent = 'Working…'; try { const r = await api('POST', '/api/signatures/propose', { signature: s, openMr, team: S.team.id }); $('#pOut').innerHTML = `Saved ${esc(r.file)}${r.branch ? ` · branch ${esc(r.branch)}${r.pushed ? ' pushed' : ''}` : ''}${r.mrUrl ? ` · <a href="${esc(r.mrUrl)}" target="_blank" rel="noopener">open merge request</a>` : ''}${r.notes.length ? '<br>' + r.notes.map(esc).join('<br>') : ''}`; const sg = await api('GET', '/api/signatures'); S.proposed = sg.proposed; } catch (e) { $('#pOut').textContent = e.message; } };
    if ($('#pMr')) $('#pMr').onclick = () => send(true);
    if ($('#pSave')) $('#pSave').onclick = () => send(false);
  }

  // ---------- Dynatrace ----------
  S._events = []; S._live = {}; S._previewEvents = []; S._pendingEvents = [];
  function queueBizevent(ev) { if (ev) (isPreview() ? S._previewEvents : S._events).push(C.bizevent(S.team, ev.offender, ev.from, ev.to)); }
  async function pushMetrics() {
    if (!S.analysis) return toast('Load data first', true);
    if (blockedByPreview()) return;
    const lines = C.metricsLines(S.analysis, S.ledger, S.team);
    try { const r = await api('POST', '/api/metrics/push', { lines, events: S._events }); toast(`Pushed ${r.metrics ? r.metrics.lines : 0} metric lines${r.bizevents ? ', ' + r.bizevents.events + ' milestone events' : ''}`); S._events = []; } catch (e) { toast('Push failed: ' + e.message, true); }
  }

  // ---------- wiring ----------
  function wire() {
    $$('#nav button').forEach(b => b.onclick = () => { S.view = b.dataset.view; if (S.view === 'exec' && S.mode === 'connected') api('GET', '/api/exec').then(x => { S.exec = x; renderExec(); }).catch(() => {}); render(); });
    $('#teamSel').onchange = e => selectTeam(e.target.value);
    $('#btnLoad').onclick = () => $('#csvFile').click();
    $('#csvFile').onchange = e => { const f = e.target.files[0]; if (!f) return; f.text().then(t => loadCSVText(t, f.name)); e.target.value = ''; };
    $('#btnDemo').onclick = () => { loadCSVText(C.demoCSV(42, 90), 'demo-incidents.csv', { demo: true }); toast('Demo data loaded: 90 days of an invented estate. Nothing from it is saved.'); };
    $('#dataSel').onchange = async e => { const f = e.target.value; if (!f) return; try { const res = await fetch('/api/data/' + encodeURIComponent(f)); loadCSVText(await res.text(), f); } catch (err) { toast(err.message, true); } };
    $('#btnPull').onclick = async () => { $('#btnPull').disabled = true; toast('Pulling from ServiceNow…'); try { const r = await api('POST', '/api/pull', { team: S.team.id }); toast(`${r.rows} incidents → data/${r.file}`); await selectTeam(S.team.id); $('#dataSel').value = r.file; $('#dataSel').dispatchEvent(new Event('change')); } catch (e) { toast('Pull failed: ' + e.message, true); } $('#btnPull').disabled = false; };
    $('#btnSync').onclick = async () => { try { const r = await api('POST', '/api/git/pull'); toast(r.ok ? (r.note ? r.note : 'Repo synced: ' + (r.output.split('\n').pop() || 'up to date')) : 'Sync failed: ' + r.error, !r.ok || !!r.note); S.teams = await api('GET', '/api/teams'); const sg = await api('GET', '/api/signatures'); S.catalog = sg.catalog; S.proposed = sg.proposed; renderTeamSelect(); await selectTeam(S.team.id); } catch (e) { toast(e.message, true); } };
    $('#btnPresent').onclick = () => { document.body.classList.add('present'); const b = document.createElement('button'); b.className = 'btn present-exit'; b.textContent = 'Exit'; b.onclick = () => { document.body.classList.remove('present'); b.remove(); }; document.body.appendChild(b); };
    ['offSearch', 'offCat', 'offState', 'offToil', 'offUnknown'].forEach(id => $('#' + id).oninput = renderOffenders);
    ['incSearch', 'incSig'].forEach(id => $('#' + id).oninput = renderIncidents);
    $('#btnExportOff').onclick = () => S._offRows && download(`${S.team.id}-offenders.csv`, C.toCSV(S._offRows.map(c => ({ pattern: c.name, category: c.category, count: c.count, per_month: +c.perMonth.toFixed(2), score: c.score, disposition: c.disposition, state: (S.ledger.offenders[c.id] || {}).state || '', saves_hours_per_month: c.savings.hoursPerMonth, saves_usd_per_year: c.savings.usdPerYear, known: c.known, id: c.id }))), 'text/csv');
    $('#btnExportInc').onclick = () => S._incRows && download(`${S.team.id}-incidents.csv`, C.toCSV(S._incRows.map(i => i.raw), S.raw.headers), 'text/csv');
    $('#btnRemap').onclick = () => { $$('#mapping select').forEach(s => { if (s.value) S.mapping[s.dataset.f] = s.value; else delete S.mapping[s.dataset.f]; }); $('#incSig').innerHTML = '<option value="">All patterns</option>'; applyMapping(); toast('Re-analyzed'); };
    $('#btnLedgerExport').onclick = () => download(`${S.team.id}-ledger.json`, JSON.stringify(S.ledger, null, 2), 'application/json');
    $('#btnLedgerImport').onclick = () => $('#ledgerFile').click();
    $('#ledgerFile').onchange = e => { const f = e.target.files[0]; if (!f) return; if (blockedByPreview()) { e.target.value = ''; return; } f.text().then(t => { const l = safeJSON(t, null); if (!l || !l.offenders) return toast('Not a ledger file', true); l.team = S.team.id; S.ledger = l; saveLedger(); render(); toast('Ledger imported'); }); e.target.value = ''; };
    $('#btnCommit').onclick = async () => { try { const r = await api('POST', '/api/git/commit', { message: `toil-analyzer(${S.team.id}): ledger and reports`, push: true }); toast(r.ok ? (r.pushed ? 'Committed and pushed' : 'Committed locally' + (r.pushError ? ' — push failed: ' + r.pushError : '')) : 'Nothing to commit: ' + r.error, !r.ok || r.pushed === false); } catch (e) { toast(e.message, true); } };
    $('#btnJira').onclick = async () => { if (blockedByPreview()) return; $('#btnJira').disabled = true; try { const r = await api('POST', '/api/jira/sync', { team: S.team.id }); adoptLedger(r.ledger); render(); toast(r.events.length ? r.events.map(e => `${e.name}: ${C.STATE_LABEL[e.from]} → ${C.STATE_LABEL[e.to]}`).join(' · ') : `Checked ${r.checked} Jira issue(s), nothing moved`); } catch (e) { toast('Jira sync failed: ' + e.message, true); } $('#btnJira').disabled = false; };
    $('#btnReTest').onclick = () => { let re; try { re = new RegExp($('#reTest').value, $('#reFlags').value.replace('g', '')); } catch (e) { $('#reOut').textContent = 'Invalid regex: ' + e.message; return; } const m = S.incidents.filter(i => re.test(i.short + '\n' + i.description)); $('#reOut').innerHTML = `<b>${m.length}</b> of ${S.incidents.length} incidents match` + (m.length ? '<br>' + m.slice(0, 5).map(i => `<span class="mono">${esc(i.number)}</span> ${esc(i.short)}`).join('<br>') : ''); };
    $('#btnReportCopy').onclick = () => S._report && copy(S._report);
    $('#btnReportDl').onclick = () => S._report && download(`${S.team.id}-${C.weekKey(new Date())}.md`, S._report, 'text/markdown');
    $('#btnReportSave').onclick = async () => { if (!S._report) return; if (blockedByPreview()) return; try { const r = await api('POST', '/api/report', { team: S.team.id, name: C.weekKey(new Date()), markdown: S._report }); toast('Saved ' + r.file); } catch (e) { toast(e.message, true); } };
    $('#btnPush').onclick = pushMetrics;
    $('#btnTeamSave').onclick = async () => { const t = safeJSON($('#teamJson').value, null); if (!t || !t.id) return $('#teamMsg').textContent = 'Invalid JSON or missing id.'; t.hoursModel = t.hoursModel || {}; t.hoursModel.rates = { technical: +$('#setRateT').value || 85, business: +$('#setRateB').value || 60 }; t.toil = Object.assign(t.toil || {}, { threshold: +$('#setThreshold').value || 60, repetitiveMin: +$('#setRepMin').value || 5 }); try { await saveTeam(t); renderTeamSelect(); await selectTeam(t.id); toast('Team saved'); } catch (e) { $('#teamMsg').textContent = e.message; } };
    $('#btnTeamDl').onclick = () => download('team.json', $('#teamJson').value, 'application/json');
    $('#btnOnboard').onclick = () => onboardModal();
    $('#btnTeamNew').onclick = () => { const id = prompt('New team id (lowercase, dashes):', ''); if (!id || !/^[a-z0-9-]+$/.test(id)) return; const t = safeJSON($('#teamJson').value, {}); t.id = id; t.name = prompt('Team name:', id) || id; $('#teamJson').value = JSON.stringify(t, null, 2); $('#btnTeamSave').click(); };
    $('#btnClearLocal').onclick = () => { if (!confirm('Remove the local ledger and team edits for ' + S.team.id + '?')) return; localStorage.removeItem('ta:ledger:' + S.team.id); localStorage.removeItem('ta:team:' + S.team.id); selectTeam(S.team.id); };
    $('#drawerClose').onclick = () => { $('#drawer').classList.remove('open'); S.selected = null; };
    document.addEventListener('keydown', e => { if (e.key === 'Escape') { $('#drawer').classList.remove('open'); $('#modalRoot').innerHTML = ''; } });
    const main = $('.main'); main.addEventListener('dragover', e => { e.preventDefault(); main.classList.add('over'); }); main.addEventListener('dragleave', () => main.classList.remove('over')); main.addEventListener('drop', e => { e.preventDefault(); main.classList.remove('over'); const f = e.dataTransfer.files[0]; if (f) f.text().then(t => loadCSVText(t, f.name)); });
  }
  let toastTimer = null;
  function toast(msg, isErr) { const r = $('#toastRoot'); r.innerHTML = `<div class="toast ${isErr ? 'err' : ''}">${esc(msg)}</div>`; clearTimeout(toastTimer); toastTimer = setTimeout(() => r.innerHTML = '', isErr ? 6000 : 3200); }

  boot().catch(e => { console.error(e); toast('Startup problem: ' + e.message, true); });
})();
