# SRE Toil Analyzer — notes for Claude Code sessions in this repo

Purpose: turn ServiceNow incident dumps into a toil kill chain (Detected → Ticketed → Fixed → Verified) with hours and savings that survive an executive's questions. Deterministic JavaScript does the analysis; you are only asked to decide dispositions and draft fixes for one offender at a time.

Load the plugin when working here: `claude --plugin-dir plugins/toil-analyzer` (or `npm run claude`).

Layout
- `lib/core.js` — pure engine (CSV, masking, signatures, scoring, hours, ledger, report, Dynatrace lines). Inlined into `ui/index.html` by `scripts/build.js`; run `npm run build` after editing it or `ui/app.js`.
- `server/` — local server (`npm start`) and the two scheduled scripts (`pull.js`, `report.js`). Zero npm dependencies; keep it that way.
- `teams/<id>/team.json` — team properties (schema in `schema/team.schema.json`). Teams edit their own file; MRs are reviewed via CODEOWNERS.
- `signatures/` — shared regex catalog; `signatures/proposed/` — pending proposals. Every signature carries samples that CI checks (`scripts/test-signatures.js`).
- `ledger/<id>/` — kill-chain state and summaries, written by the UI and the schedule. Never hand-edit.
- `data/` and `analysis-cache/` are git-ignored: raw dumps stay on the machine.

Conventions
- Verdicts are the JSON in the toil-analyzer skill — the UI parses them.
- Keep token use small: packets are ~1k tokens by design; don't expand them.
- Tests: `npm test`. Don't add dependencies for convenience; Node 18+ built-ins only.
