# SRE Toil Analyzer — v4

**Ally Financial** · Site reliability engineering. The interface follows the supplied ToilLens design, with an embedded Ally wordmark, deep plum surfaces, lavender accents and lime highlights.

## Open this v4 bundle

- **Standalone app:** open `sre-toil-analyzer-lite-v4.html` in your browser.
- **Connected app:** run `npm start` from this folder, then open `http://localhost:7077`.
- **Architecture guide:** open `sre-toil-analyzer-architecture-v4.html`.

The full source project is included below. The standalone files match `ui/index.html` and `docs/architecture.html`.

Turn ServiceNow incident dumps into a **toil kill chain** — Detected → Ticketed → Fixed → Verified — with technical and business hours, projected and *verified* savings, and an executive view. Runs on your laptop from a git clone, needs only Node.js, and uses Claude Code only when you click.

```
git clone <your-gitlab-url>/toil-analyzer.git
cd toil-analyzer
npm start            # opens http://localhost:7077 — Connected mode
```

No Node on the machine? Open `ui/index.html` directly — **Lite mode**: same UI, CSV analysis, kill chain and executive view, saved in the browser.

## What it does (zero tokens)

1. **Reads the dump** — any ServiceNow CSV export (auto-detects columns; fix them under Incidents → Column mapping) or a scheduled Table API pull.
2. **Masks and mines signatures** — job names, hosts, IDs, dates and numbers become placeholders, so `CTM_LN_ACQ_FEED_D ended NOT OK (RC=12)` and `CTM_PAY_ACH_OUT ended NOT OK (RC=8)` are one pattern. Patterns matching the shared catalog are *known*; the rest are *unknown* until someone proposes a signature.
3. **Scores toil** — repetition, automatable language in close notes, regularity of arrival, uniformity of resolution.
4. **Counts hours** — technical hours per incident (team defaults, per category, or per signature) and business hours from opened→resolved (capped) — priced with the team's rates.
5. **Tracks the kill chain** — toil candidates register in the ledger; you mark them Ticketed from the offender drawer. Jira sync moves Ticketed → **Fixed** when the issue is Done (or you click it). The scheduled pull advances Fixed → **Verified** after two clean weeks and flips Verified → **Regressed** if the pattern returns. Verified savings are measured against the incident rate *since the fix*, not the whole window.
6. **Reports** — weekly markdown, Dynatrace metrics and milestone events, and the executive view (kill chain, savings ladder, what-if slider, all-teams rollup).

Claude is invoked per offender, on click, with a ~1k-token packet and a JSON schema. Results are cached by signature, budgets live in `team.json`, and the cost of every run is recorded — that is the AI-usage metric, no vendor API needed.

## Modes

| | Lite (`ui/index.html`) | Connected (`npm start`) |
|---|---|---|
| CSV analysis, offenders, kill chain, executive view, report | yes | yes |
| Ledger storage | this browser (export/import JSON) | `ledger/<team>/` in the clone |
| Team properties | browser copy (download to share) | `teams/<team>/team.json` |
| Open dumps from `data/`, pull from ServiceNow | — | yes |
| Analyze with Claude (live stream, cache, budget) | copy packet → `/toil-analyzer:offender`, paste verdict | yes |
| Propose signature | downloads JSON for an MR | writes file, branch, commit, push, opens MR |
| Push metrics + milestones to Dynatrace | — | yes |
| Executive rollup across teams | — | yes |

The server binds to `127.0.0.1` only. Nothing is hosted.

## Load checks

Every load goes through the same checks, in the UI and in the scheduled report:

- **Duplicates.** Rows that repeat an incident number (stitched or overlapping exports) are dropped, keeping the most recent version of each: resolved beats open, later beats earlier.
- **Ownership.** Only incidents in the selected team's assignment groups are kept. Which team owns a group comes from every `teams/*/team.json`, so it does not matter who loads the file. A group may belong to one team only; CI fails an MR that claims a group twice. Switching teams with data loaded re-scopes it to the new team.
- **Preview.** If more than half of a load is not the team's, 5% or more of the rows are duplicates, or the team has no assignment groups set, nothing is saved. The ledger is a scratch copy, pushes and Jira sync wait, and a strip at the top offers **Save to ledger**, **Discard load** or **Onboard a team from this data**. Demo data is always a preview and is never saved.
- **Rebaseline.** A pattern's baseline, which savings are measured against, is set once when it is first tracked, so a bad first load sticks. **Rebaseline** in the offender panel resets it from the loaded data, with a reason kept in the history. For a fixed pattern it counts only incidents from before the fix and needs at least two weeks of them.

## Repository layout

```
ui/index.html            the app (engine, catalog and example team inlined by scripts/build.js)
ui/app.js                UI source — edit, then npm run build
lib/core.js              pure engine: csv, masking, signatures, scoring, hours, ledger, report, metrics
lib/servicenow.js        Table API → CSV        lib/dynatrace.js  metrics + bizevents
lib/repo.js              git, GitLab MRs, Claude Code headless runner
server/index.js          local server           server/pull.js, server/report.js  scheduled scripts
teams/<id>/team.json     team properties (schema/team.schema.json) — teams own theirs
signatures/*.json        shared catalog         signatures/proposed/  pending MRs
ledger/<id>/             ledger.json + summary.json (written by UI and schedule)
reports/<id>/            weekly markdown
plugins/toil-analyzer/   Claude Code plugin (skill, agents, /toil-analyzer:offender)
.claude-plugin/          marketplace manifest    .gitlab-ci.yml  validate + scheduled progress
data/, analysis-cache/   git-ignored: raw dumps and Claude verdict cache stay on the machine
```

## Team properties

Each team has one file, `teams/<id>/team.json`: apps, components (each with a list of `cis`, or a `match` regex, so patterns roll up to a component in Dynatrace), ServiceNow assignment groups, Control-M prefixes and mask patterns, hours model and rates, toil threshold, AI budget and model, Dynatrace dimensions, Jira project. Edit it in the UI (Settings) or by hand; `npm run validate` checks it against the schema, CI runs the same check on every MR. CODEOWNERS routes `teams/<id>/` to the team and `signatures/` to core SRE.

**Components from CIs.** When any component lists `cis`, components are mapped from the incident's CI field only, never from typed text. Each pattern takes the component most of its incidents' CIs belong to, and CIs no component claims show as `unmapped`. A CI may sit in one component per team (CI checks). Teams without `cis` keep the regex-over-text mapping.

**Onboarding a team.** Settings → **Onboard a team**. Pick assignment groups and CIs from a loaded export (groups another team owns are locked), group the CIs into components, and preview the team's top offenders. In Connected mode, **Open merge request** writes `teams/<id>/team.json` and a CODEOWNERS line for the team's folder on an `onboard/<id>` branch, pushes it and opens the MR (GitLab API with `GITLAB_TOKEN`, else `glab`, else a prefilled link), then puts the clone back on the branch it was on. In Lite mode it downloads `team.json` to add through an MR. The form never asks for credentials. *New team from this* still copies the current team's file.

## Scheduled progress (no Claude)

Two scripts, both safe to run from a GitLab CI schedule or Windows Task Scheduler / cron:

```
node server/pull.js   --team example-team --days 90     # ServiceNow → data/<team>-<yyyymmdd>.csv
node server/report.js --team example-team --push        # analyze, advance ledger, summary + weekly report, Dynatrace
```

The report runs the same load checks as the UI: a file that fails them is skipped, nothing is written and the script exits with code 3; `--force` accepts it. `--all` does every team. `.gitlab-ci.yml` runs them on schedule with masked variables and can commit `ledger/` and `reports/` back (set `CI_PUSH_TOKEN`). Progress means: sync Jira (Ticketed → Fixed when the issue is Done, Fixed → Ticketed if reopened; needs `JIRA_URL` + `JIRA_TOKEN`), recount the signatures in the new dump, then Fixed → Verified when two consecutive 7-day windows have zero hits, Verified → Regressed on the first hit after verification. Milestones become Dynatrace business events.

Sync in the UI is stash-aware: your uncommitted ledger edits survive a `git pull`; a real conflict is reported, never auto-resolved. **Commit & push ledger** pushes your moves so the next scheduled run builds on them.

MCP vs API: the Table API is what scheduled work uses (deterministic, no tokens). MCP is for interactive sessions; a Node MCP wrapper over `lib/servicenow.js` is the natural add-on if you want one.

## Dynatrace

Set `DT_URL` (SaaS `https://<env>.live.dynatrace.com`, or ActiveGate `https://<ag>:9999/e/<env>`) and `DT_TOKEN` with scopes `metrics.ingest` and `bizevents.ingest`. Push from Report → *Push metrics*, or from `report.js --push`.

Common schema across teams (dimensions `team`, plus whatever is in `team.json` → `dynatrace.dimensions`, e.g. `bu`, `env`):

```
toil.incidents   toil.candidates   toil.candidates.pct   toil.window.days            (the analysed window)
toil.hours.technical   toil.hours.business   toil.usd.technical   toil.usd.business
toil.hours.saved.projected   toil.hours.saved.verified   toil.usd.saved.projected   toil.usd.saved.verified
toil.ai.cost_usd   toil.ai.runs
toil.ledger.offenders {state=…}
toil.category.incidents | .hours.technical | .hours.business {category=…}
toil.component.incidents | .hours.technical | .hours.business {component=…}
bizevent  event.type=toil.milestone  signature, pattern, from_state, to_state, jira, hours_saved_per_month
```

Every metric is a gauge: each push re-describes the rolling window, so re-running never double-counts. No signature dimension on metrics (cardinality); signatures live in the events. One dashboard filtered by `team` is the multi-team view; `component` is the common axis across teams.

## Claude Code

- In the clone: `npm run claude` (= `claude --plugin-dir plugins/toil-analyzer`) loads the skill, agents and `/toil-analyzer:offender`.
- Everywhere else: `/plugin marketplace add <your-gitlab-url>/toil-analyzer.git` then `/plugin install toil-analyzer@toil-analyzer` (private repos: `GITLAB_TOKEN`).
- Connected mode runs `claude -p --output-format stream-json --max-turns N --model M --allowedTools …` with the packet on stdin. Set `CLAUDE_BIN` if `claude` isn't on PATH. Budgets: `ai.budgetUsdPerRun`, `ai.budgetUsdPerMonth` in `team.json`; the runner refuses when the month is spent. Cache: `analysis-cache/<team>/<signature>.json`, reused until the pattern grows 25%.
- To cap effort per run, see the `maxEffortLevel` setting in the Claude Code docs. On a Claude Code build without `--json-schema`, set `ai.jsonSchema: false` in team.json (the prompt still asks for JSON).

## Merge flow for gaps

An **unknown** offender shows *Propose signature* in its drawer. The dialog pre-fills a regex from the masked pattern, tests it live against the loaded incidents and against the existing catalog, and (Connected) writes `signatures/proposed/<id>.json`, branches, commits, pushes and opens the MR (`GITLAB_TOKEN` or `glab`; otherwise you get the link). CI proves the regex matches its samples and steals none from other signatures. Approve by moving the file into `signatures/`. Every team's next *Sync repo* gets the pattern.

## Configuration and network

Copy `.env.example` to `.env` (ServiceNow, Dynatrace, GitLab, Jira). Corporate CA: `NODE_EXTRA_CA_CERTS`. Proxy: Node 24+ honours `HTTP(S)_PROXY` with `NODE_USE_ENV_PROXY=1`; older Node needs a proxy-free route to ServiceNow/Dynatrace (an ActiveGate usually is).

Raw dumps are git-ignored. The ledger stores pattern names, counts, states, Jira keys and Claude verdicts; `ledger/<team>/summary.json` stores the KPI snapshot and top pattern names. Unknown patterns are named by their masked text, so review `teams/<id>/team.json` → `maskPatterns` if short descriptions can carry customer data. The packet sent to Claude Code contains up to five raw sample short descriptions and close-note excerpts.

## Commands

```
npm start            local server + UI            npm test         schema, signatures, engine, build check
npm run pull         ServiceNow → data/           npm run report   analyze + ledger + report (+ --push)
npm run build        inline engine/catalog/team into ui/index.html
```

Architecture and how everything works: `docs/architecture.html` (open it in a browser or attach it to Confluence).

Demo: press **Demo data** in the UI (90 days of an invented estate), or `node server/report.js --team example-team --file examples/demo-incidents.csv`.
