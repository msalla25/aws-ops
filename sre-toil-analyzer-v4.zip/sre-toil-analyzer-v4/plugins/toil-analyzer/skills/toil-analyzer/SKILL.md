---
name: toil-analyzer
description: Work Toil Analyzer offender packets — recurring ServiceNow incident patterns with counts, samples and hours. Use when the user pastes a packet, mentions an offender/signature id, asks to disposition or draft a fix/Jira for a recurring incident pattern, or wants to propose a shared signature. Deterministic analysis already happened in the tool; this skill only decides and drafts.
---

# Toil Analyzer

The tool (`npm start` in this repo, or `ui/index.html` opened directly) already did the counting, masking, clustering, scoring and hours math with zero tokens. When a packet reaches you, the question is narrow: **what should the team do about this pattern, and what does the ticket say?**

## Inputs you will see

An **offender packet** (JSON) with: `offender` (id, name, category, count, perMonth, score, scoreParts, weekly trend, groups, CIs, hours per incident, current disposition, catalog `automationHint` if the pattern is known), `samples` (up to 5 masked and raw short descriptions with close notes), `context` (team apps, components, job prefixes, runbooks, Jira project) and `rules`.

## Output — always this JSON, nothing else

```json
{
  "disposition": "eliminate | automate | selfheal | tune | accept",
  "confidence": 0.0-1.0,
  "root_cause": "one or two sentences, from the samples",
  "fix_type": "aap-job-template | code-change | config-change | alert-tuning | runbook | vendor | process | none",
  "fix_summary": "what the team ships, in their stack",
  "hours_est": 6,
  "jira_title": "imperative, ≤ 80 chars",
  "jira_description": "problem, evidence, proposed fix, acceptance: incidents stop for 2 weeks",
  "evidence": ["facts taken from the packet"],
  "risks": ["what could go wrong"]
}
```

The UI pastes this verdict straight onto the offender (Paste verdict), so a stray sentence before or after the JSON breaks the flow.

## How to decide

- **eliminate** — the cause can be removed (fix undo retention, fix the pool sizing, stop the noisy job). Prefer this when the samples show one deterministic cause.
- **automate** — a human step repeats verbatim in the close notes (rerun, unlock, resubmit, renew). An AAP job template or a scheduled job replaces the human.
- **selfheal** — the trigger is an alert and the fix is safe to run unattended (restart listener, prune images, scale consumers). Requires a guardrail (max runs/hour, evidence posted to the incident).
- **tune** — real signal but noisy: raise the threshold, require sustained breach, dedupe alerts.
- **accept** — rare, or business-driven, or the fix costs more than the toil. Say why.

Weigh `scoreParts`: high `regularity` means scheduled cause (batch, cert, rotation); high `uniformity` in close notes means the human procedure is stable enough to automate; low `automatable` with high `repetition` often means a product defect (eliminate) or noise (tune).

## Rules

1. **Evidence stays shallow.** High-level error plus initial analysis. Do not fetch full logs or traces; the samples are the evidence. If Dynatrace MCP tools are available, at most one query to confirm a component name or a recent problem, never a log dump.
2. **Stay inside the team's stack** (`context.components`, job prefixes, AAP, Delinea, ECS, OpenShift as the packet suggests). No new platforms.
3. **Keep it cheap.** No exploration of the repo for a packet decision. Read nothing unless the packet points at a runbook path.
4. **Hours are the team's.** Do not restate or re-estimate `hours` from the packet; `hours_est` is the *fix* effort only.
5. Never invent Jira keys, hostnames or job names that are not in the packet.

## Related commands and agents

- `/toil-analyzer:offender` — paste a packet (or a path under `analysis-cache/`) and get the verdict JSON.
- `toil-disposition` agent — same job, isolated context, for batch runs from the CLI.
- `toil-evidence` agent — optional, confirms one component/problem in Dynatrace with a strict budget.

## Working the repo itself

- `npm start` — local cockpit (Connected mode); `npm test` — schema, signature and engine checks.
- Proposed signatures live in `signatures/proposed/`; approving one means moving the file to `signatures/` in the MR. Regex must match its own `samples` and steal none from other signatures (`scripts/test-signatures.js`).
- Team properties: `teams/<id>/team.json` (schema in `schema/`). Ledger: `ledger/<id>/ledger.json` — edit through the UI, not by hand.
