---
description: Disposition a Toil Analyzer offender packet and draft its Jira text (returns verdict JSON for the UI's "Paste verdict")
argument-hint: <packet JSON | path to a packet file>
---

Use the toil-analyzer skill.

Input: $ARGUMENTS — either the packet JSON pasted inline (the UI's "Copy packet" button produces it) or a path to a JSON file in this repo (for example under analysis-cache/).

If it is a path, read that one file. Do not explore anything else.

Return only the verdict JSON object described in the skill. No preamble, no code fences.
