---
name: toil-triage-pipeline
description: Turn a ServiceNow incident CSV into grouped repeat offenders with error evidence, then into Jira tickets and a Confluence write-up. Use this whenever someone hands over an incident export, an incident dump, a ToilLens subset, a "top toil candidates" file, or asks to analyse repeat incidents, find automation candidates, group incidents by error, work out how many incidents fall in a category, or raise toil tickets from incident data. Works on a full unfiltered dump or an already-filtered subset. Also use it when the person mentions toil analysis, Control-M failure analysis, repeat offenders, or feeding incident numbers into a toil dashboard.
allowed-tools:
  - Bash(node scripts/preflight.mjs:*)
  - Bash(node scripts/prep-incidents.mjs:*)
  - Bash(node scripts/picker.mjs:*)
  - Bash(node scripts/wait-selection.mjs:*)
  - Bash(node scripts/offenders.mjs:*)
  - Bash(node scripts/evidence-plan.mjs:*)
  - Bash(node scripts/brief-inputs.mjs:*)
  - Bash(node scripts/delegation-prompt.mjs:*)
  - Bash(node scripts/check-findings.mjs:*)
  - Bash(node scripts/render-outputs.mjs:*)
  - Read
  - Write
  - Glob
---

# Toil triage pipeline

Takes an incident CSV and walks it to a reviewed backlog: **detect → confirm → group → evidence → document**. Every step that costs money or creates records is gated by a person.

The point is repeatability. The same run produces the same grouping, the numbers in the Jira match the numbers in the Confluence page, and both trace back to named incident numbers. Anyone reading the output should be able to check it.

Runs on **Node 16+ with no npm install** — stdlib only, no network calls, no package.json needed. Every command below works the same in bash, PowerShell and cmd. Run them from the skill directory, or give the full path to the script; the scripts find their own assets either way.

## Runs on auto — three gates, nothing else

The person makes exactly three decisions in a run. Everything between them runs without asking:

| Gate | What the person decides |
|---|---|
| **Target** (step 2) | Which toil item(s), evidence source and depth, what to produce — via the picker or in chat |
| **Grouping** (step 3) | Whether the offenders are grouped right; merges and drops |
| **Approval** (step 5) | Whether the drafts become tickets and pages |

Between gates, chain the commands and choose the modes yourself. Concretely: run preflight and prep back to back; launch the picker with `--detach` and poll with `wait-selection.mjs` until it returns, without asking whether to; run evidence-plan and brief-inputs together; run check-findings and render-outputs together. Never ask "shall I run prep?", "which mode?", "static or detached?", "Markdown or wiki?" — the scripts detect full vs subset, the picker falls back on its own, and the renderer emits every format. Ask only at the three gates, and only once each.

Permission prompts are the other kind of stop. The frontmatter above pre-approves the scripts for the turn that invokes this skill, but the grant clears on the next message and the run spans several. For a durable grant, once per machine:

```bash
node scripts/install-permissions.mjs            # user scope, or --project for this repo
```

It adds one `Bash(node scripts/<name>.mjs:*)` rule per script (relative and absolute forms) to Claude Code's settings and nothing broader — no blanket `Bash` or `node` allow. Restart the session after. If a prompt still appears, it's a command outside that list; say so rather than working around it.

## Before anything else

```bash
node scripts/preflight.mjs
```

Under a second. It reports the Node version, whether the skill files are intact, whether a local port can bind, and — the part that shapes the rest of the run — what tooling exists on this machine: `dtctl`, `jira`/`acli`/`confluence` CLIs on PATH, and any Dynatrace, Jira, Confluence or Atlassian MCP servers in Claude Code's config files. It writes `capabilities.json`, which step 1 carries into the run dir and the picker uses to grey out options that can't work here.

**Reconcile before moving on.** The script reads config; it cannot see the live session. Compare its MCP findings with the tools you can actually call right now:

- It lists an MCP you don't have tools for → not connected. `node scripts/preflight.mjs --set jira_mcp=no`
- You have Dynatrace or Jira tools it didn't find → `--set dynatrace_mcp=yes`
- A CLI is on PATH but the person says it isn't logged in → `--set dynatrace_cli=no`
- The team has its own triage skill → `--triage-skill <name or directory>`. Preflight also lists skills it found under `~/.claude/skills` and `./.claude/skills`, flagging triage-like ones; the picker offers them too.

Then proceed. Getting this right costs one line; getting it wrong means the picker offers Jira creation on a laptop that can't create Jiras, and the person finds out at step 5.

If Node is missing or too old, read `references/manual-fallback.md` and do the same work by reading the CSV directly — smaller volumes only.

Ask for the CSV path if it wasn't given. Never guess at a file. Every script accepts `--help`.

## Step 1 — Prep the file

```bash
node scripts/prep-incidents.mjs --csv "<path>"
```

Writes a run directory `./toil-run-YYYYMMDD-HHMM` (or wherever `--out` points). Add `--rules <team-rules.json>` for a team's own rule pack, `--mode full|subset` to override detection, `--top N` for more candidates, `--min-cluster N` to change what counts as repetitive.

The script sniffs delimiter and encoding, maps columns, categorises every incident (terms in the short description outweigh terms in the description, which outweigh close notes), groups near-duplicates into offenders, and scores them. It prints a summary and writes `summary.json`, `incidents_tagged.csv`, `clusters.csv`, `prep_report.md` and per-category subsets.

Hours per month are normalised over the window the dump covers, so six incidents in six days inside a 30-day export read as six a month, not thirty. The report says how many days were observed; quote that alongside any rate.

**Check the column map before going further.** If `missing_required` is non-empty, or most rows land in `uncategorized`, say so and fix it — usually the CSV was exported with display labels instead of field names, or the team's estate needs different rules. A bad mapping quietly poisons every number downstream.

Full vs subset is detected from ToilLens columns (`toil_score`, `toil_category`, `technical_hours`, `business_hours`). Present the detection, don't hide it — the person may have exported the wrong file.

## Step 2 — Confirm the target in the picker

```bash
node scripts/picker.mjs --run "<run dir>" --detach
```

This starts a small local page (127.0.0.1, random port — nothing is hosted), tries to open the person's browser, prints the URL, and returns immediately. Tell the person the page is open and what it's asking. If no tab appeared, give them the URL: on WSL, SSH sessions and containers there's often no browser helper to call.

Then poll for their answer:

```bash
node scripts/wait-selection.mjs --run "<run dir>"
```

It waits about 40 seconds and exits, so it never gets cut off mid-wait. Exit 0 means it prints their selection and you carry on. Exit 3 means no submit yet — run it again, as many times as the person reasonably needs. Exit 4 means the page timed out or was closed; relaunch with `--detach` or switch to chat.

Don't use the blocking form (`picker.mjs --run <dir>` with no `--detach`) from inside a session. It holds the command open until someone clicks, and people usually take longer than the harness will wait — the command gets moved to the background and you lose the thread even though the page is still up. The blocking form is for a person running the script themselves in a terminal.

The page collects: what to work on, how to gather evidence and how deep, what to produce. Options preflight didn't detect are greyed with the reason but stay clickable, because detection reads config rather than the live session — if the person picks a greyed option, ask whether that tool really is available before relying on it. When nothing was detected the page defaults to evidence `skip` and publish `none`, which is the honest starting point on a bare laptop. It writes `selection.json` and shuts down after one submit.

If the person would rather not use the page at all — or nothing can bind a local port — ask the three questions in conversation and write `selection.json` yourself, because the later scripts read it:

```json
{"target": "cat:control_m", "evidence": "dynatrace_mcp", "depth": "quick",
 "max_clusters": 8, "lookback_days": 30, "publish": ["jira", "confluence"], "draft_only": true}
```

`target` is `cat:<category_id>` from `summary.json`, two of them comma-separated (`cat:control_m,cat:mft_transfer`) when two toil items are in scope, or `all`. `evidence` is `dynatrace_mcp`, `dynatrace_cli`, `triage_skill` or `skip`. `depth` is `quick` or `standard`. With `triage_skill`, add `"triage_skill": {"name": "<skill name>", "path": "<dir or empty>"}` — the picker collects it from the skills preflight found, or a typed path.

For a **subset**, the picker pre-selects the dominant category; confirm rather than re-ask. For a **full dump**, the person picks one candidate, or two if both are in scope — each gets its own offender budget. Discourage `all` on a large dump — it burns hours of evidence gathering for a demo's worth of value. Suggest the top-scoring category and say why.

## Step 3 — Show the grouping before spending anything

```bash
node scripts/offenders.mjs --run "<run dir>"
```

Prints the offenders for the chosen category: id, name, count, window, hours per month, groups, sample incident numbers and text. Show it and ask for corrections. Two things go wrong here, both cheap now and expensive later:

- **Under-grouping** — one job appearing as three offenders because the wording varies. Merge them.
- **Over-grouping** — two different failures merged because their text is similar. This needs a more specific `offender_patterns` entry in the rule pack and a re-run of step 1; it can't be undone by an override.

Corrections go in `overrides.json` in the run dir, and every later step applies them automatically:

```json
{"merge": [["2dfc2115ec", "67a43f837b"]], "drop": ["fdbbc79bf0"], "rename": {"2dfc2115ec": "GL and PAY nightly chain"}}
```

The first id in a merge group survives with the combined counts, hours and window. Re-run `offenders.mjs` to confirm the result before moving on. Keep the file — it's how the next run on the same data reproduces the grouping, and it tells you what to fix in the rule pack.

## Step 4 — Gather evidence per offender, shallow by default

This step produces a **triage signal, not a root cause analysis**: one defensible line per offender saying what fails, how often, with what error. The person who picks up the Jira does the real investigation with the system in front of them and far better context than you have here.

Evidence is gathered **per offender, not per incident**. Investigating 14 incidents of the same job failure 14 times is exactly the toil this pipeline exists to remove.

```bash
node scripts/evidence-plan.mjs --run "<run dir>"
```

Prints the selected offenders in priority order with a bounded window, the single fact to retrieve, and **the exact DQL to run** for each (from the templates in `rules.json`, dates and search term filled in), and writes `evidence_plan.json`. With two targets the list is grouped by category and `max_clusters` applies to each.

**The budget, which is the whole point of this step:**
- `quick` depth (default): **one query per offender**. Eight offenders is eight queries.
- A second query only if the first returned nothing usable, once. If a third would be needed, mark that offender `low` confidence and move on.
- `standard` depth allows three per offender — for one or two that clearly matter, or when the person asks. Never across a whole list by default.
- Every query bounded to the plan's window and entity, aggregate in shape, with a top-N limit. No individual traces, no full stack traces, no per-incident lookups.
- Keep one line of error signature and one or two sentences of observation. Discard the rest; never paste raw tool output into the conversation or the ticket.
- Stop early if three offenders in a row return nothing — that usually means offender keys don't match entity names in their tenant. Ask rather than burn the budget.

### 4a. Write a brief per offender — this is where the AI earns its keep

```bash
node scripts/brief-inputs.mjs --run "<run dir>"
```

Prints, per planned offender, what the incidents actually say: the dominant short descriptions with counts, the description detail, **how they were closed** (the manual workaround — the toil in one sentence), CIs, groups, priority, handling time, and when they happen. Writes `brief_inputs.json`.

From that, write `briefs/<cluster_id>.md` for each offender following `references/brief-template.md`: ten lines, one question, what counts as an answer, and what to ignore. The static hint in `rules.json` is the floor; the brief is specific to these incidents. Two rules that matter: the brief contains **no cause and no fix** (that biases whoever answers it), and "Ignore" names the tempting expansions by name — the sibling job on the same agent, the second partner, the earlier window.

The brief is read twice: by whoever gathers evidence now, and by the person reviewing the ticket later who wants to know what question was asked. It's also attached to the Confluence page.

### 4b. Gather the evidence, by source

- **`dynatrace_mcp`** — `execute_dql` with the printed DQL; skip `verify_dql`, NL-to-DQL, CoPilot and analyzers. Read the brief first: its "Counts as an answer" decides what you keep and its "Ignore" decides what you drop, even if the query returned it.
- **`dynatrace_cli`** — `dtctl query "<printed DQL>" --plain -o json`. The DQL already limits rows. Ignore dtctl's own investigative skill here; the budget wins. Record the full command in `query`.
- **`triage_skill`** — the team's own skill, invoked once per offender under a contract:

  ```bash
  node scripts/delegation-prompt.mjs --run "<run dir>" --cluster "<id>"
  ```

  Prints the prompt: fixed scope (offender, window, entities, incident IDs — do not widen), the query budget, the brief, and the exact JSON to return. Invoke the skill with that prompt as its input and take the JSON it returns as the finding. Triage skills are written to be thorough — that's their job in an incident — so the contract is blunt on purpose, and it gives them one outlet: `out_of_scope_noted`, up to three one-liners for things seen outside the boundary. Those land on the Confluence page under "Seen but not investigated", so nothing is lost and nothing is chased.

  If the skill returns prose instead of JSON, don't reformat it yourself — invoke again with "return only the JSON object specified." If it keeps roaming, note it and fall back to the DQL path for that offender.
- **`skip`** — no queries. Every finding is `low` confidence and the output says plainly that no external evidence was gathered.

Categories like `credential_access`, `report_extract` and `data_fix` rarely appear in telemetry — no query, no delegation; rely on volume and repetition from the incident data.

### 4c. Check before rendering

```bash
node scripts/check-findings.mjs --run "<run dir>"
```

Validates every finding against the contract: unknown cluster ids, over-length fields, stack traces, evidence citing dates outside the window, causes stated as certainties, confidence or fix path outside the enum, savings larger than the offender costs, planned offenders with no finding. Exit 2 lists each problem with its fix. Fix them at the source — the renderer trims, but a trimmed sentence reads badly in a ticket.

Read `references/evidence.md` for the tool specifics and `references/triage-contract.md` for why the delegation prompt looks the way it does.

### 4d. Options, not orders — the part the SRE team actually uses

The finding's payoff is its **options**: two or three ways to take the offender off the team's plate, each with its effort and its effect in hours or incidents. A single "fix X" is often not actionable — the fix may sit with another team, need a change window, or not be worth it at this volume — and a ticket that only says "fix it" gets parked. Options give the owning team a real choice, and the value line makes acting on any of them visible.

Kinds, and what each is for:

| Kind | Meaning | Typical example |
|---|---|---|
| `remediate` | Remove the cause | Raise undo retention; fix the upstream feed |
| `dampen` | Reduce how often it fails or how much it hurts | Shift the schedule; add a retry; circuit-break |
| `automate` | Make the current manual workaround run without a person | AAP job template that does what the close notes describe |
| `detect` | Catch it earlier or cut alert noise | Pre-check alert; suppress the self-clearing one |
| `accept` | Document it and route it away from incident handling | Known-issue KB entry; auto-close with a note |

Rules for writing them:
- **Two or three, spanning at least two kinds.** A remediation and a damper; a damper and an automation. The `automate` option is usually available because the close notes describe the workaround — that is the toil, and automating it is the SRE move.
- **Effort as S/M/L** (hours / days / weeks) and **effect with a number**: incidents avoided per month, or handling time before and after. `hours_back_per_month` can't exceed what the offender costs; the plan shows that figure.
- **Owner hint** when the action sits with another team. That's the difference between a ticket that moves and one that doesn't.
- **`suggested_first` and `why_first`**: which option to try first and why, written as a suggestion — what it returns for the effort, and what it leaves open. The renderer frames it as "a reasonable first step" and says the owning team is best placed to choose. Never "you must", "this needs to be fixed". The checker flags that phrasing.
- **Value, stated plainly.** The Jira shows hours back per option; the Confluence page totals what the first steps would return to the team, and what the fuller options could. That total is the number the toil dashboard picks up.

Write `findings.json` in the run dir (the delegation path produces each entry; the DQL path means you write it):

```json
{
  "target": "cat:control_m",
  "evidence_source": "triage_skill",
  "depth": "quick",
  "lookback_days": 30,
  "findings": [
    {
      "cluster_id": "2dfc2115ec",
      "error_signature": "ORA-01555 snapshot too old at extract step 3",
      "evidence": [
        {"source": "incident-triage", "query": "<the query or command that was run>",
         "observed": "<one or two sentences with numbers>", "link": "<optional deep link>"}
      ],
      "root_cause_hypothesis": "Extract runs longer than undo retention when the upstream feed lands late",
      "confidence": "high",
      "options": [
        {"kind": "remediate", "action": "Raise undo retention on the extract schema, or split the extract so it commits earlier",
         "effort": "M", "effect": "Stops the failure; ~11 incidents/month avoided", "hours_back_per_month": 13, "owner_hint": "DBA team with batch owners"},
        {"kind": "automate", "action": "AAP job template: check feed arrival, then restart from step 3 once with no page-out",
         "effort": "S", "effect": "Failures still occur but resolve without a person; handling ~70 to ~5 min", "hours_back_per_month": 11, "owner_hint": "batch support"},
        {"kind": "dampen", "action": "Shift the job 30 minutes later so the feed has normally landed",
         "effort": "S", "effect": "Fewer failures on late-feed days; does not cover very late feeds", "hours_back_per_month": 6, "owner_hint": ""}
      ],
      "suggested_first": 1,
      "why_first": "It returns most of the handling time for an afternoon of work and leaves the remediation open once the DBA change is scheduled.",
      "out_of_scope_noted": ["CTM_PAY_EXTRACT shows the same ORA code on ctm-agent-02"]
    }
  ]
}
```

`cluster_id` comes from the plan — copy it exactly; it links the ticket to the incidents and drives dedup. Counts, windows, hours, offender names and the workaround line are filled from the cluster data and the brief, so don't retype them. Older findings with a single `fix_path`/`fix_summary` still render, as one option.

## Step 5 — Produce the drafts

```bash
node scripts/render-outputs.mjs --run "<run dir>" --project "<JIRA-PROJECT>" [--issue-type Task] [--existing existing_jira.json]
```

Everything follows `references/publishing-standard.md`: a Jira is six labelled blocks (What / Evidence / Likely cause / Options / A reasonable first step / Scope), around 200 words with three options, with the full incident list as an attachment, never inline; a Confluence page is one per category per run, titled `Toil · <Category> · <YYYY-MM>`, with an offenders table as its body, a "Seen but not investigated" list from the findings' out-of-scope notes, and the bulk in attachments. If either needs scrolling, something belongs in an attachment instead.

Per offender: a Markdown draft, a Jira wiki-markup draft (`.jira.txt`), and `attachments/incidents-<id>.csv`. Per category: the page as Markdown, plain HTML and storage format, plus `attachments/clusters-<cat>.csv` and `briefs-<cat>.md`. `attachments/manifest.json` says which files go on which ticket or page. Plus `drafts/jira/jira_payload.json`, `drafts/index.md` and `dashboard_summary.json`.

Which format to hand over depends on what the team has:
- Jira Cloud editor or an MCP that takes Markdown → the `.md`. Jira Server/DC, or the REST v2 `description` field → the `.jira.txt`. Pasting Markdown into DC renders the `#` signs literally, which looks sloppy in front of a reviewer.
- Confluence MCP or "insert Markdown" → the `.md`. No MCP → open the `.html` in a browser, select all, copy, paste into the Confluence editor; tables and headings survive. The `.storage.html` is only for the REST API or an MCP that takes storage format — pasted into the editor it shows raw tags.

**Deduplicate before creating anything.** If a Jira MCP is connected, query for label `toil-sig-*` (or the project's toil label), save the result as `existing_jira.json`, and pass `--existing`. Cluster ids are keyed on the offender, not the wording, so the same job failing again next quarter maps to the same id and gets skipped. Re-runs across months are the normal case, and a backlog full of duplicate toil tickets is how teams stop trusting the tool.

Then show `drafts/index.md` and stop. Do not create Jira issues or Confluence pages until the person says yes, even if `selection.json` lists `jira` and `confluence` — that selection is intent, not approval. If `draft_only` is true, don't create anything; hand over the drafts.

On approval:
- **Jira** — one issue per `"action": "create"` record in `jira_payload.json`, using its `summary`, `labels`, `issue_type`, the body from the format the team needs, and the attachment it lists. Report the created keys and write them back into `findings.json` as `jira_key`, then re-run `render-outputs.mjs` so the Confluence page shows the keys. No MCP? Hand over the payload, drafts and attachments for paste-in, and say that's what you're doing.
- **Confluence** — under the team's toil space, with the attachments from the manifest and the created Jira keys.

Finish by pointing at `dashboard_summary.json` — that's what the toil metrics dashboard consumes, so the numbers in the deck match the numbers in the tickets.

## What good output looks like

A Jira that a fixer can act on without re-reading the incidents: what fails, how often, over what window, the observed error, the proposed fix path, and what it currently costs per month. A Confluence page a manager can read in two minutes and see how many incidents fall in the category, which offenders drive it, and what's now in the backlog.

## Guardrails

- Never create tickets, pages or any other record without explicit approval in the conversation.
- Never invent an error message, a metric, a link or an hours figure. Missing evidence gets written down as missing.
- Evidence stays shallow on purpose: one bounded query per offender by default, aggregate results only, no raw tool payloads in the conversation or the tickets.
- Incident data stays local. Don't upload the CSV anywhere; the picker binds to 127.0.0.1 only.
- Watch for PII in incident text (names, account numbers, emails) before anything reaches Confluence. Redact and mention it.
- On a big file (>20k rows) or a broad target, warn about time before starting rather than halfway through. Prep itself is fast — 50k rows in a few seconds — the cost is in evidence.
- Counts are counts; causes are hypotheses. Keep that distinction visible in every artefact.

## Files

| File | Read it when |
|---|---|
| `scripts/install-permissions.mjs` | Once per machine — durable allow rules so nothing prompts |
| `scripts/preflight.mjs` | Start of every run — also detects MCPs, CLIs and local skills |
| `scripts/prep-incidents.mjs` | Step 1 |
| `scripts/picker.mjs` | Step 2 — launch with `--detach` |
| `scripts/wait-selection.mjs` | Step 2 — poll for the submit |
| `scripts/offenders.mjs` | Step 3 — review table, applies overrides |
| `scripts/evidence-plan.mjs` | Step 4 — bounded query plan |
| `scripts/brief-inputs.mjs` | Step 4a — facts for the per-offender brief |
| `scripts/delegation-prompt.mjs` | Step 4b — contract prompt for the team's triage skill |
| `scripts/check-findings.mjs` | Step 4c — validate findings, options and tone before rendering |
| `scripts/render-outputs.mjs` | Step 5 |
| `scripts/lib/csv.mjs`, `lib/text.mjs`, `lib/clusters.mjs` | Changing parsing, grouping or override behaviour |
| `assets/picker.template.html` | Restyling the picker (brand tokens at the top) |
| `references/rules.json` | Default categories, offender patterns, evidence hints, DQL templates; copy and tune per team |
| `references/evidence.md` | Step 4 — what to retrieve per category, MCP vs CLI |
| `references/brief-template.md` | Step 4a — how to write the brief, with an example |
| `references/triage-contract.md` | Step 4b — the delegation contract and why |
| `references/publishing-standard.md` | Step 5 — what goes in Jira vs Confluence, with examples |
| `references/manual-fallback.md` | Node unavailable or too old |
| `references/rollout.md` | Packaging this for other teams / Confluence distribution |
