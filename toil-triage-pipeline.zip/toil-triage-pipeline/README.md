# toil-triage-pipeline

A Claude Code skill that takes a ServiceNow incident CSV (a full dump, or a subset
exported from ToilLens) and walks it to a reviewed toil backlog: group repeat offenders,
gather one line of evidence per offender, draft Jira tickets and a Confluence page.

**Install:** unzip into `~/.claude/skills/` (personal) or your repo's `.claude/skills/`
(shared). Needs Node 16+ and nothing else — no npm install, no network.

**First use:** `node scripts/install-permissions.mjs` (per-script allow rules, so nothing prompts), then
**check it works:** `node scripts/preflight.mjs` — also reports which Dynatrace / Jira /
Confluence MCPs and CLIs it can find, so the picker only offers what will work here.

**Try it on synthetic data:** `node scripts/prep-incidents.mjs --csv assets/sample_incidents_synthetic.csv`

Then open `SKILL.md` — that's the full workflow Claude follows. `references/rollout.md`
covers tuning the rule pack for your estate and distributing this to other teams.

Incident data never leaves the laptop. The picker page binds to 127.0.0.1 only, opens
in your own browser, and exits after one click. If no browser opens (WSL, SSH, locked
down desktops), the URL is printed instead — or skip the page entirely and answer the
same three questions in chat.
