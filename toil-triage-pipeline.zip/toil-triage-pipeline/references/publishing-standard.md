# Publishing standard — Jira and Confluence

Two artefacts, two readers, two jobs. A Jira is for the person who will fix one offender: everything they need to start, nothing they'd have to scroll past. A Confluence page is for the person who owns the category: how big it is, what drives it, what's in the backlog. Neither is a place for the investigation itself — that lives in the run directory, and the attachments carry it.

The renderer (`render-outputs.mjs`) produces exactly this. Edit the standard here and the renderer together; don't hand-edit numbers into a ticket.

## Jira — one issue per offender

**Summary** (≤ 110 chars): `[<Category>] <Offender> — <N> incidents / <W>d — <first-step kind>`

**Description** — six labelled blocks, around 200 words with three options, in this order:

| Section | Content | Not this |
|---|---|---|
| **What** | Offender, count, window, handling groups. Current manual workaround in one sentence (from the close notes). Cost per month with basis. | Timeline of incidents; narrative |
| **Evidence** | One or two bullets: what was observed with numbers, the query in code, a deep link. Or "None gathered — incident text only." | Raw query output; stack traces; screenshots |
| **Likely cause** | One sentence, labelled as a hypothesis, with confidence. | Certainty; multiple competing theories |
| **Options** | Two or three, spanning at least two kinds (remediate / dampen / automate / detect / accept). Each: kind in bold, effort S/M/L, hours back per month, one concrete action, its effect in incidents or handling time, owner if it sits elsewhere. Framed as choices for the owning team. | A single "fix X"; implementation plans; instructions ("must", "should") |
| **A reasonable first step** | Which option first and why — what it returns for the effort and what it leaves open. A suggestion, not a directive. | "Do this" |
| **Scope** | "N incidents attached" + three example IDs + cluster id. | The full incident list inline |

**Labels:** `toil`, `toil-analyzer`, `toil-sig-<cluster_id>`, `<category_id>`. The `toil-sig` label is what stops the next quarter's run from raising a duplicate.

**Attachment:** `incidents-<cluster_id>.csv` — number, opened, short description, group, CI. This is the only place the full list lives.

**Priority, component, assignee:** left to the team. The renderer doesn't guess.

### Example

> **[Control-M job failure] CTM_GL_DAILY_LOAD — 8 incidents / 22d — automate the workaround**
>
> **What.** CTM_GL_DAILY_LOAD generated 8 incidents between 2026-07-29 and 2026-08-19, handled by BATCH-SUPPORT. Current workaround: restart the job from step 3; it then completes. Costing about 13.1 hours/month (reported).
>
> **Evidence.**
> - incident-triage: 8 ERROR lines in the window, all ORA-01555 at step 3, none with a different code. `fetch logs, from:… | filter contains(content,"CTM_GL_DAILY_LOAD") … | limit 5`
>
> **Likely cause.** Extract runs longer than undo retention when the upstream feed lands late — hypothesis, confidence high.
>
> **Options.** Ways to take this off the team's plate; the owning team is best placed to choose.
> 1. **Remove the cause** (effort M, ~13 hrs/month back) — Raise undo retention on the extract schema, or split the extract so it commits earlier. Stops the failure; ~11 incidents/month avoided. Owner: DBA team with batch owners.
> 2. **Automate the workaround** (effort S, ~11 hrs/month back) — AAP job template: check feed arrival, then restart from step 3 once with no page-out. Failures still occur but resolve without a person; handling ~70 to ~5 min. Owner: batch support.
> 3. **Reduce frequency or impact** (effort S, ~6 hrs/month back) — Shift the job 30 minutes later so the feed has normally landed. Fewer failures on late-feed days; does not cover very late feeds.
>
> **A reasonable first step.** Option 2 (automate) — It returns most of the handling time for an afternoon of work and leaves the remediation open once the DBA change is scheduled.
>
> **Scope.** 8 incidents attached (incidents-2dfc2115ec.csv); e.g. INC00100001, INC00100004, INC00100007. Cluster 2dfc2115ec.

That is the whole ticket. A fixer can start from any of the three; a reviewer can check the counts against the attachment; a manager can see what acting on it is worth. Nothing in it tells the owning team what they must do.

## Confluence — one page per category per run

**Title:** `Toil · <Category> · <YYYY-MM>` — one page per run, so re-runs are comparable side by side rather than edited in place.

**Body**, top to bottom:

1. **Info panel** (3 lines): source file, window and incident count, hours basis and evidence source.
2. **Summary** (2–3 sentences): incidents across offenders, hours per month, tickets raised, and what acting on the first steps would return to the team.
3. **Offenders table**: offender · incidents · hrs/month · common error · likely cause · options (kind and effort, first step starred) · Jira key. One row per offender; the table is the page.
4. **Seen but not investigated** (only if any): up to five one-liners aggregated from the findings' `out_of_scope_noted`. This is where a triage skill's wider observations go — recorded, not chased.
5. **Method** (2 lines): what produced the page and where the pipeline lives.
6. **Attachments**: `clusters-<category>.csv` (every offender, not just the investigated ones), `evidence_plan.json`, `briefs-<category>.md`.

**Not on the page:** per-incident lists, query results, the pipeline's mechanics, anything about how the person felt about the data. If the page needs scrolling on a laptop, it's carrying something that belongs in an attachment.

### Example

> **Toil · Control-M job failure · 2026-09**
>
> ℹ Generated 2026-09-17 from `august-incidents.csv` (60 incidents, 2026-07-29 to 2026-08-19). Hours basis: reported. Evidence: incident-triage, quick depth.
>
> 22 incidents across 3 offenders, currently about 36 hours per month. 2 Jira tickets raised (SRETOIL-101, SRETOIL-102); 1 offender not investigated this run. Acting on the suggested first step for each would return about 22 hours/month to the team (up to 25 with the fuller options).
>
> | Offender | Incidents | Hrs/mo | Common error | Likely cause | Options (* first) | Jira |
> |---|--:|--:|---|---|---|---|
> | CTM_GL_DAILY_LOAD | 8 | 13.1 | ORA-01555 at step 3 | Undo retention overrun on late feed | remediate (M) · automate (S)* · dampen (S) | SRETOIL-101 |
> | CTM_PAY_EXTRACT | 7 | 11.5 | ORA-01555 at step 3 | Shares the feed dependency | dampen (S)* · remediate (M) | SRETOIL-102 |
> | CTM_CARD_SETTLE | 7 | 11.5 | — | not investigated | — | — |
>
> **Seen but not investigated**
> - CTM_PAY_EXTRACT shows the same ORA code on ctm-agent-02.
>
> **Method.** Incidents grouped by offender from the ServiceNow export; one bounded query per offender; every finding reviewed before a ticket was raised. Pipeline: [Toil triage pipeline].
>
> **Attachments:** clusters-control-m.csv · evidence_plan.json · briefs-control-m.md

## Formats the renderer emits

| Target | File | Use when |
|---|---|---|
| Jira Cloud editor, most MCPs | `drafts/jira/<id>-<offender>.md` | Markdown is accepted |
| Jira Server/DC, REST v2 `description` | `drafts/jira/<id>-<offender>.jira.txt` | Markdown would render literal `#` |
| Confluence MCP, "insert Markdown" | `drafts/confluence/<cat>.md` | |
| No MCP: browser copy-paste | `drafts/confluence/<cat>.html` | Open, select all, paste into the editor |
| REST API / storage-format MCP | `drafts/confluence/<cat>.storage.html` | Never paste into the editor |
| Attachments for both | `attachments/` with `manifest.json` | Upload per the manifest |
