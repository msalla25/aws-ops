# Evidence per offender — deliberately shallow

Read this at step 4.

**What you are producing is a triage signal, not a root cause analysis.** One defensible sentence per offender: *this fails N times in this window with this error.* Someone who picks up the Jira does the real investigation with far better context than you have here. Trying to finish their job now costs a lot of tokens across dozens of offenders and produces a worse answer than they'd get in ten minutes with the system in front of them.

## The budget

Run `node scripts/evidence-plan.mjs --run <run dir>` first. It prints each offender with a bounded window, the one fact to get, and **the exact DQL to run**. Run that DQL as printed. Don't compose your own, don't widen it, don't add a second one because the first looked interesting.

Default (`quick` depth): **one query per offender**. Eight offenders means eight queries.

Escalate to a second query only when the first returned nothing usable, and only once — usually to swap the search term for the CI name, or to try the Davis problems template. If a third would be needed, that offender's confidence is `low` and you move on.

`standard` depth allows up to three per offender. Use it when the person explicitly asked, or for one or two offenders that clearly matter more than the rest. Never apply it to a whole list by default.

Two toil items in one run (the picker allows it) means each gets its own budget of `max_clusters` offenders. Work one item's list to the end before starting the next; don't interleave.

## Why the DQL is pre-written

Every template in `rules.json` ends in `summarize … | sort … | limit 5`. That's not style: the MCP's DQL tool caps responses at 1000 records, so a `fetch logs | filter …` with no aggregation can drop up to a thousand log lines into context for one offender. Five aggregated rows is the shape that keeps this cheap.

The templates are starting points — field names vary by tenant and extension (a queue-depth metric key, a log attribute name). Verify each template once in the team's tenant, fix it in their copy of `rules.json`, and it's reusable for every run after. The shape stays; only the names change.

Three templates cover the estate:

| Template | Used for | Returns |
|---|---|---|
| `log_signature` | Control-M, MFT, DataStage, JBoss, Oracle, Apigee, certificates | top 5 error lines containing the offender's search term, with counts and first/last seen |
| `metric` | filesystem, OpenShift restarts, MQ depth, Kafka lag | one daily max per host for the metric key in `rules.json` |
| `davis_problems` | alert noise, or as the one retry when logs show nothing | top 5 Davis problem names mentioning the offender |

Categories marked `none` (credential/access, report requests, data fixes) get no query. That work rarely appears in telemetry; the argument for automating it is the volume and repetition, which the incident data already gives you.

## Dynatrace MCP

Use `execute_dql` with the printed DQL. That's normally the only call per offender.

- Skip `verify_dql` for template DQL — it's another round trip per offender. If `execute_dql` returns a syntax error, fixing it is your one retry, and the fix goes into the team's `rules.json`.
- Skip `generate_dql_from_natural_language`, `explain_dql`, `chat_with_davis_copilot` and `execute_davis_analyzer` in this step. They return prose and cost extra calls; nothing here needs them.
- `find_entity_by_name` only when the `metric` template needs an entity id and the name filter in the template didn't match. One lookup, then the metric query.
- `list_problems` is a fine substitute for the `davis_problems` template — pass the offender's window as its timeframe rather than accepting the default.

Note which server you're on. The open-source local server is deprecated in favour of dtctl for Claude Code and a Dynatrace-hosted remote MCP for agent-to-agent use; tool names overlap but the remote server's DQL tool has the same record cap, so the discipline is identical.

## dtctl (Dynatrace CLI)

```
dtctl query "<printed DQL>" --plain -o json
```

`--plain -o json` gives structured output with no spinners or colour codes, which is what you want landing in context. The DQL already limits rows, so no extra trimming is needed; if a team's wrapper script returns more, pipe through `head -40`.

dtctl ships its own agent skill that teaches open-ended Dynatrace investigation. Don't let it lead here: this pipeline's budget is the instruction, and the query is already written. Record the full command in the finding's `query` field so a reviewer can re-run it.

## The brief governs what you keep

Before any query, read `briefs/<cluster_id>.md` for the offender (step 4a). Its "Counts as an answer" line is the stop condition and its "Ignore" line is the discard rule: a query that also returns the sibling job's errors has not widened the scope unless you keep them. The brief is written from the incidents' own words, so it tells you what the fixer needs — usually the same failure the close notes already name, confirmed with a count.

## If the source is the team's own triage skill

Don't hand the skill the brief on its own. Run `node scripts/delegation-prompt.mjs --run <run> --cluster <id>` and give it the printed prompt: scope as prohibitions, the query budget, the brief, and the exact JSON to return. `references/triage-contract.md` explains each part. Take the JSON as the finding, run `check-findings.mjs`, and if the skill returned prose or roamed, invoke once more with "return only the JSON object specified" — then fall back to the DQL path for that offender rather than reformatting a wide answer into a narrow ticket.

## Every query is bounded

- **Time**: the plan's window, already clamped to the lookback. Never unbounded, never "last 12 months to be safe."
- **Entity**: the offender's search term (dates and numbers masked out, so `payments_*.dat` searches for `payments`). If nothing matches, record that and drop confidence to `low` — don't go hunting the entity tree for something similar.
- **Shape**: aggregate. Counts, top error signature, a trend direction. Not individual traces, not full stack traces, not per-incident lookups.
- **Size**: `limit 5`. If a tool returns more anyway, keep the top few and discard the rest without reading it all.

## What to keep

Per offender, exactly this much:

- `error_signature` — one line, under ~150 characters: the top `sig` row from the query, trimmed. Not a stack.
- `observed` — one or two sentences with the numbers that matter: how many, over what period, any obvious clustering in time (the `first`/`last` columns tell you).
- `query` — the DQL or command you ran.
- `link` — a deep link if the tool gives one. It costs nothing and saves the fixer a search.

Discard everything else. Do not paste raw tool output into the conversation or the ticket — summarise and move on. Long payloads sitting in context make every subsequent offender more expensive.

## Stop conditions

- Three consecutive offenders returning nothing usually means the search terms don't match how this tenant names things — a Control-M job name may appear in logs on the agent host, not the job's own name. Stop, say so, and ask how offenders map to log content or entities in their tenant. Continuing burns budget for nothing.
- Evidence source is `skip`: no queries at all. Every finding is `low` confidence, and the output says plainly that no external evidence was gathered.

## What Dynatrace does not see in this estate

Control-M job status itself, MFT partner-side failures, credential resets, report requests, Oracle session-level detail. For those, the evidence is the downstream effect — the ORA- code in the app log, the handshake failure on the gateway — or nothing. Saying "not visible in telemetry" in the ticket is a legitimate, honest finding. Inventing a cause to fill the gap is the one thing that makes the whole page untrustworthy.
