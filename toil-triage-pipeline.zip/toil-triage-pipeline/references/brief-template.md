# The offender brief

One per planned offender, written by Claude from `brief_inputs.json` — not from the rule pack's static hint, which is only a floor. Saved as `briefs/<cluster_id>.md`. Ten lines or fewer. It has two readers: the triage skill (or you, running DQL), and the person reviewing the ticket later, who wants to know what question was asked.

A brief is a question with its boundaries. It is not a hypothesis and not an analysis. If you find yourself explaining the cause, stop — that's the evidence step's job, and pre-loading a cause into the brief biases whoever answers it.

## Template

```
# <offender> — <category label>
Incidents: <N> between <from> and <to>, handled by <groups>. Costing ~<hrs>/month (<basis>).
Symptom: <one sentence in the incidents' own words — quote the dominant short description>.
Detail: <one sentence from the description excerpts, if they add anything; otherwise omit>.
Current workaround: <one sentence from the close notes — what people do each time>.
Pattern: <timing / spread if it's real — "nightly around 02:00", "all on ctm-agent-01", "two partners, ACME0 and ACME1"; otherwise "no clear pattern in the incident data">.
Question: <the ONE thing evidence should establish, phrased so a yes/no or a single number answers it>.
Counts as an answer: <what a sufficient answer looks like — "the ORA code and how many times it appeared in the window", "queue depth trend and DLQ count">.
Ignore: <what is out of scope even if it looks related — other jobs on the same agent, other partners, anything outside the window>.
Search term: <search_term>   CI: <top CI>   Window: <from>..<to>
```

## Writing it

- **Symptom and workaround come from the incidents.** Quote or closely paraphrase `what_they_say` and `how_closed`. The workaround line is the most valuable one in the brief — it's the toil in one sentence, and it tells the investigator what the fixer is currently replacing.
- **The question is singular.** "What error does CTM_GL_DAILY_LOAD hit at step 3, and how often?" is a brief. "Investigate the GL load failures" is an invitation to roam.
- **"Counts as an answer" sets the depth.** It's the line that stops a capable triage skill from doing a full RCA. Make it concrete and small.
- **"Ignore" names the tempting expansions.** Use `brief_inputs` to spot them: a shared CI, a sibling job, a second partner. Name them explicitly — a skill told "ignore CTM_PAY_EXTRACT even though it shares the agent" behaves better than one told "stay focused."
- **Pattern is only stated when the data shows it.** Two incidents at 02:00 out of eight is not a pattern. Say "no clear pattern" rather than manufacturing one.
- **No cause, no fix, no recommendation.** Those go in the finding, after evidence.

## Example (from the synthetic sample)

```
# CTM_GL_DAILY_LOAD — Control-M job failure
Incidents: 8 between 2026-07-29 and 2026-08-19, handled by BATCH-SUPPORT. Costing ~13 hrs/month (reported).
Symptom: "Control-M job CTM_GL_DAILY_LOAD failed with abend."
Detail: Incidents record "Job abended at step 3. ORA-01555 snapshot too old during extract."
Current workaround: Restart the job from step 3; it then completes.
Pattern: Always ctm-agent-01, always step 3. No clear time-of-day pattern in the incident data.
Question: Is ORA-01555 the error at step 3 in every failure in the window, and how many failures were there?
Counts as an answer: The error signature at step 3 with a count for the window, and whether any failure had a different error.
Ignore: CTM_PAY_EXTRACT and CTM_CARD_SETTLE (same agent, separate offenders); anything before 2026-07-29; downstream report jobs.
Search term: CTM_GL_DAILY_LOAD   CI: ctm-agent-01   Window: 2026-07-29..2026-08-19
```

That brief costs about 120 tokens to write and saves far more than that in the evidence step, because whoever answers it has nowhere to wander.
