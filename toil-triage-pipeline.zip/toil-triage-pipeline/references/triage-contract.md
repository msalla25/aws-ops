# The triage delegation contract

`delegation-prompt.mjs` builds one prompt per offender for the team's own triage skill. This note explains the shape so it can be tuned without weakening it.

## The problem it solves

A good triage skill is thorough by design. During an incident, following a dependency to a neighbouring service is exactly right. Here it's the failure mode: eight offenders, each pulling in the shared agent, the sibling job, the upstream feed, last month's change — and the run costs ten times the budget while producing findings nobody can check against the incidents. The contract turns a thorough skill into a bounded one for the length of one call, without editing the skill.

## Four parts, in order

**Scope, stated as prohibitions.** Offender, window, entities, incident IDs — each with a "do not" attached: don't query outside the window, don't follow dependencies, don't look up incidents individually. Skills obey a prohibition more reliably than they infer a boundary from a description. "Focus on CTM_GL_DAILY_LOAD" is advice; "do not follow dependencies to other hosts, jobs, services or partners" is an instruction.

**Budget, as a number.** Queries allowed (from `depth`), aggregate only, and the stop condition: stop when the brief's "Counts as an answer" is met. The sentence "do not continue to root cause" is there because most triage skills have root cause as their finish line.

**The brief.** AI-written, specific to these incidents, and the only part of the prompt that changes per offender. Its "Ignore" line is what makes the scope concrete: naming the sibling job the skill will be tempted by works better than a general instruction to stay focused.

**Output as a schema.** One JSON object, field limits stated inline, enums for confidence and fix path, and a rule that anything else — background, timeline, recommendations — goes nowhere. The one release valve is `out_of_scope_noted`: up to three one-liners for things seen outside the boundary. It exists because a skill that notices something real and has no place to put it will put it in the analysis. Those lines end up on the Confluence page under "Seen but not investigated", so the observation survives without being chased.

## What the checker enforces afterwards

`check-findings.mjs` is the contract's other half. It rejects stack traces, over-length fields, evidence citing dates outside the window, causes stated as certainties, savings larger than the offender's cost, and findings for offenders that weren't planned. If a skill's output fails the check, the fix is to re-invoke with "return only the JSON object specified", not to reformat it by hand — reformatting is how a roaming analysis gets laundered into a tidy ticket.

## Tuning it for a specific skill

Keep the four parts and their order. Things that are safe to change per team:

- The wording of the prohibitions, if the skill has its own vocabulary (e.g. it calls entities "components").
- The evidence source name it writes into `source`.
- The example JSON values.

Things that weaken it if changed: removing the incident ID list (it's what makes "don't look them up individually" checkable), removing the stop condition, making `out_of_scope_noted` bigger than three, or letting prose accompany the JSON.

## When the skill and the contract disagree

Some skills refuse bounded work, or restate their own process before answering. Two invocations is the limit: once with the prompt, once with "return only the JSON object specified." After that, use the DQL path for that offender and say so in the finding's `evidence` — an honest DQL result beats a laundered narrative.
