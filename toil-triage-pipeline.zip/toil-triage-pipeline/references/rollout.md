# Rolling this out to other teams

The skill pairs with the ToilLens HTML: ToilLens produces the subset, this skill takes it from there. Distribute them together or teams will have half a pipeline.

## Package

```bash
zip -r toil-triage-pipeline.zip toil-triage-pipeline -x '*/node_modules/*' '*/.DS_Store'
```

Attach the zip to the same Confluence page that hosts the ToilLens HTML, versioned in the filename (`toil-triage-pipeline-v1.0.zip`). Keep source in GitLab and tag each release; the Confluence attachment is a copy of a tag, never the master copy.

Teams unzip into their skills directory (`~/.claude/skills/` for personal use, or the repo's `.claude/skills/` to share within a project). Nothing to install — Node 16+ stdlib only, no npm, no network. Two commands on first use: `node scripts/install-permissions.mjs` so the pipeline's scripts run without a permission prompt each (it adds per-script allow rules, nothing broader), then `node scripts/preflight.mjs`, which catches an old Node or a blocked local port before it wastes anyone's time.

## What each team should change

- `references/rules.json` — the only file most teams need to touch. Copy it, tune the terms, `offender_patterns`, the metric keys and the three DQL templates for their tenant (verify each template once with `execute_dql` or `dtctl query`; field names differ by extension), keep it in their own repo, pass it with `--rules`. Ask teams to send good rule packs back so the defaults improve. The `overrides.json` files teams write during step 3 are the best hint about which patterns need work.
- Jira project key and label convention in step 5. The ticket and page layout is `references/publishing-standard.md`; if a team wants a different layout, change the standard and the renderer together so both stay short.
- Their own triage skill, if they have one: `preflight.mjs --triage-skill <name>` or pick it in the picker. The delegation contract (`references/triage-contract.md`) keeps it inside the incident boundary; tune the wording, not the structure.
- The three brand colour tokens at the top of `assets/picker.template.html`, so the picker matches ToilLens.

## Onboarding a team in one session

1. They export incidents from ServiceNow with the agreed field list and run it through ToilLens.
2. They download a subset (or hand over the full dump).
3. Run this skill end to end with them watching. One run is worth any amount of documentation.
4. Sit with them on the rules file for their top two categories.
5. Agree the Jira label so dedup works across their re-runs.

## Keeping the numbers honest across teams

Everything reconciles because `dashboard_summary.json` comes from the same run that produced the tickets. Two things protect that:

- Never hand-edit numbers into a Jira or Confluence page. If a number is wrong, fix the rules or the grouping and re-run.
- Keep the run directory. It contains the column map, the tagged incidents, any overrides and the findings — it's the audit trail when someone asks where a number came from, which they will.

## For the exec view

`dashboard_summary.json` per team, collected on a shared drive or Confluence attachment, is enough to build the multi-team toil picture without any server: incidents by category, technical and business hours, offenders investigated, tickets raised, hours saved if fixed. Re-running the same team's export next quarter and comparing the two summaries is what shows a category actually shrinking — which is the only real proof the pipeline works.
