#!/usr/bin/env node
/**
 * delegation-prompt.mjs - the exact prompt handed to the team's own triage skill for
 * ONE offender: fixed boundaries and output schema from the plan, plus the AI-written
 * brief for specificity. Prints it and writes prompts/<cluster_id>.md.
 *
 *   node scripts/delegation-prompt.mjs --run ./run --cluster 2dfc2115ec
 *   node scripts/delegation-prompt.mjs --run ./run            # all planned offenders
 *
 * The contract is deliberately blunt. Triage skills are written to be thorough; this
 * one is being asked for a bounded answer, and the boundaries have to be stated in a
 * way that survives a skill whose own instructions say "investigate fully".
 */

import fs from 'node:fs';
import path from 'node:path';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) o[x.slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
  }
  return o;
}
const a = args(process.argv);
if (!a.run || a.help) {
  console.error('Usage: node delegation-prompt.mjs --run <run-dir> [--cluster id] [--skill name]');
  process.exit(a.help ? 0 : 1);
}
const load = (p, d = null) => (fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : d);
const plan = load(path.join(a.run, 'evidence_plan.json'));
if (!plan) { console.error('evidence_plan.json not found - run evidence-plan.mjs first.'); process.exit(1); }
const sel = load(path.join(a.run, 'selection.json'), {}) || {};
const cap = load(path.join(a.run, 'capabilities.json'), {}) || {};
const inputs = load(path.join(a.run, 'brief_inputs.json'), { offenders: [] });

const skillName = a.skill || sel.triage_skill?.name || cap.triage_skill?.name || '<the team triage skill>';
const skillPath = sel.triage_skill?.path || cap.triage_skill?.path || '';
const perOffender = plan.query_budget?.per_offender ?? 1;
const tagged = fs.existsSync(path.join(a.run, 'incidents_tagged.csv'))
  ? fs.readFileSync(path.join(a.run, 'incidents_tagged.csv'), 'utf8').split(/\r?\n/) : [];

function incidentIds(o) {
  const ids = new Set([o.cluster_id, ...(o.merged_from || [])]);
  // cheap scan of the tagged CSV: number is column 0, cluster_id is present as a cell
  const out = [];
  for (const line of tagged.slice(1)) {
    for (const id of ids) if (line.includes(id)) { out.push(line.split(',')[0]); break; }
  }
  return out;
}

function prompt(o) {
  const briefPath = path.join(a.run, 'briefs', `${o.cluster_id}.md`);
  const brief = fs.existsSync(briefPath) ? fs.readFileSync(briefPath, 'utf8').trim() : null;
  const bi = inputs.offenders.find((x) => x.cluster_id === o.cluster_id) || {};
  const ids = incidentIds(o);
  const shown = ids.slice(0, 10).join(', ') + (ids.length > 10 ? `, … (${ids.length} total)` : '');
  const cis = (bi.cis || []).map((c) => c.text).join(', ') || 'see brief';

  return `You are being invoked by the toil triage pipeline for ONE offender. Answer the brief below and nothing else.

SCOPE (fixed - do not widen)
- Offender: ${o.offender}   (search term: ${o.search_term || o.offender})
- Category: ${o.category_label}
- Time window: ${o.from} to ${o.to}. Do not query, read, or reason about anything outside it.
- Entities: ${cis}. Do not follow dependencies to other hosts, jobs, services or partners.
- Incidents in scope: ${shown || 'see brief'}. Do not look up incidents individually.

BUDGET
- At most ${perOffender} quer${perOffender === 1 ? 'y' : 'ies'}, aggregate only (counts, top error, trend). No per-incident lookups, no traces, no stack dumps.
- Stop when the brief's "Counts as an answer" is met. Do not continue to root cause.
- If the first query returns nothing usable, say so and set confidence to "low". Do not substitute a similar-looking entity.

BRIEF
${brief || `# ${o.offender} - ${o.category_label}
(No AI brief was written for this offender. Static guidance follows.)
Question: ${o.get_only}
Search term: ${o.search_term || o.offender}   Window: ${o.from}..${o.to}`}

OUTPUT
Return exactly one JSON object and no prose before or after it. Limits are enforced downstream; longer text is truncated.
{
  "cluster_id": "${o.cluster_id}",
  "error_signature": "<one line, max 150 chars: the exception or error as observed; empty string if none found>",
  "evidence": [
    {"source": "${skillName}", "query": "<what you ran, max 200 chars>", "observed": "<one or two sentences with numbers, max 400 chars>", "link": "<deep link or empty>"}
  ],
  "root_cause_hypothesis": "<max 300 chars; a hypothesis, stated as one; empty if the evidence doesn't support one>",
  "confidence": "<high|medium|low>",
  "options": [
    {"kind": "<remediate|dampen|automate|detect|accept>", "action": "<max 200 chars: one concrete change>", "effort": "<S|M|L>",
     "effect": "<max 200 chars: what changes for the team - incidents avoided per month, or handling time per incident>",
     "hours_back_per_month": <number, at most the offender's current ${o.hours_per_month ?? '?'} hrs/month>, "owner_hint": "<team or role, or empty>"}
  ],
  "suggested_first": <index into options>,
  "why_first": "<max 200 chars: why that option is a reasonable first step and what it does not preclude - a suggestion, not an instruction>",
  "out_of_scope_noted": ["<optional: one line each for anything relevant you saw OUTSIDE the scope; max 3; do not investigate it>"]
}

Options: give two or three, spanning at least two kinds. remediate = remove the cause; dampen = reduce how often it fails or how much it hurts (schedule shift, retry, circuit breaker); automate = make the current manual workaround run without a person; detect = catch it earlier or cut alert noise; accept = document it and route it away from incident handling. Each option states its effect in hours or incidents, because that is how the team decides. The fixer chooses; you suggest.
Confidence means: high = the evidence names the failure; medium = consistent but indirect; low = inference from incident text or an empty result.
Anything you would normally add - background, timeline, next steps - goes nowhere. If it matters, one line in out_of_scope_noted.`;
}

const targets = plan.offenders.filter((o) => !a.cluster || o.cluster_id === a.cluster);
if (!targets.length) { console.error(`No planned offender matches ${a.cluster}.`); process.exit(1); }
fs.mkdirSync(path.join(a.run, 'prompts'), { recursive: true });

let missingBriefs = 0;
for (const o of targets) {
  const text = prompt(o);
  fs.writeFileSync(path.join(a.run, 'prompts', `${o.cluster_id}.md`), text);
  if (!fs.existsSync(path.join(a.run, 'briefs', `${o.cluster_id}.md`))) missingBriefs++;
  if (a.cluster || targets.length === 1) console.log(text);
}
if (!(a.cluster || targets.length === 1)) {
  console.log(`Wrote ${targets.length} prompt(s) to ${path.join(a.run, 'prompts')}:`);
  for (const o of targets) console.log(`  ${o.cluster_id}  ${o.offender}`);
}
console.log(`\nSkill to invoke: ${skillName}${skillPath ? ` (${skillPath})` : ''}. Invoke it once per prompt; take the JSON it returns as that offender's finding.`);
if (missingBriefs) console.log(`WARNING: ${missingBriefs} offender(s) have no briefs/<id>.md - the static hint was used. Write the brief first for a tighter answer.`);
