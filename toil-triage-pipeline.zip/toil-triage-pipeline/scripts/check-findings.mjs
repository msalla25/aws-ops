#!/usr/bin/env node
/**
 * check-findings.mjs - validate findings.json against the contract before anything
 * is rendered. Catches what a roaming triage skill produces: long text, stack traces,
 * unknown cluster ids, evidence outside the window, causes stated as fact.
 *
 *   node scripts/check-findings.mjs --run ./toil-run-20260909
 *
 * Exit 0 = clean, 2 = violations (listed, with the fix). Nothing is modified.
 */

import fs from 'node:fs';
import path from 'node:path';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) o[x.slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
  }
  return o;
}
const a = args(process.argv);
if (!a.run || a.help) { console.error('Usage: node check-findings.mjs --run <run-dir> [--findings file]'); process.exit(a.help ? 0 : 1); }
const load = (p, d = null) => (fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : d);
const fpath = a.findings || path.join(a.run, 'findings.json');
const doc = load(fpath);
if (!doc) { console.error(`No findings at ${fpath}`); process.exit(1); }
const findings = Array.isArray(doc) ? doc : (doc.findings || []);
const plan = load(path.join(a.run, 'evidence_plan.json'), { offenders: [] });
const planned = new Map(plan.offenders.map((o) => [o.cluster_id, o]));

const LIMITS = { error_signature: 150, observed: 400, query: 200, root_cause_hypothesis: 300, fix_summary: 300 };
const CONF = ['high', 'medium', 'low'];
const FIX = ['aap_job_template', 'config_change', 'code_change', 'monitoring', 'process', 'vendor', 'unknown'];
const KINDS = ['remediate', 'dampen', 'automate', 'detect', 'accept'];
const EFFORT = ['S', 'M', 'L'];
const BOSSY = /\b(you (must|should|need to|have to)|must be fixed|needs? to be fixed|has to be fixed|immediately fix|fix this now)\b/i;
const STACKY = /(\n\s*at\s+[\w$.]+\(|Traceback \(most recent|Caused by:|\bstack ?trace\b|^\s+at\s)/im;
const CERTAIN = /\b(the root cause is|root cause:|is caused by|definitely|confirmed root cause)\b/i;

const problems = [];
const note = (id, msg, fix) => problems.push({ id, msg, fix });

if (!findings.length) note('-', 'findings.json has no findings', 'Write at least one finding per planned offender, or mark the run as evidence-skipped.');

const seen = new Set();
for (const f of findings) {
  const id = f.cluster_id || '(missing)';
  if (!f.cluster_id) note(id, 'missing cluster_id', 'Copy the id from the evidence plan.');
  else if (seen.has(id)) note(id, 'duplicate finding for this cluster', 'Keep one finding per offender.');
  seen.add(id);
  const p = planned.get(f.cluster_id);
  if (f.cluster_id && planned.size && !p) note(id, 'cluster_id is not in the evidence plan', 'Findings must map to planned offenders; re-run evidence-plan.mjs if the plan changed.');

  for (const [k, max] of Object.entries(LIMITS)) {
    if (k === 'observed' || k === 'query') continue;
    if (f[k] && String(f[k]).length > max) note(id, `${k} is ${String(f[k]).length} chars (max ${max})`, 'Shorten at the source - the renderer truncates, but a trimmed sentence reads badly.');
  }
  const ev = Array.isArray(f.evidence) ? f.evidence : [];
  if (ev.length > 3) note(id, `${ev.length} evidence entries (max 3)`, 'Keep the one or two that answer the brief.');
  ev.forEach((e, i) => {
    if (e.observed && String(e.observed).length > LIMITS.observed) note(id, `evidence[${i}].observed is ${String(e.observed).length} chars (max 400)`, 'Two sentences with numbers.');
    if (e.query && String(e.query).length > LIMITS.query) note(id, `evidence[${i}].query is long (max 200)`, 'Record the query, not its output.');
    if (STACKY.test(String(e.observed || ''))) note(id, `evidence[${i}].observed contains a stack trace`, 'Keep the exception class and message only.');
    if (p && e.observed) {
      const dates = String(e.observed).match(/\d{4}-\d{2}-\d{2}/g) || [];
      const outside = dates.filter((d) => d < p.from || d > p.to);
      if (outside.length) note(id, `evidence cites dates outside the window (${outside.join(', ')})`, `Bound queries to ${p.from}..${p.to}.`);
    }
  });
  if (STACKY.test(String(f.error_signature || ''))) note(id, 'error_signature looks like a stack trace', 'One line: exception class + message.');
  if (f.confidence && !CONF.includes(f.confidence)) note(id, `confidence "${f.confidence}" not in ${CONF.join('|')}`, 'Use the enum.');
  if (f.fix_path && !FIX.includes(f.fix_path)) note(id, `fix_path "${f.fix_path}" not recognised`, `Use one of ${FIX.join(', ')}.`);
  // options: the part the fixer acts on
  const opts = Array.isArray(f.options) ? f.options : [];
  if (!opts.length && !f.fix_path) note(id, 'no options and no fix_path', 'Give two or three options (remediate / dampen / automate / detect / accept), each with effort and effect.');
  if (opts.length > 3) note(id, `${opts.length} options (max 3)`, 'Keep the two or three that differ in kind or effort.');
  if (opts.length === 1 && f.confidence !== 'low') note(id, 'only one option offered', 'Add a second of a different kind (e.g. dampen or automate alongside remediate) so the team has a real choice.');
  if (opts.length >= 2 && new Set(opts.map((o) => o.kind)).size === 1) note(id, 'all options are the same kind', 'Span at least two kinds - a remediation and a damper, or a damper and an automation.');
  opts.forEach((o, i) => {
    if (!KINDS.includes(o.kind)) note(id, `options[${i}].kind "${o.kind}" not in ${KINDS.join('|')}`, 'Use the enum.');
    if (!EFFORT.includes(o.effort)) note(id, `options[${i}].effort "${o.effort}" not S|M|L`, 'S = hours, M = days, L = weeks.');
    if (!o.action) note(id, `options[${i}] has no action`, 'One concrete change.');
    if (String(o.action || '').length > 200) note(id, `options[${i}].action over 200 chars`, 'One sentence.');
    if (!o.effect) note(id, `options[${i}] has no effect`, 'State what changes for the team in incidents or hours.');
    if (String(o.effect || '').length > 200) note(id, `options[${i}].effect over 200 chars`, 'One sentence with a number.');
    if (o.hours_back_per_month != null && p && p.hours_per_month && o.hours_back_per_month > p.hours_per_month * 1.05) {
      note(id, `options[${i}].hours_back_per_month (${o.hours_back_per_month}) exceeds hours currently spent (${p.hours_per_month})`, 'An option cannot return more than the offender costs.');
    }
    if (BOSSY.test(String(o.action || '') + ' ' + String(o.effect || ''))) note(id, `options[${i}] is phrased as an instruction`, 'Describe the change and its effect; the owning team decides.');
  });
  if (opts.length) {
    if (f.suggested_first == null || !Number.isInteger(f.suggested_first) || f.suggested_first < 0 || f.suggested_first >= opts.length) note(id, 'suggested_first missing or out of range', 'Index of the option to try first.');
    if (!f.why_first) note(id, 'why_first missing', 'One sentence: why that option first, and what it does not preclude.');
    if (String(f.why_first || '').length > 200) note(id, 'why_first over 200 chars', 'One sentence.');
    if (BOSSY.test(String(f.why_first || ''))) note(id, 'why_first is phrased as an instruction', 'It is a suggestion to the owning team, not a directive.');
  }
  if (CERTAIN.test(String(f.root_cause_hypothesis || ''))) note(id, 'root_cause_hypothesis is stated as a certainty', 'Phrase it as a hypothesis; the ticket labels it as one.');
  if (!ev.length && f.confidence === 'high') note(id, 'confidence high with no evidence', 'Without evidence, confidence is low.');
  if (ev.length && !f.error_signature && f.confidence !== 'low') note(id, 'evidence present but no error_signature', 'Fill the signature from the observed result, or lower confidence.');
  const oos = Array.isArray(f.out_of_scope_noted) ? f.out_of_scope_noted : [];
  if (oos.length > 3) note(id, `${oos.length} out-of-scope notes (max 3)`, 'One line each, three at most.');
  if (oos.some((s) => String(s).length > 200)) note(id, 'an out_of_scope_noted entry is over 200 chars', 'One line each.');
  if (f.est_hours_saved_per_month && p && p.hours_per_month && f.est_hours_saved_per_month > p.hours_per_month * 1.05) {
    note(id, `est_hours_saved_per_month (${f.est_hours_saved_per_month}) exceeds hours currently spent (${p.hours_per_month})`, 'A fix cannot save more than the offender costs.');
  }
}
for (const o of plan.offenders) {
  if (!seen.has(o.cluster_id) && o.template !== 'none') note(o.cluster_id, `planned offender "${o.offender}" has no finding`, 'Add a finding, or note in the output that it was not investigated.');
}

if (!problems.length) {
  console.log(`findings.json: ${findings.length} finding(s), all within the contract.`);
  process.exit(0);
}
console.log(`findings.json: ${problems.length} issue(s)\n`);
for (const p of problems) console.log(`- [${p.id}] ${p.msg}\n    fix: ${p.fix}`);
process.exit(2);
