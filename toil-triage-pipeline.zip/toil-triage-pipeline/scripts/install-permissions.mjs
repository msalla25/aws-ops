#!/usr/bin/env node
/**
 * install-permissions.mjs - add allow rules for this skill's scripts to Claude Code
 * settings, so the pipeline runs without a permission prompt per command.
 *
 *   node scripts/install-permissions.mjs            # user scope: ~/.claude/settings.json
 *   node scripts/install-permissions.mjs --project  # project scope: ./.claude/settings.json
 *   node scripts/install-permissions.mjs --print    # just show the rules
 *
 * Rules use Claude Code's prefix syntax, Bash(prefix:*), one per script, in both the
 * relative form (run from the skill directory) and the absolute form (run from
 * anywhere). Nothing broader: no Bash(node:*), no wildcard over the whole tool.
 * Idempotent; keeps a .bak of the settings file it changes.
 */

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SKILL_DIR = path.resolve(HERE, '..');
const SCRIPTS = ['preflight.mjs', 'prep-incidents.mjs', 'picker.mjs', 'wait-selection.mjs', 'offenders.mjs',
  'evidence-plan.mjs', 'brief-inputs.mjs', 'delegation-prompt.mjs', 'check-findings.mjs', 'render-outputs.mjs'];

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) if (argv[i].startsWith('--')) o[argv[i].slice(2)] = 'true';
  return o;
}
const a = args(process.argv);
if (a.help) {
  console.error('Usage: node install-permissions.mjs [--project] [--print]');
  process.exit(0);
}

// Absolute form uses forward slashes on every platform - that's what Claude Code
// matches against, and it sidesteps backslash-escaping in JSON.
const abs = SKILL_DIR.replace(/\\/g, '/');
const home = os.homedir().replace(/\\/g, '/');
const tilde = abs.startsWith(home) ? '~' + abs.slice(home.length) : null;

const rules = [];
for (const s of SCRIPTS) {
  rules.push(`Bash(node scripts/${s}:*)`);
  rules.push(`Bash(node ${abs}/scripts/${s}:*)`);
  if (tilde) rules.push(`Bash(node ${tilde}/scripts/${s}:*)`);
}
// The pipeline's own file reads/writes inside a run dir: briefs, findings, overrides.
rules.push('Read', 'Write', 'Edit', 'Glob');

if (a.print) {
  console.log(JSON.stringify({ permissions: { allow: rules } }, null, 2));
  process.exit(0);
}

const target = a.project
  ? path.join(process.cwd(), '.claude', 'settings.json')
  : path.join(os.homedir(), '.claude', 'settings.json');

let settings = {};
if (fs.existsSync(target)) {
  try { settings = JSON.parse(fs.readFileSync(target, 'utf8')); }
  catch (e) { console.error(`${target} is not valid JSON (${e.message}). Fix it or move it aside, then re-run.`); process.exit(1); }
  fs.copyFileSync(target, target + '.bak');
}
settings.permissions = settings.permissions || {};
const allow = Array.isArray(settings.permissions.allow) ? settings.permissions.allow : [];
const before = allow.length;
for (const r of rules) if (!allow.includes(r)) allow.push(r);
settings.permissions.allow = allow;
fs.mkdirSync(path.dirname(target), { recursive: true });
fs.writeFileSync(target, JSON.stringify(settings, null, 2) + '\n');

console.log(`${target}: ${allow.length - before} rule(s) added, ${before} kept${fs.existsSync(target + '.bak') ? ' (backup: ' + path.basename(target) + '.bak)' : ''}.`);
console.log('Restart the Claude Code session for the rules to load. Scripts run from the skill directory or by absolute path will no longer prompt.');
console.log('If you run the scripts from a different checkout, re-run this from that copy.');
