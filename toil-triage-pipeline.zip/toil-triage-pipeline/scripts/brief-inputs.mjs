#!/usr/bin/env node
/**
 * brief-inputs.mjs - the compact facts behind each planned offender, so a short brief
 * can be written from what the incidents actually say without reading the CSV.
 *
 *   node scripts/brief-inputs.mjs --run ./toil-run-20260909
 *   node scripts/brief-inputs.mjs --run ./run --cluster 2dfc2115ec
 *
 * Per offender: the distinct short descriptions with counts, how the incidents were
 * closed (the manual workaround, usually), CIs, groups, priority, handling time, and
 * when they happen (hour-of-day and weekday). Writes brief_inputs.json and prints the
 * same thing compactly. Nothing here is a conclusion - it's the raw material for one.
 */

import fs from 'node:fs';
import path from 'node:path';
import { readCsv } from './lib/csv.mjs';
import { parseDate } from './lib/text.mjs';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) o[x.slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
  }
  return o;
}
const a = args(process.argv);
if (!a.run || a.help) {
  console.error('Usage: node brief-inputs.mjs --run <run-dir> [--cluster id] [--top 3]');
  process.exit(a.help ? 0 : 1);
}
const load = (p, d = null) => (fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : d);
const plan = load(path.join(a.run, 'evidence_plan.json'));
if (!plan) { console.error('evidence_plan.json not found - run evidence-plan.mjs first.'); process.exit(1); }
const top = parseInt(a.top || '3', 10);

const tagged = readCsv(path.join(a.run, 'incidents_tagged.csv')).rows;
// Overrides may have merged clusters: the plan lists merged_from ids, so gather all of them.
const wanted = plan.offenders.filter((o) => !a.cluster || o.cluster_id === a.cluster);

function topN(values, n = top, max = 140) {
  const c = new Map();
  for (const v of values) { const k = String(v || '').trim(); if (k) c.set(k, (c.get(k) || 0) + 1); }
  return [...c.entries()].sort((x, y) => y[1] - x[1]).slice(0, n).map(([k, v]) => ({ text: k.slice(0, max), count: v }));
}
function median(nums) {
  const v = nums.filter((n) => Number.isFinite(n)).sort((x, y) => x - y);
  return v.length ? v[Math.floor(v.length / 2)] : null;
}
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const out = [];
for (const o of wanted) {
  const ids = new Set([o.cluster_id, ...(o.merged_from || [])]);
  const rows = tagged.filter((r) => ids.has(r.cluster_id));
  const opened = rows.map((r) => parseDate(r.opened_at)).filter(Boolean);
  const hours = topN(opened.map((d) => `${String(d.getHours()).padStart(2, '0')}:00`), 2);
  const days = topN(opened.map((d) => DAYS[d.getDay()]), 2);
  const item = {
    cluster_id: o.cluster_id,
    offender: o.offender,
    search_term: o.search_term,
    category_id: o.category_id,
    category_label: o.category_label,
    incidents: rows.length,
    window: `${o.from} to ${o.to}`,
    what_they_say: topN(rows.map((r) => r.short_description)),
    detail: topN(rows.map((r) => r.description_excerpt), 2, 200),
    how_closed: topN(rows.map((r) => r.close_notes_excerpt), 2, 200),
    cis: topN(rows.map((r) => r.cmdb_ci), 3, 60),
    groups: [...new Set(rows.map((r) => r.assignment_group).filter(Boolean))].slice(0, 3),
    priority: topN(rows.map((r) => r.priority), 2, 30),
    median_handling_min: median(rows.map((r) => parseFloat(r.elapsed_min))),
    hours_per_month: o.hours_per_month,
    hours_basis: o.hours_basis,
    when: { hour_of_day: hours, weekday: days },
    static_hint: o.get_only,
    suggested_dql: o.suggested_dql || '',
  };
  out.push(item);
}
fs.writeFileSync(path.join(a.run, 'brief_inputs.json'), JSON.stringify({ generated_from: 'incidents_tagged.csv', offenders: out }, null, 2));

const fmt = (arr) => arr.map((x) => `"${x.text}" (x${x.count})`).join(' | ') || 'n/a';
for (const it of out) {
  console.log(`## ${it.offender}  [${it.cluster_id}]  ${it.category_label}  x${it.incidents}  ${it.window}`);
  console.log(`  say:      ${fmt(it.what_they_say)}`);
  if (it.detail.length) console.log(`  detail:   ${fmt(it.detail)}`);
  console.log(`  closed:   ${fmt(it.how_closed)}`);
  console.log(`  where:    CIs ${fmt(it.cis)} | groups ${it.groups.join(', ') || 'n/a'} | priority ${fmt(it.priority)}`);
  console.log(`  cost:     median handling ${it.median_handling_min ?? '?'} min | ~${it.hours_per_month} hrs/month (${it.hours_basis})`);
  console.log(`  when:     ${fmt(it.when.hour_of_day)} | ${fmt(it.when.weekday)}`);
  console.log(`  hint:     ${it.static_hint}`);
  console.log('');
}
console.log(`Wrote ${path.join(a.run, 'brief_inputs.json')}. Now write briefs/<cluster_id>.md for each (references/brief-template.md).`);
