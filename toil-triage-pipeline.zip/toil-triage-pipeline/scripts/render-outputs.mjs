#!/usr/bin/env node
/**
 * render-outputs.mjs - turn findings.json into Jira drafts, Confluence pages, the
 * attachments that carry the bulk, and a dashboard summary. Writes files only; it
 * never calls Jira or Confluence. The layout follows references/publishing-standard.md.
 *
 *   node scripts/render-outputs.mjs --run ./toil-run-20260909 --project SRETOIL
 *   node scripts/render-outputs.mjs --run ./run --existing existing_jira.json --issue-type Story
 *
 * Per offender:   drafts/jira/<id>-<offender>.md          Markdown (Jira Cloud editor, most MCPs)
 *                 drafts/jira/<id>-<offender>.jira.txt    Jira wiki markup (Jira Server/DC, REST v2)
 *                 attachments/incidents-<id>.csv          the full incident list (never inline)
 * Per category:   drafts/confluence/<cat>.md | .html | .storage.html
 *                 attachments/clusters-<cat>.csv, briefs-<cat>.md
 * Plus:           attachments/evidence_plan.json, attachments/manifest.json,
 *                 drafts/jira/jira_payload.json, drafts/index.md, dashboard_summary.json
 */

import fs from 'node:fs';
import path from 'node:path';
import { loadClusters } from './lib/clusters.mjs';
import { readCsv, writeCsv } from './lib/csv.mjs';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });

const KIND_LABEL = {
  remediate: 'Remove the cause',
  dampen: 'Reduce frequency or impact',
  automate: 'Automate the workaround',
  detect: 'Detect earlier / cut noise',
  accept: 'Accept and reroute',
};
// Legacy single fix_path findings become one option so older runs still render.
const LEGACY_KIND = { aap_job_template: 'automate', config_change: 'remediate', code_change: 'remediate',
  monitoring: 'detect', process: 'accept', vendor: 'remediate' };

/** Evidence is a triage signal, not a dump. Trim hard so an oversized tool payload
 *  can never end up pasted into a Jira or a Confluence page. */
const SIG_MAX = 150, OBS_MAX = 400, QUERY_MAX = 200, CAUSE_MAX = 300, OOS_MAX = 200;
const trim = (s, max) => {
  const one = String(s ?? '').replace(/\s+/g, ' ').trim();
  return one.length > max ? one.slice(0, max - 1).trimEnd() + '…' : one;
};

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) o[x.slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
  }
  return o;
}
const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const slug = (s) => (String(s ?? 'item').replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48) || 'item');
const round = (n) => Math.round(n * 10) / 10;
const load = (p, d = null) => (p && fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : d);
function optionsFor(f) {
  let opts = Array.isArray(f.options) ? f.options : [];
  if (!opts.length && f.fix_path && f.fix_path !== 'unknown') {
    opts = [{ kind: LEGACY_KIND[f.fix_path] || 'remediate', action: f.fix_summary || '', effort: '?', effect: '', hours_back_per_month: f.est_hours_saved_per_month ?? null, owner_hint: '' }];
  }
  return opts.slice(0, 3).map((o) => ({
    kind: o.kind, label: KIND_LABEL[o.kind] || o.kind || 'Option', action: trim(o.action, 200), effort: o.effort || '?',
    effect: trim(o.effect, 200), hours: o.hours_back_per_month ?? null, owner: trim(o.owner_hint, 60),
  }));
}
const firstOf = (m) => m.options[m.first] || m.options[0] || null;
const optionSummary = (m) => m.options.length
  ? m.options.map((o, i) => `${o.kind} (${o.effort})${i === m.first ? '*' : ''}`).join(' · ')
  : 'options to be defined';
const daysBetween = (a, b) => (a && b) ? Math.max(1, Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 864e5) + 1) : null;

function stamp(withTime = true) {
  const d = new Date(); const p = (n) => String(n).padStart(2, '0');
  const day = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  return withTime ? `${day} ${p(d.getHours())}:${p(d.getMinutes())}` : day;
}
const yearMonth = () => stamp(false).slice(0, 7);

// ---------------------------------------------------------------- main setup
const a = args(process.argv);
if (!a.run || a.help) {
  console.error('Usage: node render-outputs.mjs --run <run-dir> [--project KEY] [--issue-type Task] [--existing existing_jira.json] [--findings f]');
  process.exit(a.help ? 0 : 1);
}
const run = a.run;
const project = a.project || 'PROJECT';
const issueType = a['issue-type'] || 'Task';
const summary = load(path.join(run, 'summary.json'), {}) || {};
const sel = load(path.join(run, 'selection.json'), {}) || {};
const briefInputs = load(path.join(run, 'brief_inputs.json'), { offenders: [] });
const fpath = a.findings || path.join(run, 'findings.json');
const fdoc = load(fpath);
if (!fdoc) { console.error(`No findings file at ${fpath}. Write findings.json first (schema in SKILL.md).`); process.exit(1); }
const findings = Array.isArray(fdoc) ? fdoc : (fdoc.findings || []);
if (!findings.length) { console.error('findings.json has no findings.'); process.exit(1); }

const cfg = {
  lookback_days: fdoc.lookback_days ?? sel.lookback_days ?? '?',
  evidence: fdoc.evidence_source ?? sel.evidence ?? 'none',
  depth: fdoc.depth ?? sel.depth ?? 'quick',
  target: fdoc.target ?? sel.target ?? 'all',
  skill: sel.triage_skill?.name || '',
};
const evidenceLabel = cfg.evidence === 'triage_skill' && cfg.skill ? `${cfg.skill} (triage skill)` : cfg.evidence;

// Enrich from clusters (overrides applied): the pipeline's numbers, not retyped ones.
const { clusters, applied } = loadClusters(run);
const byId = new Map(clusters.map((c) => [c.cluster_id, c]));
const empty = (v) => v === undefined || v === null || v === '' || (Array.isArray(v) && !v.length);
const unknownIds = [];
for (const f of findings) {
  const base = byId.get(f.cluster_id);
  if (!base) { unknownIds.push(f.cluster_id); continue; }
  for (const k of ['category_label', 'category_id', 'first_seen', 'last_seen', 'technical_hours', 'business_hours',
    'estimated_hours', 'hours_basis', 'hours_per_month', 'sample_incidents', 'assignment_groups', 'merged_from']) {
    if (empty(f[k]) || f[k] === 0) f[k] = base[k];
  }
  if (!f.count) f.count = base.count;
  if (!f.offender) f.offender = base.offender;
}
if (unknownIds.length) {
  console.error(`WARNING: cluster_id not found in clusters.csv (or dropped by overrides): ${unknownIds.join(', ')}. Those findings render with only what they contain.`);
}

// The manual workaround, from the brief if written, else from the close notes.
function workaroundFor(id) {
  const bp = path.join(run, 'briefs', `${id}.md`);
  if (fs.existsSync(bp)) {
    const m = /^Current workaround:\s*(.+)$/im.exec(fs.readFileSync(bp, 'utf8'));
    if (m) return trim(m[1], 200);
  }
  const bi = briefInputs.offenders.find((o) => o.cluster_id === id);
  const hc = bi?.how_closed?.[0]?.text;
  return hc ? trim(hc, 200) : '';
}

const existing = a.existing ? (load(a.existing, []) || []) : [];
const seen = new Map();
for (const e of existing) for (const lab of e.labels || []) if (lab.startsWith('toil-sig-')) seen.set(lab.slice(9), e);

// ------------------------------------------------------------ one data model
function model(f) {
  const days = daysBetween(f.first_seen, f.last_seen);
  return {
    id: f.cluster_id,
    offender: f.offender || f.cluster_id,
    category: f.category_label || 'Toil',
    categoryId: f.category_id || 'uncategorized',
    count: f.count || 0,
    from: f.first_seen || '?', to: f.last_seen || '?', days,
    groups: f.assignment_groups || [],
    workaround: workaroundFor(f.cluster_id),
    signature: trim(f.error_signature, SIG_MAX),
    evidence: (f.evidence || []).slice(0, 3).map((e) => ({
      source: e.source || 'source', observed: trim(e.observed, OBS_MAX), query: trim(e.query, QUERY_MAX), link: e.link || '',
    })),
    cause: trim(f.root_cause_hypothesis, CAUSE_MAX),
    confidence: f.confidence || 'low',
    options: optionsFor(f),
    first: Number.isInteger(f.suggested_first) ? f.suggested_first : 0,
    whyFirst: trim(f.why_first, OOS_MAX),
    basis: f.hours_basis || 'estimated',
    hrsPerMonth: f.hours_per_month ?? null,
    estSaved: f.est_hours_saved_per_month ?? null,
    samples: (f.sample_incidents || []).slice(0, 3),
    merged: f.merged_from || [],
    oos: (f.out_of_scope_noted || []).slice(0, 3).map((s) => trim(s, OOS_MAX)),
    jiraKey: f.jira_key || '',
    labels: ['toil', 'toil-analyzer', `toil-sig-${f.cluster_id}`, slug(f.category_id || 'uncategorized').toLowerCase()],
    attachment: `incidents-${f.cluster_id}.csv`,
  };
}

const jiraSummary = (m) => trim(`[${m.category}] ${m.offender} — ${m.count} incidents / ${m.days ?? '?'}d — ${firstOf(m) ? firstOf(m).label.toLowerCase() : 'options tbd'}`, 110);

function whatLine(m) {
  return `${m.offender} generated ${m.count} incidents between ${m.from} and ${m.to}`
    + (m.groups.length ? `, handled by ${m.groups.join(', ')}` : '') + '.'
    + (m.workaround ? ` Current workaround: ${m.workaround.replace(/\.?$/, '.')}` : '')
    + (m.hrsPerMonth !== null ? ` Costing about ${m.hrsPerMonth} hours/month (${m.basis}).` : '')
    + (m.merged.length ? ` Includes ${m.merged.length} grouping(s) confirmed as the same failure.` : '');
}
const causeLine = (m) => m.cause ? `${m.cause} — hypothesis, confidence ${m.confidence}.` : `Not established (confidence ${m.confidence}).`;
const dot = (t) => String(t || '').replace(/[.\s]*$/, '.');
const optionMeta = (o) => [`effort ${o.effort}`, o.hours !== null ? `~${o.hours} hrs/month back` : null].filter(Boolean).join(', ');
const optionLine = (o, bold) => `${bold(o.label)} (${optionMeta(o)}) — ${dot(o.action)}`
  + (o.effect ? ` ${dot(o.effect)}` : '') + (o.owner ? ` Owner: ${o.owner}.` : '');
const firstLine = (m) => {
  const o = firstOf(m); if (!o) return '';
  return `Option ${m.first + 1} (${o.kind}) — ${m.whyFirst ? dot(m.whyFirst) : 'looks like a reasonable place to start.'}`;
};
const scopeLine = (m) => `${m.count} incidents attached (${m.attachment})` + (m.samples.length ? `; e.g. ${m.samples.join(', ')}` : '') + `. Cluster ${m.id}.`;

function jiraMarkdown(m) {
  const L = [`**What.** ${whatLine(m)}`, '', '**Evidence.**'];
  if (m.evidence.length) for (const e of m.evidence) L.push(`- ${e.source}: ${e.observed}` + (e.query ? ` \`${e.query}\`` : '') + (e.link ? ` [link](${e.link})` : ''));
  else L.push('- None gathered — incident text only.');
  if (m.signature) L.push('', `Common error: \`${m.signature}\``);
  L.push('', `**Likely cause.** ${causeLine(m)}`, '');
  if (m.options.length) {
    L.push('**Options.** Ways to take this off the team\'s plate; the owning team is best placed to choose.');
    m.options.forEach((o, i) => L.push(`${i + 1}. ${optionLine(o, (t) => `**${t}**`)}`));
    L.push('', `**A reasonable first step.** ${firstLine(m)}`);
  } else L.push('**Options.** To be defined with the owning team; the evidence above is the starting point.');
  L.push('', `**Scope.** ${scopeLine(m)}`);
  return L.join('\n');
}
function jiraWiki(m) {
  const code = (s) => `{{${String(s).replace(/[{}]/g, '')}}}`;
  const L = [`*What.* ${whatLine(m)}`, '', '*Evidence.*'];
  if (m.evidence.length) for (const e of m.evidence) L.push(`* ${e.source}: ${e.observed}` + (e.query ? ` ${code(e.query)}` : '') + (e.link ? ` [link|${e.link}]` : ''));
  else L.push('* None gathered — incident text only.');
  if (m.signature) L.push('', `Common error: ${code(m.signature)}`);
  L.push('', `*Likely cause.* ${causeLine(m)}`, '');
  if (m.options.length) {
    L.push('*Options.* Ways to take this off the team\'s plate; the owning team is best placed to choose.');
    m.options.forEach((o) => L.push(`# ${optionLine(o, (t) => `*${t}*`)}`));
    L.push('', `*A reasonable first step.* ${firstLine(m)}`);
  } else L.push('*Options.* To be defined with the owning team; the evidence above is the starting point.');
  L.push('', `*Scope.* ${scopeLine(m)}`);
  return L.join('\n');
}

// ---------------------------------------------------------- confluence page
function pageModel(catLabel, models, allClusters) {
  const investigated = new Set(models.map((m) => m.id));
  const rows = [
    ...models,
    ...allClusters.filter((c) => !investigated.has(c.cluster_id)).map((c) => ({
      id: c.cluster_id, offender: c.offender, count: c.count, hrsPerMonth: c.hours_per_month, signature: '', cause: '', options: [], first: 0, jiraKey: '', notInvestigated: true,
    })),
  ];
  const keys = models.map((m) => m.jiraKey).filter(Boolean);
  return {
    catLabel, catSlug: slug(catLabel).toLowerCase(),
    title: `Toil · ${catLabel} · ${yearMonth()}`,
    generated: stamp(false), source: path.basename(summary.source_csv || ''),
    total: summary.total_incidents, from: summary.date_range?.from || '?', to: summary.date_range?.to || '?',
    basis: summary.hours_basis || 'estimated', evidence: evidenceLabel, depth: cfg.depth, mode: summary.mode || 'full',
    incidents: rows.reduce((s, r) => s + (r.count || 0), 0),
    offenders: rows.length, investigated: models.length,
    perMonth: round(rows.reduce((s, r) => s + (r.hrsPerMonth || 0), 0)),
    saved: round(models.reduce((s, m) => s + ((firstOf(m)?.hours) || m.estSaved || 0), 0)),
    savedMax: round(models.reduce((s, m) => s + Math.max(0, ...m.options.map((o) => o.hours || 0), m.estSaved || 0), 0)),
    tickets: keys, drafts: models.length - keys.length,
    oos: [...new Set(models.flatMap((m) => m.oos))].slice(0, 5),
    rows,
    attachments: [`clusters-${slug(catLabel).toLowerCase()}.csv`, 'evidence_plan.json', `briefs-${slug(catLabel).toLowerCase()}.md`],
  };
}
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const summaryText = (p) => `${plural(p.incidents, 'incident')} across ${plural(p.offenders, 'offender')}, currently about ${p.perMonth} hours per month. `
  + (p.tickets.length ? `${plural(p.tickets.length, 'Jira ticket')} raised (${p.tickets.join(', ')})` : `${plural(p.drafts, 'ticket draft')} awaiting approval`)
  + (p.offenders > p.investigated ? `; ${plural(p.offenders - p.investigated, 'offender')} not investigated this run.` : '.')
  + (p.saved ? ` Acting on the suggested first step for each would return about ${p.saved} hours/month to the team${p.savedMax > p.saved ? ` (up to ${p.savedMax} with the fuller options)` : ''}.` : '');
const methodText = (p) => (p.mode === 'subset' ? 'ToilLens filtered the ServiceNow export; ' : 'The ServiceNow export was categorised by rule pack; ')
  + `incidents were grouped by offender and ${p.evidence === 'skip' || p.evidence === 'none' ? 'no external evidence was gathered' : `one bounded query was run per offender (${p.evidence}, ${p.depth} depth)`}. Every finding was reviewed by a person before a ticket was raised.`;
const cell = (r, k) => r.notInvestigated ? (k === 'cause' ? 'not investigated' : '—') : (r[k] || '—');

function confluenceMarkdown(p) {
  const L = [`# ${p.title}`, '',
    `> Generated ${p.generated} from \`${p.source}\` (${p.total} incidents, ${p.from} to ${p.to}). Hours basis: ${p.basis}. Evidence: ${p.evidence}, ${p.depth} depth.`, '',
    summaryText(p), '',
    '| Offender | Incidents | Hrs/mo | Common error | Likely cause | Options (* first) | Jira |', '|---|--:|--:|---|---|---|---|'];
  for (const r of p.rows) L.push(`| ${r.offender} | ${r.count} | ${r.hrsPerMonth ?? ''} | ${trim(cell(r, 'signature'), 70)} | ${trim(cell(r, 'cause'), 120)} | ${r.notInvestigated ? '—' : optionSummary(r)} | ${r.jiraKey || (r.notInvestigated ? '—' : 'draft')} |`);
  if (p.oos.length) L.push('', '**Seen but not investigated**', '', ...p.oos.map((s) => `- ${s}`));
  L.push('', `**Method.** ${methodText(p)}`, '', `**Attachments:** ${p.attachments.join(' · ')}`);
  return L.join('\n');
}
function confluenceBody(p) {
  const rows = p.rows.map((r) => '<tr>' + `<td>${esc(r.offender)}</td><td style="text-align:right">${r.count}</td><td style="text-align:right">${r.hrsPerMonth ?? ''}</td>`
    + `<td>${r.notInvestigated ? '—' : `<code>${esc(trim(r.signature, 70) || '—')}</code>`}</td><td>${esc(trim(cell(r, 'cause'), 120))}</td><td>${esc(r.notInvestigated ? '—' : optionSummary(r))}</td>`
    + `<td>${esc(r.jiraKey || (r.notInvestigated ? '—' : 'draft'))}</td></tr>`).join('\n');
  return `<h1>${esc(p.title)}</h1>
<p>${esc(summaryText(p))}</p>
<table><tbody>
<tr><th>Offender</th><th>Incidents</th><th>Hrs/mo</th><th>Common error</th><th>Likely cause</th><th>Options (* first)</th><th>Jira</th></tr>
${rows}
</tbody></table>
${p.oos.length ? `<h3>Seen but not investigated</h3>\n<ul>\n${p.oos.map((s) => `<li>${esc(s)}</li>`).join('\n')}\n</ul>` : ''}
<p><strong>Method.</strong> ${esc(methodText(p))}</p>
<p><strong>Attachments:</strong> ${p.attachments.map(esc).join(' · ')}</p>`;
}
const infoText = (p) => `Generated ${p.generated} from ${p.source} (${p.total} incidents, ${p.from} to ${p.to}). Hours basis: ${p.basis}. Evidence: ${p.evidence}, ${p.depth} depth.`;
const confluenceStorage = (p) => `<ac:structured-macro ac:name="info"><ac:rich-text-body><p>${esc(infoText(p))}</p></ac:rich-text-body></ac:structured-macro>\n${confluenceBody(p)}\n`;
const confluencePlainHtml = (p) => `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(p.title)}</title>
<style>body{font:14px/1.5 Arial,sans-serif;max-width:1100px;margin:24px auto;color:#1c1c1c}table{border-collapse:collapse;width:100%}
th,td{border:1px solid #ccc;padding:6px 8px;text-align:left;vertical-align:top}th{background:#f2f2f2}code{font-size:12px}
.note{background:#eef3fb;border-left:4px solid #4c7bd9;padding:8px 12px}</style></head><body>
<p class="note">${esc(infoText(p))}</p>
${confluenceBody(p)}
</body></html>\n`;

// ------------------------------------------------------------------ outputs
const jdir = path.join(run, 'drafts', 'jira');
const cdir = path.join(run, 'drafts', 'confluence');
const adir = path.join(run, 'attachments');
for (const d of [jdir, cdir, adir]) fs.mkdirSync(d, { recursive: true });

const tagged = fs.existsSync(path.join(run, 'incidents_tagged.csv')) ? readCsv(path.join(run, 'incidents_tagged.csv')).rows : [];
const manifest = { generated_at: stamp(), jira: {}, confluence: {} };

const payload = [], dupes = [], toCreate = [], models = [];
for (const f of findings) {
  const dup = seen.get(f.cluster_id);
  if (dup) f.jira_key = dup.key;
  const m = model(f);
  models.push(m);
  const base = `${m.id}-${slug(m.offender)}`;
  fs.writeFileSync(path.join(jdir, `${base}.md`), jiraMarkdown(m));
  fs.writeFileSync(path.join(jdir, `${base}.jira.txt`), jiraWiki(m));
  // attachment: every incident in this offender (including merged groupings)
  const ids = new Set([m.id, ...m.merged]);
  const rows = tagged.filter((r) => ids.has(r.cluster_id)).map((r) => ({
    number: r.number, opened_at: r.opened_at, short_description: r.short_description, assignment_group: r.assignment_group, cmdb_ci: r.cmdb_ci,
  }));
  writeCsv(path.join(adir, m.attachment), ['number', 'opened_at', 'short_description', 'assignment_group', 'cmdb_ci'], rows);
  manifest.jira[m.id] = { summary: jiraSummary(m), attachments: [path.join('attachments', m.attachment)] };
  const rec = {
    cluster_id: m.id, project, issue_type: issueType, summary: jiraSummary(m), labels: m.labels,
    description_markdown: path.join('drafts', 'jira', `${base}.md`),
    description_wiki: path.join('drafts', 'jira', `${base}.jira.txt`),
    attachments: [path.join('attachments', m.attachment)],
    duplicate_of: dup ? dup.key : null, action: dup ? 'skip-duplicate' : 'create',
  };
  payload.push(rec);
  (dup ? dupes : toCreate).push(rec);
}
fs.writeFileSync(path.join(jdir, 'jira_payload.json'), JSON.stringify(payload, null, 2));

const byCat = new Map();
for (const m of models) { if (!byCat.has(m.category)) byCat.set(m.category, []); byCat.get(m.category).push(m); }
const pages = [];
for (const [cat, ms] of byCat) {
  const catId = ms[0].categoryId;
  const catClusters = clusters.filter((c) => c.category_id === catId);
  const p = pageModel(cat, ms, catClusters);
  const base = path.join(cdir, p.catSlug);
  fs.writeFileSync(`${base}.md`, confluenceMarkdown(p));
  fs.writeFileSync(`${base}.html`, confluencePlainHtml(p));
  fs.writeFileSync(`${base}.storage.html`, confluenceStorage(p));
  // attachments: all offenders in the category, the plan, and the briefs
  writeCsv(path.join(adir, `clusters-${p.catSlug}.csv`),
    ['cluster_id', 'offender', 'count', 'first_seen', 'last_seen', 'hours_per_month', 'hours_basis', 'assignment_groups', 'sample_incidents'],
    catClusters.map((c) => ({ ...c, assignment_groups: c.assignment_groups.join('|'), sample_incidents: c.sample_incidents.join(' ') })));
  const briefs = catClusters.map((c) => path.join(run, 'briefs', `${c.cluster_id}.md`)).filter((f) => fs.existsSync(f));
  if (briefs.length) fs.writeFileSync(path.join(adir, `briefs-${p.catSlug}.md`), briefs.map((f) => fs.readFileSync(f, 'utf8').trim()).join('\n\n---\n\n') + '\n');
  manifest.confluence[cat] = { title: p.title, page: `${base}.md`, attachments: p.attachments.filter((n) => fs.existsSync(path.join(adir, n))).map((n) => path.join('attachments', n)) };
  pages.push({ base, title: p.title });
}
if (fs.existsSync(path.join(run, 'evidence_plan.json'))) fs.copyFileSync(path.join(run, 'evidence_plan.json'), path.join(adir, 'evidence_plan.json'));
fs.writeFileSync(path.join(adir, 'manifest.json'), JSON.stringify(manifest, null, 2));

const dash = {
  generated_at: stamp(false), source_csv: path.basename(summary.source_csv || ''), mode: summary.mode, target: cfg.target,
  window: summary.date_range || {}, observation_days: summary.observation_days, total_incidents_in_file: summary.total_incidents,
  hours_basis: summary.hours_basis, evidence_source: evidenceLabel, depth: cfg.depth,
  categories: (summary.categories || []).map((c) => ({
    category_id: c.category_id, label: c.label, incidents: c.incidents, share_pct: c.share_pct, technical_hours: c.technical_hours,
    business_hours: c.business_hours, estimated_hours: c.estimated_hours, hours_per_month: c.hours_per_month, priority_score: c.priority_score,
  })),
  offenders_investigated: models.length,
  incidents_in_scope: models.reduce((s, m) => s + m.count, 0),
  hours_per_month_in_scope: round(models.reduce((s, m) => s + (m.hrsPerMonth || 0), 0)),
  hours_back_first_step_per_month: round(models.reduce((s, m) => s + ((firstOf(m)?.hours) || m.estSaved || 0), 0)),
  hours_back_max_per_month: round(models.reduce((s, m) => s + Math.max(0, ...m.options.map((o) => o.hours || 0), m.estSaved || 0), 0)),
  options_by_kind: models.flatMap((m) => m.options.map((o) => o.kind)).reduce((acc, k) => ({ ...acc, [k]: (acc[k] || 0) + 1 }), {}),
  jira_to_create: toCreate.length, jira_duplicates_skipped: dupes.length, overrides_applied: applied,
};
fs.writeFileSync(path.join(run, 'dashboard_summary.json'), JSON.stringify(dash, null, 2));

const idx = [`# Drafts - ${stamp()}`, '',
  `- Offenders investigated: ${models.length}  (${dash.incidents_in_scope} incidents, ~${dash.hours_per_month_in_scope} hrs/month in scope)`,
  `- Jira to create: ${toCreate.length}   |   duplicates skipped: ${dupes.length}`,
  `- Hours back per month if each suggested first step is taken: ${dash.hours_back_first_step_per_month} (up to ${dash.hours_back_max_per_month} with fuller options)`];
if (applied.length) idx.push(`- Overrides applied: ${applied.join('; ')}`);
idx.push('', '## Jira drafts (Markdown + wiki markup; one incidents-<id>.csv attachment each)', '');
for (const r of payload) idx.push(`- [${r.duplicate_of ? `SKIP (dup of ${r.duplicate_of})` : 'CREATE'}] ${r.summary}  ->  \`${r.description_markdown}\``);
idx.push('', '## Confluence pages (.md / .html preview / .storage.html; attachments per manifest)', '', ...pages.map((p) => `- ${p.title}  ->  \`${p.base}.*\``));
idx.push('', `Attachments and manifest: \`${adir}\``);
fs.writeFileSync(path.join(run, 'drafts', 'index.md'), idx.join('\n') + '\n');
console.log(idx.join('\n'));
console.log(`\nDashboard summary: ${path.join(run, 'dashboard_summary.json')}`);
