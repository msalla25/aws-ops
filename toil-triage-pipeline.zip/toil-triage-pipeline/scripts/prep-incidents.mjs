#!/usr/bin/env node
/**
 * prep-incidents.mjs - turn a ServiceNow incident CSV into categorised, clustered
 * toil candidates. Works on a full unfiltered dump or a ToilLens-filtered subset.
 * Node stdlib only, no npm install, no network calls.
 *
 *   node scripts/prep-incidents.mjs --csv incidents.csv --out ./toil-run-20260909
 *   node scripts/prep-incidents.mjs --csv sub.csv --out ./run --rules my-rules.json --mode subset
 *
 * Writes into --out:
 *   summary.json           machine-readable picture of the run (drives the picker)
 *   column_map.json        which CSV header became which canonical field
 *   incidents_tagged.csv   every input row + category, signature, cluster id
 *   clusters.csv           one row per cluster (the "offenders")
 *   subsets/<category>.csv per-category incident subset
 *   prep_report.md         human-readable summary
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCsv, writeCsv } from './lib/csv.mjs';
import {


  CANONICAL, TOILLENS_MARKERS, REQUIRED, mapColumns, signature, categorise,
  extractOffender, normaliseOffender, parseDate, ymd, toFloat, clusterWithin, shortHash,
} from './lib/text.mjs';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });


const HERE = path.dirname(fileURLToPath(import.meta.url));

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const k = a.slice(2);
      const v = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
      o[k] = v;
    }
  }
  return o;
}

function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

const a = args(process.argv);
if (!a.csv || a.help) {
  console.error('Usage: node prep-incidents.mjs --csv <file> [--out <run-dir>] [--rules f] [--mode auto|full|subset] [--top N] [--min-cluster N]');
  console.error('  --out defaults to ./toil-run-YYYYMMDD-HHMM in the current directory.');
  process.exit(a.help ? 0 : 1);
}
const outDir = a.out || (() => {
  const d = new Date(); const p = (n) => String(n).padStart(2, '0');
  return `./toil-run-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
})();
const topN = parseInt(a.top || '8', 10);
const minCluster = parseInt(a['min-cluster'] || '2', 10);
const rulesPath = a.rules || path.join(HERE, '..', 'references', 'rules.json');

fs.mkdirSync(path.join(outDir, 'subsets'), { recursive: true });
// Carry the preflight result into the run dir so the picker (and the audit trail) have it.
for (const cand of [a.capabilities, path.join(process.cwd(), 'capabilities.json')].filter(Boolean)) {
  if (fs.existsSync(cand)) { fs.copyFileSync(cand, path.join(outDir, 'capabilities.json')); break; }
}

const { headers, rows, encoding, delimiter } = readCsv(a.csv);
const rules = JSON.parse(fs.readFileSync(rulesPath, 'utf8'));
const cmap = mapColumns(headers);
const missing = REQUIRED.filter((c) => !cmap[c]);
const markers = TOILLENS_MARKERS.filter((m) => cmap[m]);
let mode = a.mode && a.mode !== 'auto' ? a.mode : (markers.length ? 'subset' : 'full');

const g = (row, canon) => (cmap[canon] ? String(row[cmap[canon]] ?? '').trim() : '');

const records = rows.map((row, i) => {
  const blob = [g(row, 'short_description'), g(row, 'description'), g(row, 'close_notes'),
    g(row, 'category'), g(row, 'subcategory')].filter(Boolean).join(' ');
  const { cat, hits } = categorise({
    short_description: g(row, 'short_description'), description: g(row, 'description'),
    close_notes: g(row, 'close_notes'), category: g(row, 'category'), subcategory: g(row, 'subcategory'),
  }, rules);
  const opened = parseDate(g(row, 'opened_at'));
  const resolved = parseDate(g(row, 'resolved_at'));
  const elapsed = opened && resolved && resolved > opened
    ? Math.round(((resolved - opened) / 60000) * 10) / 10 : null;
  return {
    idx: i,
    number: g(row, 'number') || `ROW${i + 1}`,
    short_description: g(row, 'short_description'),
    assignment_group: g(row, 'assignment_group'),
    cmdb_ci: g(row, 'cmdb_ci'),
    priority: g(row, 'priority'),
    opened_at: g(row, 'opened_at'),
    resolved_at: g(row, 'resolved_at'),
    elapsed_min: elapsed,
    category_id: cat.id,
    category_label: cat.label,
    matched_terms: hits.join(', '),
    ...(() => { const o = normaliseOffender(extractOffender(blob, cat) || g(row, 'cmdb_ci')); return { offender: o.key, offender_search: o.search }; })(),
    signature: signature(blob),
    technical_hours: toFloat(g(row, 'technical_hours')),
    business_hours: toFloat(g(row, 'business_hours')),
    toil_score: toFloat(g(row, 'toil_score')),
    description_excerpt: g(row, 'description').replace(/\s+/g, ' ').slice(0, 200),
    close_notes_excerpt: g(row, 'close_notes').replace(/\s+/g, ' ').slice(0, 200),
    _raw: row,
  };
});

const catMeta = Object.fromEntries(rules.categories.map((c) => [c.id, c]));
catMeta[rules.uncategorized.id] = rules.uncategorized;

const byCat = new Map();
for (const r of records) {
  if (!byCat.has(r.category_id)) byCat.set(r.category_id, []);
  byCat.get(r.category_id).push(r);
}

const round = (n, d = 1) => Math.round(n * 10 ** d) / 10 ** d;

// Rates are normalised over the window the dump covers, not each cluster's own span:
// six incidents in six days inside a 30-day export is 6/month, not 30/month.
const allOpened = records.map((r) => parseDate(r.opened_at)).filter(Boolean).sort((x, y) => x - y);
const observationDays = allOpened.length
  ? Math.max(7, Math.round((allOpened[allOpened.length - 1] - allOpened[0]) / 864e5) + 1) : 30;
const perMonth = (hrs) => round(hrs / (observationDays / 30)); // observationDays is floored at 7 above

const clusters = [], catSummaries = [];

for (const [cid, recs] of byCat) {
  const meta = catMeta[cid];
  const defaultMin = meta.default_handling_minutes ?? 45;
  const auto = meta.automatability ?? 0.5;

  const known = recs.map((r) => r.elapsed_min).filter((m) => m && m < 60 * 72);
  const avgMin = known.length ? round(known.reduce((s, v) => s + v, 0) / known.length) : defaultMin;
  const techH = round(recs.reduce((s, r) => s + r.technical_hours, 0));
  const bizH = round(recs.reduce((s, r) => s + r.business_hours, 0));
  const estH = round((recs.length * avgMin) / 60);
  const reported = techH > 0 || bizH > 0;

  const clOut = [];
  const idSeen = new Map();
  for (const [sig, crecs] of clusterWithin(recs)) {
    const counts = new Map();
    for (const r of crecs) if (r.offender) counts.set(r.offender, (counts.get(r.offender) || 0) + 1);
    const key = [...counts.entries()].sort((x, y) => y[1] - x[1])[0]?.[0] || '';
    const search = (crecs.find((r) => r.offender === key) || {}).offender_search || key;
    // Stable across re-runs: keyed on offender (not wording) so the same job failing
    // again next quarter maps to the same id and dedup against Jira works. A second
    // cluster under one offender gets a numbered suffix.
    const baseKey = key ? key.toLowerCase() : sig;
    const n = (idSeen.get(`${cid}|${baseKey}`) || 0); idSeen.set(`${cid}|${baseKey}`, n + 1);
    const clusterId = shortHash(`${cid}|${baseKey}|${n}`);
    const dates = crecs.map((r) => parseDate(r.opened_at)).filter(Boolean).sort((x, y) => x - y);
    const cTech = round(crecs.reduce((s, r) => s + r.technical_hours, 0));
    const cBiz = round(crecs.reduce((s, r) => s + r.business_hours, 0));
    const cEst = round((crecs.length * avgMin) / 60);
    const repetitive = crecs.length >= minCluster;
    const spanDays = dates.length ? Math.max(1, Math.round((dates[dates.length - 1] - dates[0]) / 864e5) + 1) : 0;
    const hrsInScope = (cTech || cBiz) ? cTech + cBiz : cEst;
    const hoursPerMonth = perMonth(hrsInScope);
    const entry = {
      cluster_id: clusterId,
      category_id: cid,
      category_label: meta.label,
      offender: key || '(no offender key extracted)',
      offender_search: search,
      signature: sig,
      count: crecs.length,
      distinct_ci: new Set(crecs.map((r) => r.cmdb_ci).filter(Boolean)).size,
      first_seen: ymd(dates[0]),
      last_seen: ymd(dates[dates.length - 1]),
      technical_hours: cTech,
      business_hours: cBiz,
      estimated_hours: cEst,
      hours_basis: cTech || cBiz ? 'reported' : 'estimated',
      hours_per_month: hoursPerMonth,
      span_days: spanDays,
      observation_days: observationDays,
      automatability: auto,
      sample_incidents: crecs.slice(0, 5).map((r) => r.number),
      sample_text: (crecs[0].short_description || '').slice(0, 180),
      assignment_groups: [...new Set(crecs.map((r) => r.assignment_group).filter(Boolean))].slice(0, 4),
      repetitive,
      priority_score: round(((cTech || cBiz) ? cTech + cBiz : cEst) * auto * (repetitive ? 1.25 : 0.6)),
    };
    for (const r of crecs) r.cluster_id = clusterId;
    clOut.push(entry);
    clusters.push(entry);
  }

  clOut.sort((x, y) => y.priority_score - x.priority_score);
  catSummaries.push({
    category_id: cid,
    label: meta.label,
    incidents: recs.length,
    share_pct: round((100 * recs.length) / Math.max(1, records.length)),
    clusters: clOut.length,
    repetitive_clusters: clOut.filter((c) => c.repetitive).length,
    avg_handling_minutes: avgMin,
    technical_hours: techH,
    business_hours: bizH,
    estimated_hours: estH,
    hours_basis: reported ? 'reported' : 'estimated',
    automatability: auto,
    priority_score: round((reported ? techH + bizH : estH) * auto),
    hours_per_month: perMonth(reported ? techH + bizH : estH),
    top_clusters: clOut.slice(0, 5),
  });
}

catSummaries.sort((x, y) => y.priority_score - x.priority_score);
clusters.sort((x, y) => y.priority_score - x.priority_score);

// ------------------------------------------------------------------- writing
fs.writeFileSync(path.join(outDir, 'column_map.json'), JSON.stringify({
  encoding, delimiter, headers, mapped: cmap,
  unmapped_headers: headers.filter((h) => !Object.values(cmap).includes(h)),
  missing_required: missing,
}, null, 2));

const taggedCols = ['number', 'category_id', 'category_label', 'offender', 'signature', 'matched_terms',
  'short_description', 'assignment_group', 'cmdb_ci', 'priority', 'opened_at', 'resolved_at',
  'elapsed_min', 'technical_hours', 'business_hours', 'cluster_id', 'description_excerpt', 'close_notes_excerpt'];
writeCsv(path.join(outDir, 'incidents_tagged.csv'), taggedCols,
  records.map((r) => Object.fromEntries(taggedCols.map((k) => [k, r[k] ?? '']))));

const clusterCols = ['cluster_id', 'category_id', 'category_label', 'offender', 'offender_search', 'count', 'distinct_ci',
  'first_seen', 'last_seen', 'span_days', 'observation_days', 'technical_hours', 'business_hours', 'estimated_hours', 'hours_basis',
  'hours_per_month', 'priority_score', 'repetitive', 'assignment_groups', 'sample_incidents', 'sample_text'];
writeCsv(path.join(outDir, 'clusters.csv'), clusterCols, clusters.map((c) => ({
  ...c, sample_incidents: c.sample_incidents.join(' '), assignment_groups: c.assignment_groups.join('|'),
})));

for (const [cid, recs] of byCat) {
  const safe = cid.replace(/[^a-z0-9_]+/gi, '_');
  writeCsv(path.join(outDir, 'subsets', `${safe}.csv`), headers, recs.map((r) => r._raw));
}

const openedDates = allOpened.map(ymd);
const summary = {
  generated_at: stamp(),
  source_csv: path.resolve(a.csv),
  run_dir: path.resolve(outDir),
  mode,
  mode_reason: markers.length
    ? `ToilLens columns present: ${markers.join(', ')}`
    : 'no ToilLens columns found - treating as a full unfiltered dump',
  total_incidents: records.length,
  date_range: { from: openedDates[0] || '', to: openedDates[openedDates.length - 1] || '' },
  observation_days: observationDays,
  hours_basis: catSummaries.some((c) => c.hours_basis === 'reported') ? 'reported' : 'estimated',
  column_map: cmap,
  missing_required: missing,
  unmapped_headers: headers.filter((h) => !Object.values(cmap).includes(h)).slice(0, 20),
  categories: catSummaries,
  top_candidates: clusters.slice(0, topN).map((c) => ({
    cluster_id: c.cluster_id, category_id: c.category_id, category_label: c.category_label,
    offender: c.offender, count: c.count, technical_hours: c.technical_hours,
    business_hours: c.business_hours, estimated_hours: c.estimated_hours, hours_basis: c.hours_basis,
    priority_score: c.priority_score, first_seen: c.first_seen, last_seen: c.last_seen,
    hours_per_month: c.hours_per_month, span_days: c.span_days,
    sample_text: c.sample_text, sample_incidents: c.sample_incidents,
  })),
  assignment_groups: [...records.reduce((m, r) => {
    if (r.assignment_group) m.set(r.assignment_group, (m.get(r.assignment_group) || 0) + 1);
    return m;
  }, new Map())].sort((x, y) => y[1] - x[1]).slice(0, 10).map(([k]) => k),
};
fs.writeFileSync(path.join(outDir, 'summary.json'), JSON.stringify(summary, null, 2));

const lines = [
  `# Prep report - ${summary.generated_at}`, '',
  `- Source: \`${path.basename(a.csv)}\` (${records.length} incidents, ${encoding}, delimiter "${delimiter === '\t' ? 'tab' : delimiter}")`,
  `- Detected as: **${mode.toUpperCase()} list** - ${summary.mode_reason}`,
  `- Window: ${summary.date_range.from || '?'} to ${summary.date_range.to || '?'}`,
  `- Hours basis: **${summary.hours_basis}**; rates normalised over ${observationDays} observed days`, '',
];
if (missing.length) lines.push(`> Missing required columns: ${missing.join(', ')} - map them before trusting the output.`, '');
lines.push('## Categories', '', '| Category | Incidents | % | Offenders | Tech hrs | Biz hrs | Hrs/month | Score |', '|---|---:|---:|---:|---:|---:|---:|---:|');
for (const c of catSummaries) {
  const h = c.hours_basis === 'reported' ? `${c.technical_hours}` : `~${c.estimated_hours}`;
  lines.push(`| ${c.label} | ${c.incidents} | ${c.share_pct}% | ${c.clusters} | ${h} | ${c.business_hours} | ${c.hours_per_month} | ${c.priority_score} |`);
}
lines.push('', '## Top candidates', '');
summary.top_candidates.forEach((c, i) => {
  lines.push(`${i + 1}. **${c.category_label}** - \`${c.offender}\` x${c.count} (${c.first_seen} to ${c.last_seen}), ~${c.hours_per_month} hrs/month ${c.hours_basis}, score ${c.priority_score} [${c.sample_incidents.slice(0, 3).join(', ')}]`);
});
fs.writeFileSync(path.join(outDir, 'prep_report.md'), lines.join('\n') + '\n');

console.log(lines.slice(0, 60).join('\n'));
console.log(`\nWrote run directory: ${path.resolve(outDir)}`);
if (missing.length) console.log(`WARNING: unmapped required fields: ${missing.join(', ')}`);
