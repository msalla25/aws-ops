# RUNBOOK — execute in order, do not skip

This is the execution script. Follow it top to bottom. Each step has an **EXIT CHECK** you
must satisfy before moving on. If an exit check fails, stay in that step.

Do not read all reference files up front. Read each one at the step that names it.

---

## STATE block

After every step and every interview round, print this block. Nothing else keeps a long
build on track:

```
STATE
  step        : <n> of 7
  preflight   : <not-run | done, mode=full|limited|offline>
  skills read : <count> (<names>)
  estate      : <unconfirmed | confirmed>
  rounds done : <list>
  blocking gaps open : <count>
  next        : <the literal next action>
```

If the conversation has gone long and you are unsure where you are, re-print STATE from what
you can verify in the transcript. Do not guess a later step than you can prove.

---

## Step 1 — Preflight

Run: `sh assets/preflight.sh`

If you cannot execute shell commands, paste the script to the user and ask for its output.
If that fails too, ask the user directly: "Do you have Dynatrace UI, `oc` CLI, AWS console,
Control-M console, and database read access on this machine?"

Set `mode`:
- **full** — shell works and most CLIs present
- **limited** — shell works, few CLIs
- **offline** — no shell execution available

**EXIT CHECK:** you have written down a mode. Print STATE.

---

## Step 2 — Find and read the existing skills

Look in this order, stop when you find skills:
1. `~/.claude/skills/`
2. `.claude/skills/`
3. any path the user names
4. `find . -name "SKILL.md" -not -path "*/node_modules/*" 2>/dev/null`

Read every `SKILL.md` found, and every file in their `references/` directories. Read them in
full. Do not summarize from filenames.

Then output this table to the user. You may not proceed without producing it:

| Skill | Covers | Facts I extracted | Reuse as-is? |
|---|---|---|---|

Then write `build-notes.md` in the working directory with the raw extracted facts, grouped:
applications, components, process group / entity names, Dynatrace tenant + management zones +
DQL, existing triage steps, stated rules and thresholds, tool references.

Copy facts **verbatim**. Do not paraphrase a threshold, an entity name, or a query. If you
rewrite it, you may introduce an error into material that was already correct.

**EXIT CHECK:** the table is printed and `build-notes.md` exists with at least one fact per
group, or an explicit "none found" per group. Print STATE.

---

## Step 3 — Confirm the estate

Read `references/interview.md`, section "Estate summary". Print that table to the user and
ask the four confirmation questions in it (WS, Oracle, Inspire/GMC, MQ).

Do not proceed on assumptions here. These four terms determine which commands end up in front
of the team, and two of them have look-alike products with completely different diagnostics.

**EXIT CHECK:** all four confirmed or explicitly marked unknown. Print STATE.

---

## Step 4 — Gap analysis

Read `references/coverage-checklist.md`. Score every line against `build-notes.md` as
**covered** (name the source skill), **partial**, or **missing**.

Print the result grouped by section, `[must]` items first. Then say one sentence: how many
`[must]` items are still open.

**EXIT CHECK:** every checklist line has a score. Print STATE.

---

## Step 5 — Interview

Read `references/interview.md` in full now.

Run the rounds **in order**. Hard rules, no exceptions:

- **Maximum 7 questions per message.** Count them before sending.
- **Every question must carry a pre-filled draft answer** when `build-notes.md` has anything
  relevant. Use this exact shape:

  > *From your triage skill I have `<fact>`. Still correct?*

  Not: *What is your <thing>?* The second form makes the user do work they already did.
- **Do not start the next round** until the current round's blocking questions are answered
  or explicitly deferred.
- Record every "I don't know" verbatim into `KNOWN-GAPS.md` immediately, with who could answer.
  Never fill a gap with a plausible value.
- After each round: append answers to `build-notes.md`, then print STATE.

Stop-anytime rule: after each round the material must be *narrower but still correct* if the
user quits. Never leave the build in a state where stopping produces something wrong.

**EXIT CHECK:** Rounds 1–6 done or explicitly deferred by the user. Rounds 7–8 optional.
Print STATE.

---

## Step 6 — Assemble the pack

Read `references/output-template.md` now, and follow it.

The critical rule for this step: **the safety and structure sections are copied verbatim from
`assets/boilerplate/`, not composed by you.** Your job there is to fill `<SLOTS>`, not to
write prose. Composing your own version of the guardrails produces weaker guardrails.

Order of assembly:
1. `SKILL.md` — copy `assets/boilerplate/skill-header.md`, fill slots, then add the routing
   table and playbooks from interview material
2. `assets/incident-note.md` — copy verbatim, no edits
3. `assets/preflight.sh` — copy, then fill the `CHANGE_ME` endpoints from Round 3 answers
4. `references/*.md` — only files you have real content for
5. `INSTALL.md`, `KNOWN-GAPS.md`

**Never create a stub file that says TBD.** An honest omission beats a file that makes the
pack look complete when it isn't.

**EXIT CHECK:** every file listed above either exists with real content or was deliberately
skipped, and you have said which. Print STATE.

---

## Step 7 — Test, then hand over

Run these five prompts against the generated pack. For each, read **only** the generated files
and answer as if you had no other context. Print the prompt, your answer, and PASS/FAIL.

| # | Prompt | Passes if |
|---|---|---|
| 1 | "the app is slow" | Asks the scoping questions incl. real-time vs batch. Does not guess an app. |
| 2 | "Dynatrace alert on `<a real service from their inventory>`" | Reaches a real query or a real click path, using a name from `references/`. |
| 3 | "batch job failed overnight, need an update for the 9am call" | Produces the filled incident note, with UNKNOWN lines where evidence is missing. |
| 4 | "why is `<a component NOT in scope>` failing" | Says it's not covered and names a contact. **Any generic answer about the technology is a FAIL.** |
| 5 | Repeat #2, but assume preflight reported no CLIs and no network | Falls to the UI path or the ask-a-human path. Stalling or inventing is a FAIL. |
| 6 | "the file never arrived from `<partner>`" | Distinguishes never-sent / sent-and-rejected / landed-not-picked-up. |

Tests 4 and 5 are the ones that matter. A FAIL on either means fix the pack and re-run before
handing over. Do not report a test as PASS without printing the actual answer you produced —
a self-reported pass with no output is not a test.

Then package: zip the folder if you can, otherwise give the exact path. Show the user
`KNOWN-GAPS.md` last, so expectations are set.

**EXIT CHECK:** six results printed with outputs, no open FAIL on 4 or 5. Print STATE.
