#!/bin/sh
# preflight.sh - environment probe. POSIX sh only. No python, no jq, no bashisms.
# Purpose: find out what this machine can actually do before any workflow assumes it.
# Safe to run anywhere: read-only, no network writes, no credential values printed.

echo "=== PREFLIGHT $(date 2>/dev/null || echo 'date-unavailable') ==="
echo

# --- platform ---
echo "[platform]"
echo "  os      : $(uname -s 2>/dev/null || echo unknown)"
echo "  arch    : $(uname -m 2>/dev/null || echo unknown)"
echo "  shell   : ${SHELL:-unknown}"
echo "  user    : $(id -un 2>/dev/null || whoami 2>/dev/null || echo unknown)"
echo "  cwd     : $(pwd 2>/dev/null || echo unknown)"
echo

# --- tool presence ---
# Prints AVAILABLE/MISSING plus version when cheap to get. Never fails the script.
have() {
  if command -v "$1" >/dev/null 2>&1; then
    v=$(eval "$2" 2>/dev/null | head -n 1)
    printf '  %-12s AVAILABLE  %s\n' "$1" "$v"
  else
    printf '  %-12s MISSING\n' "$1"
  fi
}

echo "[interpreters]"
have python3 "python3 --version"
have python  "python --version"
have node    "node --version"
have perl    "perl -v | sed -n 2p"
echo

echo "[text tools]"
have jq      "jq --version"
have awk     "awk --version"
have sed     "sed --version | head -n1"
have grep    "grep --version | head -n1"
echo

echo "[network tools]"
have curl    "curl --version | head -n1"
have wget    "wget --version | head -n1"
have nc      "echo present"
have dig     "echo present"
echo

echo "[cloud clis]"
have oc         "oc version --client 2>/dev/null | head -n1"
have kubectl    "kubectl version --client 2>/dev/null | head -n1"
have aws        "aws --version"
have ansible    "ansible --version | head -n1"
have git        "git --version"
echo

echo "[on-prem clis]"
have sqlplus    "echo present"
have tnsping    "echo present"
have psql       "psql --version"
have runmqsc    "echo present"
have dspmq      "echo present"
have dsjob      "echo present"
have sftp       "echo present"
have ssh        "echo present"
have java       "java -version 2>&1 | head -n1"
have jcmd       "echo present"
have openssl    "openssl version"
have kafka-topics.sh "echo present"
echo
echo "  Note: Control-M, DataStage, MFT, Apigee and the OpenShift COTS product are usually"
echo "  reached through their own consoles rather than a CLI. Absence here is expected and"
echo "  is not a blocker - see references/observability.md for the real source of truth."
echo

# --- connectivity ---
# Edit ENDPOINTS for your environment. Keep it to hostnames you are allowed to probe.
# Format: label|host|port
ENDPOINTS="
dynatrace|CHANGE_ME.live.dynatrace.com|443
openshift-api|CHANGE_ME|6443
apigee|CHANGE_ME|443
controlm-em|CHANGE_ME|443
mft-console|CHANGE_ME|443
aws-api|CHANGE_ME|443
internet|github.com|443
"

echo "[connectivity]"
if command -v curl >/dev/null 2>&1; then
  echo "$ENDPOINTS" | while IFS='|' read -r label host port; do
    [ -z "$label" ] && continue
    case "$host" in CHANGE_ME*) printf '  %-14s SKIPPED (not configured)\n' "$label"; continue;; esac
    if curl -s -o /dev/null -m 5 --connect-timeout 5 "https://$host:$port" 2>/dev/null; then
      printf '  %-14s REACHABLE\n' "$label"
    else
      printf '  %-14s UNREACHABLE (blocked, proxy, or wrong host)\n' "$label"
    fi
  done
else
  echo "  curl missing - cannot test connectivity. Ask the user directly."
fi
echo

# --- credentials present, values never printed ---
echo "[credentials] (presence only, values not shown)"
for v in DT_API_TOKEN DYNATRACE_TOKEN AWS_PROFILE AWS_ACCESS_KEY_ID KUBECONFIG HTTPS_PROXY HTTP_PROXY; do
  eval "val=\${$v:-}"
  if [ -n "$val" ]; then
    printf '  %-20s SET\n' "$v"
  else
    printf '  %-20s not set\n' "$v"
  fi
done
echo

# --- writable scratch ---
echo "[filesystem]"
if touch ./.preflight_write_test 2>/dev/null; then
  echo "  cwd writable   : yes"
  rm -f ./.preflight_write_test 2>/dev/null
else
  echo "  cwd writable   : no"
fi
if touch /tmp/.preflight_write_test 2>/dev/null; then
  echo "  /tmp writable  : yes"
  rm -f /tmp/.preflight_write_test 2>/dev/null
else
  echo "  /tmp writable  : no"
fi
echo

echo "=== END PREFLIGHT ==="
echo
echo "How to read this:"
echo "  Anything MISSING or UNREACHABLE is not a blocker - it means take the"
echo "  UI path or the ask-a-human path instead. Do not assume a tool exists"
echo "  because it usually does."
