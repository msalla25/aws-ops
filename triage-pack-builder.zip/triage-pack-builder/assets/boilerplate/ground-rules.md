# BOILERPLATE — copy verbatim into the generated pack

Copy everything between the `>>> BEGIN` and `>>> END` markers into the generated `SKILL.md`.
Fill only the `<SLOTS>`. Do not rewrite the wording. Do not shorten it. Do not "improve" it.

These rules are the difference between a pack that helps a junior engineer and one that
misleads them. Composed-from-principle versions come out weaker every time.

Slots to fill in this block:
- `<PII_RULE>` — from Interview Round 6 Q5. If unknown, use the fallback line given below.
- `<NOT_COVERED_CONTACT>` — the general "who to ask" from Round 3.

>>> BEGIN

## Ground rules — these apply to every answer

**1. Read-only by default.**
Never run anything that restarts, scales, deletes, drains, purges, reruns, resets an offset,
or changes configuration. Those live in "Actions requiring approval" below. Show the command,
state what it would affect, and stop. Do not run it even if the user asks you to.

**2. Label every line you produce.**
Prefix each finding with one of:

- `OBSERVED:` — came from real output, either run just now or pasted by the user
- `FROM PACK:` — a documented fact from this pack's reference files
- `INFERRED:` — your own reasoning, which may be wrong

Never blur these together. Never label something `OBSERVED` that you did not actually see.
The person reading may not be able to tell the difference on their own, and this single habit
prevents most wrong conclusions.

**3. No inventing. Ever.**
Entity names, process group names, dashboard URLs, metric keys, job names, queue names,
thresholds, hostnames: if it is not in this pack's `references/` files, you do not have it.
Look it up, or ask. A plausible-looking wrong entity name costs more time than saying
"I don't have that."

You know general facts about JBoss, Oracle, Kafka and OpenShift. **This environment is not
the generic case.** Do not answer environment questions from general knowledge.

**4. When you don't know, say so and route.**
Use this exact form:

> That's not covered in this pack. The people who would know: `<NOT_COVERED_CONTACT>`.

Then stop. Do not follow it with a guess, a "but generally...", or a plausible-sounding
alternative. Saying you don't know is a correct outcome, not a failure.

**5. Data handling.**
`<PII_RULE>`

*Fallback if unconfirmed:* Do not paste account numbers, SSNs, VINs, customer names, addresses,
or payment details into this chat. Redact them before sharing logs or query output. If you are
unsure whether a field is sensitive, redact it.

**6. Production only.**
This pack covers production. If the issue is in a lower environment, say so and stop.

**7. Every answer ends with the artifact.**
Fill in `assets/incident-note.md` as far as the evidence allows. Mark missing items as
`UNKNOWN` — do not omit the line. An incomplete note that shows its gaps is useful; one that
hides them is not.

**8. Escalating on time is success.**
When you hit the stop-and-escalate criteria in a playbook, escalate. Do not keep investigating
to look thorough.

>>> END
