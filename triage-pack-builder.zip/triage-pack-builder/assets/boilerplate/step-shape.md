# BOILERPLATE — the three-route step shape

Every operational step in every playbook uses this exact shape. Copy the structure, fill the
slots from interview material. Do not write a step that has only one route.

Slots per step:
- `<CHECK_NAME>` — what this step establishes, in plain words
- `<COMMAND_OR_QUERY>` — exact, copy-paste ready, placeholders in `<ANGLE_BRACKETS>`
- `<UI_PATH>` — literal click path, e.g. "Dynatrace → Services → filter MZ `<MZ>` → Response time"
- `<OWNER>` and `<CHANNEL>` — who to ask, and where
- `<ASK_TEXT>` — the exact sentence to send them
- `<NORMAL>` / `<PROBLEM>` — real values where known, `UNKNOWN` where not
- `<WHY>` — one line on what this rules in or out

>>> BEGIN STEP SHAPE

**Step N: `<CHECK_NAME>`**

- *If the CLI is available (preflight said so):*
  ```
  <COMMAND_OR_QUERY>
  ```
- *If UI access only:* `<UI_PATH>`. Ask the user to paste what they see.
- *If neither:* ask `<OWNER>` in `<CHANNEL>`:
  > `<ASK_TEXT>`

**Normal:** `<NORMAL>` — **Problem:** `<PROBLEM>`
**Why this matters:** `<WHY>`

**Stop and escalate if:** `<CRITERIA>`

>>> END STEP SHAPE

---

## Rules for filling the step shape

**The third route is not a failure mode.** For an offshore engineer on a restricted VDI it may
be the normal path. A pack that only works when tooling is installed gets abandoned in week one.
Never leave the third route blank — if you don't know who to ask, that is a `KNOWN-GAPS` entry,
not an empty line.

**If a component is dark to Dynatrace, the first route is not a Dynatrace query.** Check
`references/observability.md` before writing any step. Writing a Dynatrace path for Control-M,
DataStage, MFT or the Inspire/GMC component will send someone looking at a screen that shows
nothing.

**`<NORMAL>` and `<PROBLEM>` must come from the user, not from you.** If the interview didn't
produce a number, write `UNKNOWN — ask <OWNER>`. An invented threshold in a shared pack
propagates to every engineer who installs it.

**Commands are copy-paste ready.** No pseudo-code, no "adjust as needed", no "something like".
Every placeholder gets a one-line note on where to get its value.

---

## Boilerplate — the triage loop

Copy verbatim into the generated SKILL.md.

>>> BEGIN

## The triage loop

Every playbook follows these five steps. Tell the user which step you are on.

1. **Scope** — what is broken, since when, how wide, real-time or batch
2. **Evidence** — gather using the routes above; if there was a change window, check it first
3. **Hypothesis** — state it as a hypothesis and label it `INFERRED`
4. **Check or escalate** — one read-only check that would *disprove* the hypothesis, or escalate
5. **Hand off** — fill the incident note

Step 4 is deliberately worded as disproving. Looking for confirmation of a first guess is the
most common way triage goes wrong.

>>> END
