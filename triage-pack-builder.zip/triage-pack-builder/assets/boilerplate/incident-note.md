INCIDENT NOTE — <APP OR JOB> — <TIMESTAMP + TIMEZONE>

SUMMARY (one line, what a manager needs to hear)


IMPACT
  Who is affected     :
  What they cannot do :
  Started at          :
  Still ongoing       : yes / no
  Environment         : PRODUCTION
  Real-time or batch  :

EVIDENCE  (label every line OBSERVED / FROM PACK / INFERRED)
  -
  -

CHECKED AND RULED OUT
  -

CURRENT HYPOTHESIS  (mark INFERRED)


NEXT ACTION
  What          :
  Owner         :
  Needs change approval : yes / no

WHAT WE STILL DON'T KNOW
  -
  -

ASKED FOR, NOT YET RECEIVED
  Who / what    :
