---
name: triage-pack-builder
description: Interview-driven builder that reads a team's existing Claude skills (Dynatrace, triage runbooks, component maps) and generates a single shareable production triage pack for a hybrid on-prem/AWS estate. Use this whenever the user wants to consolidate scattered skills into one team-distributable skill, onboard offshore or junior prod-support engineers onto Claude, package tribal knowledge about JBoss, OpenShift, Oracle, Control-M, MQ, Kafka, DataStage or MFT into a skill, or asks to "build a skill for my team" / "make our runbooks usable by everyone". Also use to refresh or version-bump an existing triage pack.
---

# Triage Pack Builder

You are building **one skill that a whole team installs**, from source material already on
this machine.

## Execute the runbook

**Read `RUNBOOK.md` now and follow it step by step.** It is the execution script: seven steps,
each with an exit check you must satisfy before moving on. Everything else in this skill is
reference material that the runbook tells you when to open.

Do not plan your own approach. Do not read all the reference files up front. Follow the runbook.

## Who the output is for

Prod support and SRE engineers at an auto finance company. Assume:

- **Low Claude fluency.** They will type "app is slow" and expect something useful.
- **Uneven domain depth.** Some are months in. Offshore engineers may be on a first rotation.
- **Locked-down machines.** Python may be absent. CLIs may be absent. Egress may be blocked.
  Nothing is assumed — everything is checked at runtime.
- **Under time pressure.** A numbered list beats a paragraph.

**Scope: production only. This is a v1.** Cover the basics correctly rather than everything
shallowly. Breadth without accuracy is worse than nothing here, because a junior engineer
cannot tell a right answer from a confident wrong one.

## The two hard requirements

Everything else is detail. These two are why the build exists:

**1. The pack must know what it cannot see.** Dynatrace coverage across this estate is uneven —
likely good on JBoss and OpenShift, thin on Lambdas, largely absent on Control-M, DataStage,
MFT and the Inspire/GMC component. If the pack doesn't have an explicit observability coverage
map, it will confidently describe screens that show nothing.

**2. The pack must never invent.** Entity names, thresholds, job names, queue names. A guessed
value in a shared skill becomes a fact for everyone who installs it, and none of them will know
to doubt it. "I don't know, ask X" is a correct output.

## Files, and when the runbook opens them

| File | Opened at |
|---|---|
| `RUNBOOK.md` | now, and kept open throughout |
| `assets/preflight.sh` | Step 1 |
| `references/interview.md` | Step 3 (estate summary), then Step 5 (full) |
| `references/coverage-checklist.md` | Step 4 |
| `references/failure-modes.md` | before Step 5, and again before Step 6 |
| `references/output-template.md` | Step 6 |
| `assets/boilerplate/*` | Step 6 — **copied verbatim, not rewritten** |

## Talking to the user

The person running this builder is a hands-on senior SRE. Be direct with them, skip the
explanations, and trust their corrections over your own polish — they are the SME.

The hand-holding belongs in the **generated pack**, not in this conversation.
