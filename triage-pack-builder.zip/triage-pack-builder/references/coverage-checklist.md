# v1 coverage checklist — hybrid estate, production only

Score every item **covered** (name the source skill), **partial**, or **missing**. Show this
to the user before the interview — seeing gaps is faster than being asked about them.

Shippable when every `[must]` is covered and no `[must]` contains an invented value.

Expect the existing skills to score well on AWS and Dynatrace and poorly on the on-prem
batch/file/data layer. That asymmetry is the point of the build.

## Orientation
- [must] In-scope flows named, and an explicit out-of-scope list (incl. non-prod)
- [must] Plain-language symptom -> flow routing table
- [must] Glossary: "WS", the COTS product name, Control-M job naming, internal acronyms
- [nice] One-paragraph estate overview for new joiners

## Environment awareness
- [must] Preflight runs before any operational answer
- [must] Degradation ladder per check: CLI -> UI click path -> ask-a-human, with named owner
- [must] Explicit note that on-prem access differs from AWS access, and offshore may have neither
- [nice] VDI/proxy quirks specific to this org

## Flow maps
- [must] End-to-end hop sequence for at least 2 in-scope flows
- [must] On-prem <-> AWS boundary marked, with how traffic crosses
- [must] Timeout chain for the real-time path (where the first timeout fires, at what value)
- [nice] Remaining flows mapped

## Observability coverage map  <- the accuracy backbone
- [must] Per component: instrumented in DT yes/no, and if no, the actual source of truth
- [must] Named owner + channel for every component support cannot see directly
- [must] Explicit statement of what is dark (likely Control-M, DataStage, MFT, Inspire/GMC)
- [nice] Baseline normal ranges per key metric

## Component knowledge
- [must] Component -> process group / entity name, for the DT-visible ones
- [must] Owner and contact channel per component
- [nice] Dependency direction
- [nice] Commonly-misblamed components

## Handoff points
- [must] Apigee vs backend: how to tell which side failed
- [must] COTS/OCP -> Oracle: pool exhaustion vs slow query vs lock
- [must] MFT three-way: never sent / sent-and-rejected / landed-not-picked-up
- [nice] MQ depth and Kafka lag thresholds
- [nice] Control-M "ran but did nothing" detection

## Triage paths
- [must] At least 2 fully documented flows, end to end
- [must] Stop-and-escalate criteria in each
- [must] Batch restart safety: which jobs are safe to rerun, which risk double-posting
- [nice] Additional flows
- [nice] "Nothing matches" fallback

## Safety
- [must] Read-only default, stated explicitly
- [must] Change-approval list, split on-prem vs AWS
- [must] PII rule for auto finance — what must never be pasted into chat
- [must] No-fabrication rule + OBSERVED / FROM PACK / INFERRED labelling
- [must] Anything support has access to do but should not do
- [nice] Blast radius per risky action

## Output
- [must] Incident note / handoff template
- [must] Escalation matrix with severity definitions and time thresholds
- [must] Batch SLA cutoff times, if a batch flow is in scope
- [nice] Example filled-in note from a real past incident

## Distribution
- [must] INSTALL.md for a non-technical reader
- [must] KNOWN-GAPS.md
- [nice] Named owner and feedback route
- [nice] Version stamp
