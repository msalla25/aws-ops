# Failure modes — read before Step 5 and before Step 6

These are the ways this build goes wrong. Each is stated as a prohibition because prohibitions
survive a long session better than principles do.

## During the interview

**Do not ask a question you could have pre-filled.** If `build-notes.md` contains anything
relevant, lead with it: *"From your triage skill I have X. Still correct?"* The user already
wrote this down once.

**Do not send more than 7 questions in one message.** Count them. A wall of questions gets a
partial answer, and partial answers become invented gaps.

**Do not accept silence as agreement.** If the user answers 4 of 6, ask the other 2 once more,
then mark them as gaps and move on. Do not assume the unanswered ones were fine.

**Do not fill an "I don't know" with a reasonable value.** This is the single most damaging
thing you can do in this build. A guessed threshold in a shared pack becomes a fact for every
engineer who installs it, and none of them will know to doubt it. Write it to `KNOWN-GAPS.md`.

**Do not silently resolve a contradiction between two existing skills.** Surface both versions
and ask which is current.

## During assembly

**Do not compose your own version of the safety sections.** Copy from `assets/boilerplate/`
and fill slots. If you find yourself writing guardrail prose, you have gone off-script.

**Do not write a step with only one route.** Every operational step gets CLI / UI / ask-a-human.

**Do not write a Dynatrace path for a component that is dark to Dynatrace.** Check
`references/observability.md` first. This is the most likely concrete error in the whole build.

**Do not create stub files.** A `references/aws.md` containing "TBD" is worse than no file —
it makes the pack look complete. Skip it and log it in `KNOWN-GAPS.md`.

**Do not exceed ~350 lines in the generated SKILL.md.** Push detail into `references/`.
Long skills degrade instruction-following, and nobody reads 900 lines during an incident.

**Do not paraphrase a query, threshold, entity name, or job name from the source skills.**
Copy it exactly. Paraphrasing correct material is a way to introduce errors into it.

## During testing

**Do not report PASS without printing the actual answer.** A self-reported pass with no output
is not a test.

**Do not soften test 4.** If the generated pack answers an out-of-scope question with general
technology knowledge instead of "not covered", that is a FAIL, even if the general answer was
accurate. The whole point is that the team cannot tell the difference.

**Do not skip test 5.** The no-tooling path is the one offshore engineers will hit most.

## Throughout

**Do not skip a phase because you have enough context.** The exit checks exist because a build
that feels on track and one that is on track look identical from the inside.

**Do not proceed past a failed exit check.** Stay in the step.

**Do not lose the STATE block.** If the session gets long and you are unsure where you are,
re-derive STATE from what you can verify in the transcript and print it. Guessing a later step
than you can prove is how phases get silently skipped.

**Do not expand scope.** If the user starts discussing automation, remediation, or capacity
work, note it as v2 and steer back. A shipped v1 that gets used beats a v2 that never lands.
