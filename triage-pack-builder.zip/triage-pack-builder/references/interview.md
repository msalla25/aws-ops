# Interview question bank — hybrid estate, production only

Tuned for this environment. Read this before Round 1 and correct anything wrong — the estate
summary below was captured from conversation and some terms were transcribed phonetically.

## Estate summary (confirm with the user first)

**Scope: production only.** Non-prod is out of scope for v1, including "it works in UAT"
comparisons unless the user says otherwise.

| Layer | What's there | Where |
|---|---|---|
| Entry point (real-time) | Apigee | — |
| Main workload | COTS product — the "WS" | OpenShift, on-prem |
| API microservices, Spring Batch, event engine | JBoss/WildFly | On-prem, DFW |
| Cloud microservices + Lambdas + small DBs | AWS | Legacy footprint |
| Heavy data | Oracle (Exadata?) | On-prem |
| Content / document services | Inspire / GMC component | — |
| ETL batch | DataStage | — |
| Messaging (on-prem) | MQ | — |
| Messaging (cloud) | Kafka → AWS microservices and Lambdas | — |
| Scheduling | Control-M | — |
| File transfer | MFT | — |

**Confirm these four before proceeding — I inferred them:**
1. "WS" — what does this stand for, and what's the product's real name? It's the main workload,
   so it needs a name the team recognises.
2. Oracle — Exadata specifically, or standard RAC/single instance?
3. Content services — Quadient Inspire / GMC Inspire (document composition)? What does it
   produce — statements, letters, payoff quotes?
4. MQ — IBM MQ, or ActiveMQ/AMQ? These have completely different diagnostics.

## Why this bank is structured around flows, not components

A component list produces a pack that can answer "is JBoss up." Real incidents here cross
boundaries: Apigee → OpenShift COTS → Oracle, or Control-M → DataStage → MFT → downstream.
The engineer's actual problem is *which hop broke*, and the hops are where evidence is
thinnest. So Rounds 2–4 build flow maps and handoff points before touching any single tool.

Ask in rounds of 5–7. Pre-fill everything you can from the existing skills. Mark `[blocking]`
vs `[nice-to-have]`. After every round the pack should be *narrower but still correct* if
the user stops.

---

## Round 1 — Scope and pain `[all blocking]`

1. Of the flows below, which 2–3 generate the most production incidents?
   - Real-time customer/dealer traffic (Apigee → COTS/APIs → Oracle)
   - Overnight batch (Control-M → Spring Batch / DataStage → Oracle)
   - File in/out (MFT → downstream)
   - Document/statement generation (Inspire/GMC)
   - Event-driven (MQ or Kafka → consumers → Lambdas)
2. What are the 5 things this team actually gets paged for, in the words the page uses?
3. Does the team resolve, or triage-and-hand-off? Different for on-prem vs AWS?
4. What's the one mistake juniors make most often that this pack should prevent?
5. Which component gets blamed first and is usually innocent?

Q4 and Q5 are the two highest-yield questions in this bank. Ask them properly and wait.

---

## Round 2 — Flow maps `[blocking]`

For each in-scope flow from Round 1, get the hop sequence end to end. Draw it back to the
user as a chain and have them correct it. Example shape:

`Apigee → <COTS on OCP> → <JBoss API MS> → Oracle → response`

Per flow, ask:

1. The hop sequence, named the way the team names them.
2. Where does it cross the on-prem/AWS boundary, if at all? How does traffic get across —
   Direct Connect, VPN, gateway?
3. Which hop fails most often?
4. Which hop is hardest to see into? (Feeds Round 3.)
5. Is there a synchronous timeout chain? Where does the first timeout fire, and at what value?

Q5 matters a lot for the Apigee path — a junior will chase the slow backend when the real
symptom is a gateway timeout firing before the backend finishes.

---

## Round 3 — Observability coverage map `[blocking — this is the accuracy backbone]`

Dynatrace coverage will not be uniform across this estate. Assume it's good on JBoss and
OpenShift, thinner on Lambdas, and largely absent on Control-M, DataStage, MFT, and the
Inspire/GMC component. The pack must know where it can and cannot see, or it will invent.

For **each component**, get:

| Component | Instrumented in DT? | If not, what IS the source of truth? | Who has access? |
|---|---|---|---|

Specifically:

1. Which components have the OneAgent, and which are dark?
2. For the COTS product on OpenShift — is it instrumented, or is it a black box? What does
   the team actually look at for it?
3. Control-M — how does support see job status? Console, EM, a report?
4. DataStage — where do job logs live and who can read them?
5. MFT — how does anyone confirm a file actually landed?
6. Apigee — analytics UI, or does DT trace through it?
7. Lambdas — CloudWatch only, or DT serverless too?
8. Oracle — does support have read access, an AWR/dashboard, or must they ask the DBA?

For every "must ask the DBA / must ask the scheduling team" answer, capture **who** and
**which channel**. That answer becomes a route in the pack, not a dead end.

---

## Round 4 — Handoff points `[blocking]`

The seams. Per boundary that appears in the Round 2 flows:

1. **Apigee → backend** — how do you tell a gateway problem from a backend problem?
   What does Apigee return in each case?
2. **COTS on OCP → Oracle** — connection pool location, and how do you see it? Pool
   exhaustion vs slow query vs lock — how does the team tell these apart?
3. **On-prem → AWS** — what carries the traffic, and how do you check it's healthy?
4. **MQ → consumer** — where does depth get read, and what depth is abnormal?
5. **Kafka → Lambda** — lag visibility, DLQ location, and what happens to a poison message?
6. **Control-M → Spring Batch / DataStage** — what does Control-M show when the job
   technically ran but did nothing useful?
7. **MFT → downstream** — how do you distinguish "file never sent", "file sent but rejected",
   and "file landed but wasn't picked up"?

Q7 is worth extra time. That three-way distinction is a classic time sink for new engineers,
and it's cheap to document once.

---

## Round 5 — Per-domain first checks `[blocking for the flows chosen in Round 1]`

Only for the in-scope flows. For each, get first check / normal vs abnormal / second check /
stop-and-escalate criteria.

**Real-time (Apigee → COTS → JBoss → Oracle)**
- Where do you look first to split gateway vs app vs DB?
- Normal response time and error rate for the main entry point?
- COTS-specific: is there a vendor-supplied health page or admin console?

**JBoss / WildFly**
- Thread pool, connection pool, heap — which one first, and where is it read?
- Known thresholds? Any recurring pattern the team already recognises?

**Batch (Control-M → Spring Batch / DataStage)**
- SLA cutoff times — what's the "we must escalate by" clock?
- Restart safety: which jobs are safe to rerun, which are absolutely not (double-posting
  risk is real in auto finance — get this explicit)?
- How do you tell "still running" from "hung"?

**Oracle**
- What can support check read-only without a DBA?
- Common patterns — locks, tablespace, long-running query, stats?

**Messaging (MQ / Kafka)**
- Normal vs alarming depth/lag per queue or topic that matters?
- Who owns the consumer side?

**AWS (microservices / Lambdas / small DBs)**
- Since these are legacy: is anyone actively maintaining them? Who?
- Lambda failure — where does the error surface, and is there a DLQ?

**Document / content (Inspire / GMC)**
- What's the symptom when this breaks — is it customer-visible immediately or discovered later?
- Any regulatory clock on statement or letter generation?

---

## Round 6 — Guardrails and escalation `[blocking]`

Likely different between on-prem and AWS. Ask separately where they differ.

1. Severity definitions in this org — what makes a Sev1?
2. Escalation path and time thresholds, per flow if they differ.
3. **Never without change approval** — be specific: JBoss restarts, OCP pod deletes,
   Control-M job forces/reruns, MQ queue purges, Kafka offset resets, Lambda config changes,
   any Oracle write. Which of these does support have the *access* to do but shouldn't?
4. What IS safe read-only at 3am without waking anyone?
5. Data handling — auto finance PII. What must never be pasted into a chat window? Account
   numbers, VINs, SSNs, names, payment details? State it plainly.
6. Where do incident notes go, and what format does the bridge call expect?

Q3 and Q5 both go near the top of the generated pack, not buried in a reference file.

---

## Round 7 — Language and onboarding `[nice-to-have but high value here]`

Offshore engineers plus a COTS product plus internal nicknames is a rough combination.

1. Internal acronyms and system nicknames — "WS", the COTS product's internal name, any
   flow or job naming conventions.
2. Control-M job naming convention — can you tell what a job does from its name?
3. Any term whose internal meaning differs from the industry-standard meaning?
4. Should the pack include a one-line "why this check matters" per step? For a team building
   domain depth, usually worth the tokens.

---

## Round 8 — Maintenance `[nice-to-have]`

1. Owner, and who reviews corrections?
2. How do people report a wrong step?
3. What triggers v2 — the "more details that can be added later," or accumulated gaps?

---

## Handling non-answers

- "I don't know" → `KNOWN-GAPS.md`, with who could answer. Never fill with a plausible value.
- "It depends" → get the two most common cases, document both branches.
- "All the flows" → push back once, concretely: five shallow flows will be abandoned; two
  solid ones get used. Then accept their call.
- Contradiction with an existing skill → surface both, ask which is current, note the loser
  so the stale skill can be cleaned up.
- **Anything AWS-shaped that the existing skills already cover well** → reuse verbatim, don't
  re-interview. The gap is on-prem, not cloud.
