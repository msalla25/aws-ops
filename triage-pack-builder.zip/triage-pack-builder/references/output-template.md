# Output template

The skeleton for the generated pack. Fill from inventory + interview. Delete any section you
have no real content for — an empty stub is worse than an honest omission.

Write for a reader who is competent but new: to the tooling, sometimes to the domain,
sometimes to Claude itself.

---

```markdown
---
name: <team>-triage-pack
description: Production triage guide for <team> covering <app1>, <app2>, <app3>. Use this
  whenever someone reports a production issue, receives a Dynatrace alert, is asked for a
  status update on an incident, needs to check the health of one of these applications, or
  asks how to investigate slowness, errors, failed batches, or queue backlogs. Also use for
  handing an incident to an application team or preparing an update for a bridge call.
version: 1.0
owner: <name / channel>
---

# <Team> Production Triage Pack

**What this covers:** <apps>. **What it does not cover:** <explicit out-of-scope list>.

If you're asked about something outside that list, say so instead of guessing.

## Step 0 — Check the environment first

Before answering anything operational, run:

    sh assets/preflight.sh

Read the result. It tells you which paths below are available on this machine. If the script
won't run, ask the user which of these they have: Dynatrace UI, `oc` CLI, AWS console,
database read access. Assume nothing.

## Ground rules (apply to every answer)

**COPY VERBATIM from `assets/boilerplate/ground-rules.md`.** Fill only `<PII_RULE>` and
`<NOT_COVERED_CONTACT>`. Do not write your own version of this section — a composed version
comes out weaker every time, and this is the section that keeps a junior engineer safe.

## Where to start — symptom routing

| They said something like | Go to |
|---|---|
| "app is slow", "timeouts", "screens hanging" | Playbook A — Real-time path (Apigee → COTS → APIs → Oracle) |
| "getting errors", "5xx", "users can't submit" | Playbook B — Real-time errors |
| "job failed", "batch didn't finish", "still running" | Playbook C — Batch (Control-M → Spring Batch / DataStage) |
| "file didn't arrive", "we never got the file" | Playbook D — MFT / file transfer |
| "queue backed up", "messages stuck", "lag" | Playbook E — MQ / Kafka |
| "statements didn't generate", "letters missing" | Playbook F — Content / Inspire-GMC |
| "lambda failing", "the AWS service is erroring" | Playbook G — AWS microservices / Lambda |
| "Dynatrace alert on <X>" | Playbook H — Alert triage, then route to A–G |
| "need an update for the call" | Skip to the incident note; gather what exists |
| Nothing matches | Ask the scoping questions below, then say if it's out of scope |

**This is production only.** If the issue is in a non-prod environment, say so and stop.

**Scoping questions** when the report is vague — ask all at once, don't interrogate:
1. Which application or job, and is this production?
2. When did it start, and is it happening now?
3. Everyone affected, or specific users / dealers / regions?
4. Real-time (someone waiting on a screen) or batch/file (discovered after the fact)?

Question 4 decides on-prem vs AWS, sync vs async, and which half of this pack applies. Ask it
early — it saves more time than any other single question.

**Before answering, check the observability coverage map** in `references/observability.md`.
Several components here are not instrumented in Dynatrace. If the component in question is
dark, do not describe what Dynatrace would show — go straight to the documented source of
truth or the named owner.

## The triage loop

Every playbook follows the same five steps. Say which step you're on.

1. **Scope** — what is broken, since when, how wide
2. **Evidence** — gather from the paths below, oldest-first if there's a change window
3. **Hypothesis** — state it as a hypothesis, marked `INFERRED`
4. **Check or escalate** — one read-only check that would disprove it, or escalate
5. **Hand off** — fill the incident note

## Playbooks

**Every step uses the shape in `assets/boilerplate/step-shape.md`.** Copy that structure and
fill the slots. Never write a step with only one route. Before writing any step, check
`references/observability.md` — if the component is dark to Dynatrace, the first route is not
a Dynatrace query.

The triage-loop section is also copied verbatim from `step-shape.md`.

### Playbook A — Latency

**Step 1: Confirm it's real and scope it.**

- *If CLI + token available:*
  ```
  <exact command or DQL>
  ```
- *If UI only:* Dynatrace → <exact click path> → filter to management zone `<MZ>` → read <metric>.
  Paste what you see.
- *If neither:* ask <role/channel> for: "current response time for `<service>` over the last
  2 hours vs the same window yesterday."

**Normal looks like:** <value>. **Problem looks like:** <value>.
**Why this matters:** <one line — keeps the reader learning>.

**Step 2: ...**

**Stop and escalate if:** <criteria>.

## Actions requiring change approval

| Action | Blast radius | Who approves |
|---|---|---|

Never run these from this skill. Show the command, state the risk, point at the process.

## Reference files

- `references/flows.md` — end-to-end hop maps, on-prem/AWS boundary, timeout chains
- `references/observability.md` — **read this first**: per component, what's instrumented,
  what's dark, and the real source of truth for each
- `references/components.md` — component → process group / entity name → owner → channel
- `references/dynatrace.md` — tenant, management zones, queries, entity naming
- `references/onprem.md` — JBoss, OpenShift COTS, Oracle, MQ, Control-M, DataStage, MFT
- `references/aws.md` — microservices, Lambdas, Kafka consumers, small DBs (legacy)
- `references/escalation.md` — severity definitions, contacts, batch SLA cutoffs
- `references/glossary.md` — acronyms, "WS", COTS product name, Control-M job naming

## When you don't know

Say: "That's not covered in this pack — here's who would know: <contact>."
Then log it so it can go into v2. Do not fill the gap with general knowledge about the
technology; the environment here is not the generic case.
```

---

## Companion files

### `assets/incident-note.md`

**COPY VERBATIM from `assets/boilerplate/incident-note.md`.** No edits.

The "WHAT WE STILL DON'T KNOW" and "ASKED FOR, NOT YET RECEIVED" fields are deliberate. Juniors
tend to present partial findings as complete; a required field for unknowns fixes that habit
faster than any instruction.

### `INSTALL.md`

Written for someone who has never installed a skill. Cover:
1. Where the folder goes, exact path, per OS
2. How to confirm Claude picked it up
3. Three example first prompts to try
4. What to do when it says it doesn't know — that's correct behaviour, not a bug
5. Who to tell when a step is wrong

### `KNOWN-GAPS.md`

Every `TODO(v2)` and every "I don't know" from the interview, with who could answer it.
Doubles as the v2 backlog.
