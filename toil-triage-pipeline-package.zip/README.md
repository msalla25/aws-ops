# Toil triage pipeline — full package

Two folders:

- **`toil-triage-pipeline/`** — the skill itself. This is the only part that gets
  installed. Unzip it into `~/.claude/skills/` (personal) or your repo's
  `.claude/skills/` (shared with a team). Needs Node 16+ and nothing else: no npm
  install, no network access, no package.json.

- **`samples/`** — output from a real run against the synthetic data included in the
  skill. Nothing here is needed to run anything; it's there so you can see what the
  pipeline produces before running it, and so reviewers and other teams can judge the
  output without installing anything.

## Quick start

```
cd toil-triage-pipeline
node scripts/preflight.mjs        # <1s; also finds Dynatrace/Jira/Confluence MCPs and CLIs
node scripts/prep-incidents.mjs --csv assets/sample_incidents_synthetic.csv
```

That writes a `toil-run-<timestamp>/` folder. Then open `SKILL.md` — it's the full
workflow Claude follows, and it reads fine as a human runbook too.

## What's in samples/

| File | What it shows |
|---|---|
| `prep_report.md` | What step 1 prints: categories, hours per month, top candidates |
| `clusters.csv` | The offenders, one row each — the pipeline's source of truth |
| `picker-preview.html` | The local page teams see, on a laptop with Dynatrace MCP + dtctl + Jira detected. Inert |
| `picker-preview-bare-laptop.html` | Same page when preflight finds nothing — Dynatrace and publish options greyed |
| `capabilities.json` | What preflight writes: which MCPs and CLIs it found, and where |
| `evidence_plan.json` | The bounded query plan, including the exact DQL per offender |
| `jira/` | One draft per offender, in Markdown and Jira wiki markup |
| `confluence/` | Per category: Markdown, plain HTML to copy-paste, storage format |
| `index.md` | The review list Claude shows before anything is created |
| `dashboard_summary.json` | What the toil metrics dashboard consumes |

The samples cover two toil items in one run (Control-M and MFT), which is why there
are two Confluence pages.

## Before sharing with other teams

Three things to set, all documented in `references/rollout.md`:

1. Brand tokens at the top of `assets/picker.template.html`, so the picker matches ToilLens.
2. Your Jira project key and toil label convention.
3. A pass over `references/rules.json` — categories, offender patterns, metric keys and
   the three DQL templates. Verify each template once in your tenant; field names differ
   by extension.

Incident data never leaves the laptop. The picker binds to 127.0.0.1 only and exits
after one click.
