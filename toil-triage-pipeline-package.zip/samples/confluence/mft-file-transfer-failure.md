> Generated 2026-09-10 from `sample_incidents_synthetic.csv` (60 incidents, 2026-07-29 to 2026-08-19). Hours basis: reported. Evidence: dynatrace_mcp.

## MFT / file transfer failure - repeat offenders

**11** incidents across **1** offenders. Technical hours 6.6, business hours 13.2, currently about **27 hours per month**.

| Offender | Incidents | Hrs/month | Common error | Likely cause | Fix path | Jira |
|---|--:|--:|---|---|---|---|
| payments_*.dat | 11 | 27 | `SFTP transfer failed: connection reset by partner` | t | Process or runbook change | draft |

## How this was produced

1. ToilLens filtered the ServiceNow dump and exported this subset.
2. Incidents were grouped into offenders by normalised error signature and reviewed by a person.
3. Error detail was pulled once per offender (dynatrace_mcp, quick depth), not per incident.
4. A person reviewed every finding before any ticket was raised.

*Counts come from the incident dump. Causes are hypotheses from the evidence listed in each Jira, not confirmed root cause.*