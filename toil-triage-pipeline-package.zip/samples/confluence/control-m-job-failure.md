> Generated 2026-09-10 from `sample_incidents_synthetic.csv` (60 incidents, 2026-07-29 to 2026-08-19). Hours basis: reported. Evidence: dynatrace_mcp.

## Control-M job failure - repeat offenders

**22** incidents across **3** offenders. Technical hours 17.6, business hours 8.8, currently about **36.1 hours per month**.

| Offender | Incidents | Hrs/month | Common error | Likely cause | Fix path | Jira |
|---|--:|--:|---|---|---|---|
| CTM_GL_DAILY_LOAD | 8 | 13.1 | `ORA-01555 snapshot too old` | t | Automate via AAP job template | draft |
| CTM_PAY_EXTRACT | 7 | 11.5 | `ORA-01555 snapshot too old` | t | Automate via AAP job template | draft |
| CTM_CARD_SETTLE | 7 | 11.5 | `ORA-01555 snapshot too old` | t | Automate via AAP job template | draft |

## How this was produced

1. ToilLens filtered the ServiceNow dump and exported this subset.
2. Incidents were grouped into offenders by normalised error signature and reviewed by a person.
3. Error detail was pulled once per offender (dynatrace_mcp, quick depth), not per incident.
4. A person reviewed every finding before any ticket was raised.

*Counts come from the incident dump. Causes are hypotheses from the evidence listed in each Jira, not confirmed root cause.*