# Drafts - 2026-09-10 19:48

- Offenders investigated: 4  (33 incidents, ~63.1 hrs/month in scope)
- Jira to create: 4   |   duplicates skipped: 0
- Estimated hours saved per month if all fixed: 0

## Jira drafts (Markdown + wiki markup for each)

- [CREATE] [Control-M job failure] CTM_GL_DAILY_LOAD - 8 incidents, Automate via AAP job template  ->  `drafts/jira/2dfc2115ec-CTM_GL_DAILY_LOAD.md`
- [CREATE] [Control-M job failure] CTM_PAY_EXTRACT - 7 incidents, Automate via AAP job template  ->  `drafts/jira/67a43f837b-CTM_PAY_EXTRACT.md`
- [CREATE] [Control-M job failure] CTM_CARD_SETTLE - 7 incidents, Automate via AAP job template  ->  `drafts/jira/fdbbc79bf0-CTM_CARD_SETTLE.md`
- [CREATE] [MFT / file transfer failure] payments_*.dat - 11 incidents, Process or runbook change  ->  `drafts/jira/0d2e971d55-payments_-.dat.md`

## Confluence drafts (.md / .html preview / .storage.html)

- `toil-run-20260910-1948/drafts/confluence/control-m-job-failure.*`
- `toil-run-20260910-1948/drafts/confluence/mft-file-transfer-failure.*`
