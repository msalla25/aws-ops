# Prep report - 2026-09-10 19:48

- Source: `sample_incidents_synthetic.csv` (60 incidents, utf-8, delimiter ",")
- Detected as: **SUBSET list** - ToilLens columns present: toil_score, technical_hours, business_hours
- Window: 2026-07-29 to 2026-08-19
- Hours basis: **reported**; rates normalised over 22 observed days

## Categories

| Category | Incidents | % | Offenders | Tech hrs | Biz hrs | Hrs/month | Score |
|---|---:|---:|---:|---:|---:|---:|---:|
| Control-M job failure | 22 | 36.7% | 3 | 17.6 | 8.8 | 36 | 23.8 |
| MFT / file transfer failure | 11 | 18.3% | 1 | 6.6 | 13.2 | 27 | 15.8 |
| Certificate expiry / TLS | 5 | 8.3% | 1 | 5 | 2.5 | 10.2 | 7.1 |
| Uncategorized | 6 | 10% | 1 | 9 | 12 | 28.6 | 6.3 |
| Password / service account / access | 7 | 11.7% | 1 | 3.5 | 2.1 | 7.6 | 5 |
| Filesystem / capacity | 9 | 15% | 1 | 3.6 | 0 | 4.9 | 3.4 |

## Top candidates

1. **MFT / file transfer failure** - `payments_*.dat` x11 (2026-08-07 to 2026-08-17), ~27 hrs/month reported, score 19.8 [INC00100023, INC00100025, INC00100027]
2. **Control-M job failure** - `CTM_GL_DAILY_LOAD` x8 (2026-07-29 to 2026-08-19), ~13.1 hrs/month reported, score 10.8 [INC00100001, INC00100004, INC00100007]
3. **Control-M job failure** - `CTM_PAY_EXTRACT` x7 (2026-07-31 to 2026-08-18), ~11.5 hrs/month reported, score 9.5 [INC00100002, INC00100005, INC00100008]
4. **Control-M job failure** - `CTM_CARD_SETTLE` x7 (2026-07-30 to 2026-08-18), ~11.5 hrs/month reported, score 9.5 [INC00100003, INC00100006, INC00100009]
5. **Certificate expiry / TLS** - `api.internal.corp` x5 (2026-08-15 to 2026-08-19), ~10.2 hrs/month reported, score 8.9 [INC00100050, INC00100051, INC00100052]
6. **Uncategorized** - `portal-web` x6 (2026-08-14 to 2026-08-19), ~28.6 hrs/month reported, score 7.9 [INC00100055, INC00100056, INC00100057]
7. **Password / service account / access** - `SVC_BATCH` x7 (2026-08-10 to 2026-08-16), ~7.6 hrs/month reported, score 6.3 [INC00100043, INC00100044, INC00100045]
8. **Filesystem / capacity** - `var/log` x9 (2026-08-11 to 2026-08-19), ~4.9 hrs/month reported, score 4.3 [INC00100034, INC00100037, INC00100040]
