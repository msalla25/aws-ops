# payments_*.dat - 11 incidents

**Suggested summary:** [MFT / file transfer failure] payments_*.dat - 11 incidents, Process or runbook change

**Labels:** toil, toil-analyzer, toil-sig-0d2e971d55, mft_transfer

## What is happening
payments_*.dat generated **11 incidents** between 2026-08-07 to 2026-08-17, handled by MFT-SUPPORT.

Common error signature: `SFTP transfer failed: connection reset by partner`

## Evidence
- **dynatrace_mcp**: 11 matching error lines in window (query: `fetch logs, from:"2026-08-07T00:00:00Z", to:"2026-08-17T23:59:59Z" | filter contains(content, "payments") and (loglevel == "ERROR" or loglevel == "SEVERE" or loglevel == "WARN") | summarize n = count…`)

## Likely cause
t (confidence: **medium**)

## Proposed fix
**Process or runbook change** - x

## Value if fixed
- Incidents removed: ~11 per 30 days
- Hours in scope: technical 6.6, business 13.2 (reported)
- Currently costing about **27 hours per month** (reported)

## Sample incidents
INC00100023, INC00100025, INC00100027, INC00100029, INC00100031

_Generated 2026-09-10 19:48 from sample_incidents_synthetic.csv by the toil triage pipeline. Cluster 0d2e971d55._