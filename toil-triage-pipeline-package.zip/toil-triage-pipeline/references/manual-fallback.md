# Running without Node

Some locked-down laptops have no Node, or a version older than 16. The pipeline still works, just with lower volume and more of the grouping done by reading.

## First, check properly

`node -v` is the only thing that matters. Worth trying before giving up:
- Node bundled with other corporate tooling (VS Code installs, Git for Windows, an Electron app's runtime).
- `where node` on Windows / `which -a node` on macOS and Linux — a second install often exists outside PATH.
- Node 16 through 22 all run these scripts unchanged. Below 16, `??`, optional chaining and top-level await may fail; the fallback below applies.

## Limits of doing it by hand

Do this for up to roughly 500 rows. Past that, ask the person to run the scripts on a machine that has Node, or to export a narrower subset from ToilLens first — hand-grouping thousands of rows produces numbers nobody should put in front of a CIO.

## Substitute steps

**Step 1 (prep).** Read the CSV directly. Identify the columns that correspond to: incident number, short description, description, close notes, assignment group, CI, opened, resolved, and any ToilLens columns (`toil_score`, `technical_hours`, `business_hours`). State the mapping you inferred and ask for confirmation. If ToilLens columns are present, treat it as a pre-filtered subset.

Categorise using the term lists in `rules.json` — read that file and apply the same first-match-wins order, so the categories stay comparable with runs done via the scripts.

**Step 2 (picker).** No local server, and no `--detach`/`wait-selection` loop. Ask the three questions in conversation: what to target, evidence source, what to produce. Alternatively, open `assets/picker.template.html` directly in a browser — it won't have data in it, but it shows the team what the real flow looks like.

**Step 3 (grouping).** There is no `offenders.mjs` table to show, so group by hand: strip numbers, timestamps, hostnames and ticket IDs from each description mentally, then group what's left, splitting by job or component name first. Aim for offenders a support engineer would recognise as "the same thing happening again". Show the groups with counts and sample incident numbers and ask for corrections — this matters more here, because there's no deterministic signature to fall back on.

**Steps 4–5 (evidence and output).** Unchanged in substance. Write `findings.json` by hand in the schema from SKILL.md, then produce the Jira and Confluence content directly, following the layout in `scripts/render-outputs.mjs` (read the `jiraMarkdown`, `jiraWiki` and `confluenceMarkdown` functions). Matching that layout keeps outputs consistent across teams, which is the whole point of having a template.
