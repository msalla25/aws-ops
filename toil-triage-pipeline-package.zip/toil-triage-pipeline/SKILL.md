---
name: toil-triage-pipeline
description: Turn a ServiceNow incident CSV into grouped repeat offenders with error evidence, then into Jira tickets and a Confluence write-up. Use this whenever someone hands over an incident export, an incident dump, a ToilLens subset, a "top toil candidates" file, or asks to analyse repeat incidents, find automation candidates, group incidents by error, work out how many incidents fall in a category, or raise toil tickets from incident data. Works on a full unfiltered dump or an already-filtered subset. Also use it when the person mentions toil analysis, Control-M failure analysis, repeat offenders, or feeding incident numbers into a toil dashboard.
---

# Toil triage pipeline

Takes an incident CSV and walks it to a reviewed backlog: **detect → confirm → group → evidence → document**. Every step that costs money or creates records is gated by a person.

The point is repeatability. The same run produces the same grouping, the numbers in the Jira match the numbers in the Confluence page, and both trace back to named incident numbers. Anyone reading the output should be able to check it.

Runs on **Node 16+ with no npm install** — stdlib only, no network calls, no package.json needed. Every command below works the same in bash, PowerShell and cmd. Run them from the skill directory, or give the full path to the script; the scripts find their own assets either way.

## Before anything else

```bash
node scripts/preflight.mjs
```

Under a second. It reports the Node version, whether the skill files are intact, whether a local port can bind, and — the part that shapes the rest of the run — what tooling exists on this machine: `dtctl`, `jira`/`acli`/`confluence` CLIs on PATH, and any Dynatrace, Jira, Confluence or Atlassian MCP servers in Claude Code's config files. It writes `capabilities.json`, which step 1 carries into the run dir and the picker uses to grey out options that can't work here.

**Reconcile before moving on.** The script reads config; it cannot see the live session. Compare its MCP findings with the tools you can actually call right now:

- It lists an MCP you don't have tools for → not connected. `node scripts/preflight.mjs --set jira_mcp=no`
- You have Dynatrace or Jira tools it didn't find → `--set dynatrace_mcp=yes`
- A CLI is on PATH but the person says it isn't logged in → `--set dynatrace_cli=no`

Then proceed. Getting this right costs one line; getting it wrong means the picker offers Jira creation on a laptop that can't create Jiras, and the person finds out at step 5.

If Node is missing or too old, read `references/manual-fallback.md` and do the same work by reading the CSV directly — smaller volumes only.

Ask for the CSV path if it wasn't given. Never guess at a file. Every script accepts `--help`.

## Step 1 — Prep the file

```bash
node scripts/prep-incidents.mjs --csv "<path>"
```

Writes a run directory `./toil-run-YYYYMMDD-HHMM` (or wherever `--out` points). Add `--rules <team-rules.json>` for a team's own rule pack, `--mode full|subset` to override detection, `--top N` for more candidates, `--min-cluster N` to change what counts as repetitive.

The script sniffs delimiter and encoding, maps columns, categorises every incident (terms in the short description outweigh terms in the description, which outweigh close notes), groups near-duplicates into offenders, and scores them. It prints a summary and writes `summary.json`, `incidents_tagged.csv`, `clusters.csv`, `prep_report.md` and per-category subsets.

Hours per month are normalised over the window the dump covers, so six incidents in six days inside a 30-day export read as six a month, not thirty. The report says how many days were observed; quote that alongside any rate.

**Check the column map before going further.** If `missing_required` is non-empty, or most rows land in `uncategorized`, say so and fix it — usually the CSV was exported with display labels instead of field names, or the team's estate needs different rules. A bad mapping quietly poisons every number downstream.

Full vs subset is detected from ToilLens columns (`toil_score`, `toil_category`, `technical_hours`, `business_hours`). Present the detection, don't hide it — the person may have exported the wrong file.

## Step 2 — Confirm the target in the picker

```bash
node scripts/picker.mjs --run "<run dir>" --detach
```

This starts a small local page (127.0.0.1, random port — nothing is hosted), tries to open the person's browser, prints the URL, and returns immediately. Tell the person the page is open and what it's asking. If no tab appeared, give them the URL: on WSL, SSH sessions and containers there's often no browser helper to call.

Then poll for their answer:

```bash
node scripts/wait-selection.mjs --run "<run dir>"
```

It waits about 40 seconds and exits, so it never gets cut off mid-wait. Exit 0 means it prints their selection and you carry on. Exit 3 means no submit yet — run it again, as many times as the person reasonably needs. Exit 4 means the page timed out or was closed; relaunch with `--detach` or switch to chat.

Don't use the blocking form (`picker.mjs --run <dir>` with no `--detach`) from inside a session. It holds the command open until someone clicks, and people usually take longer than the harness will wait — the command gets moved to the background and you lose the thread even though the page is still up. The blocking form is for a person running the script themselves in a terminal.

The page collects: what to work on, how to gather evidence and how deep, what to produce. Options preflight didn't detect are greyed with the reason but stay clickable, because detection reads config rather than the live session — if the person picks a greyed option, ask whether that tool really is available before relying on it. When nothing was detected the page defaults to evidence `skip` and publish `none`, which is the honest starting point on a bare laptop. It writes `selection.json` and shuts down after one submit.

If the person would rather not use the page at all — or nothing can bind a local port — ask the three questions in conversation and write `selection.json` yourself, because the later scripts read it:

```json
{"target": "cat:control_m", "evidence": "dynatrace_mcp", "depth": "quick",
 "max_clusters": 8, "lookback_days": 30, "publish": ["jira", "confluence"], "draft_only": true}
```

`target` is `cat:<category_id>` from `summary.json`, two of them comma-separated (`cat:control_m,cat:mft_transfer`) when two toil items are in scope, or `all`. `evidence` is `dynatrace_mcp`, `dynatrace_cli`, `triage_skill` or `skip`. `depth` is `quick` or `standard`.

For a **subset**, the picker pre-selects the dominant category; confirm rather than re-ask. For a **full dump**, the person picks one candidate, or two if both are in scope — each gets its own offender budget. Discourage `all` on a large dump — it burns hours of evidence gathering for a demo's worth of value. Suggest the top-scoring category and say why.

## Step 3 — Show the grouping before spending anything

```bash
node scripts/offenders.mjs --run "<run dir>"
```

Prints the offenders for the chosen category: id, name, count, window, hours per month, groups, sample incident numbers and text. Show it and ask for corrections. Two things go wrong here, both cheap now and expensive later:

- **Under-grouping** — one job appearing as three offenders because the wording varies. Merge them.
- **Over-grouping** — two different failures merged because their text is similar. This needs a more specific `offender_patterns` entry in the rule pack and a re-run of step 1; it can't be undone by an override.

Corrections go in `overrides.json` in the run dir, and every later step applies them automatically:

```json
{"merge": [["2dfc2115ec", "67a43f837b"]], "drop": ["fdbbc79bf0"], "rename": {"2dfc2115ec": "GL and PAY nightly chain"}}
```

The first id in a merge group survives with the combined counts, hours and window. Re-run `offenders.mjs` to confirm the result before moving on. Keep the file — it's how the next run on the same data reproduces the grouping, and it tells you what to fix in the rule pack.

## Step 4 — Gather evidence per offender, shallow by default

This step produces a **triage signal, not a root cause analysis**: one defensible line per offender saying what fails, how often, with what error. The person who picks up the Jira does the real investigation with the system in front of them and far better context than you have here.

Evidence is gathered **per offender, not per incident**. Investigating 14 incidents of the same job failure 14 times is exactly the toil this pipeline exists to remove.

```bash
node scripts/evidence-plan.mjs --run "<run dir>"
```

Prints the selected offenders in priority order with a bounded window, the single fact to retrieve, and **the exact DQL to run** for each (from the templates in `rules.json`, dates and search term filled in), and writes `evidence_plan.json`. Run the DQL as printed; work down the list and stop at the end of it. With two targets the list is grouped by category and `max_clusters` applies to each.

**The budget, which is the whole point of this step:**
- `quick` depth (default): **one query per offender**, and it is the printed one. Eight offenders is eight queries.
- A second query only if the first returned nothing usable, once. If a third would be needed, mark that offender `low` confidence and move on.
- `standard` depth allows three per offender — for one or two that clearly matter, or when the person asks. Never across a whole list by default.
- Every query bounded to the plan's window and entity, aggregate in shape, with a top-N limit. No individual traces, no full stack traces, no per-incident lookups.
- Keep one line of error signature and one or two sentences of observation. Discard the rest; never paste raw tool output into the conversation or the ticket. Payloads left in context make every later offender more expensive.
- Stop early if three offenders in a row return nothing — that usually means offender keys don't match entity names in their tenant. Ask rather than burn the budget.

Read `references/evidence.md` for the tool specifics (which MCP tools to use and avoid, dtctl flags), the three DQL templates and why every one ends in `limit 5`, and what this estate's telemetry cannot see.

Sources, from `selection.json`:

- **`dynatrace_mcp`** — `execute_dql` with the printed DQL; skip `verify_dql`, NL-to-DQL, CoPilot and analyzers. Extract the one line, discard the rest.
- **`dynatrace_cli`** — `dtctl query "<printed DQL>" --plain -o json`. The DQL already limits rows. Ignore dtctl's own investigative skill here; the budget wins. Record the full command in `query` so it's reproducible.
- **`triage_skill`** — invoke the team's own triage skill per offender with the offender key and window, and take its summary as the evidence block. Ask it for a summary, not a full triage report.
- **`skip`** — no queries. Every finding is `low` confidence and the output says plainly that no external evidence was gathered. A ticket that looks evidence-backed but isn't will get someone burned in a review.

Categories like `credential_access`, `report_extract` and `data_fix` rarely appear in telemetry — skip the query and rely on volume and repetition from the incident data, which you already have.

Write `findings.json` in the run dir:

```json
{
  "target": "cat:control_m",
  "evidence_source": "dynatrace_mcp",
  "depth": "quick",
  "lookback_days": 30,
  "findings": [
    {
      "cluster_id": "2dfc2115ec",
      "error_signature": "ORA-01555 snapshot too old during extract step",
      "evidence": [
        {"source": "dynatrace_mcp", "query": "<the query or command you ran>",
         "observed": "<one or two sentences with numbers>", "link": "<optional deep link>"}
      ],
      "root_cause_hypothesis": "Extract overruns the undo retention when the upstream feed is late",
      "confidence": "high",
      "fix_path": "aap_job_template",
      "fix_summary": "Pre-check job template that verifies feed arrival, retry once with a longer undo window",
      "est_hours_saved_per_month": 3.5
    }
  ]
}
```

`cluster_id` comes from the plan — copy it exactly; it links the ticket to the incidents and drives dedup. Everything else is optional: counts, windows, hours and offender names are filled from the cluster data (with overrides applied), so don't retype them. The renderer trims `error_signature` and `observed` if they run long, so a stray payload can't reach a ticket, but keep them short at the source.

Rules for filling this in, because the credibility of the whole thing rests on it:
- `error_signature` and `observed` must come from something actually returned. If a query returned nothing, record that it returned nothing.
- `confidence` is `high` only when the evidence names the failure; `medium` when it's consistent but indirect; `low` when it's inference from incident text or a query came back empty.
- `root_cause_hypothesis` is a hypothesis, and the output says so. Don't state a cause as fact, and don't stretch one shallow query into a confident cause.
- `est_hours_saved_per_month` is optional. The plan shows each offender's current hours per month; a fix rarely recovers all of it, so treat that as the ceiling and say what fraction you're assuming. Leave it out rather than invent it.

Valid `fix_path` values: `aap_job_template`, `config_change`, `code_change`, `monitoring`, `process`, `vendor`, `unknown`.

## Step 5 — Produce the drafts

```bash
node scripts/render-outputs.mjs --run "<run dir>" --project "<JIRA-PROJECT>" [--issue-type Task] [--existing existing_jira.json]
```

Per offender: a Markdown draft and a Jira wiki-markup draft (`.jira.txt`). Per category: a Confluence page as Markdown, as plain HTML, and as storage format. Plus `drafts/jira/jira_payload.json`, `drafts/index.md` and `dashboard_summary.json`.

Which format to hand over depends on what the team has:
- Jira Cloud editor or an MCP that takes Markdown → the `.md`. Jira Server/DC, or the REST v2 `description` field → the `.jira.txt`. Pasting Markdown into DC renders the `#` signs literally, which looks sloppy in front of a reviewer.
- Confluence MCP or "insert Markdown" → the `.md`. No MCP → open the `.html` in a browser, select all, copy, paste into the Confluence editor; tables and headings survive. The `.storage.html` is only for the REST API or an MCP that takes storage format — pasted into the editor it shows raw tags.

**Deduplicate before creating anything.** If a Jira MCP is connected, query for label `toil-sig-*` (or the project's toil label), save the result as `existing_jira.json`, and pass `--existing`. Cluster ids are keyed on the offender, not the wording, so the same job failing again next quarter maps to the same id and gets skipped. Re-runs across months are the normal case, and a backlog full of duplicate toil tickets is how teams stop trusting the tool.

Then show `drafts/index.md` and stop. Do not create Jira issues or Confluence pages until the person says yes, even if `selection.json` lists `jira` and `confluence` — that selection is intent, not approval. If `draft_only` is true, don't create anything; hand over the drafts.

On approval:
- **Jira** — one issue per `"action": "create"` record in `jira_payload.json`, using its `summary`, `labels`, `issue_type` and the body from the format the team needs. Report the created keys and write them back into `findings.json` as `jira_key`, then re-run `render-outputs.mjs` so the Confluence page shows the keys. No MCP? Hand over the payload and drafts for paste-in, and say that's what you're doing.
- **Confluence** — under the team's toil space, linking the created Jira keys.

Finish by pointing at `dashboard_summary.json` — that's what the toil metrics dashboard consumes, so the numbers in the deck match the numbers in the tickets.

## What good output looks like

A Jira that a fixer can act on without re-reading the incidents: what fails, how often, over what window, the observed error, the proposed fix path, and what it currently costs per month. A Confluence page a manager can read in two minutes and see how many incidents fall in the category, which offenders drive it, and what's now in the backlog.

## Guardrails

- Never create tickets, pages or any other record without explicit approval in the conversation.
- Never invent an error message, a metric, a link or an hours figure. Missing evidence gets written down as missing.
- Evidence stays shallow on purpose: one bounded query per offender by default, aggregate results only, no raw tool payloads in the conversation or the tickets.
- Incident data stays local. Don't upload the CSV anywhere; the picker binds to 127.0.0.1 only.
- Watch for PII in incident text (names, account numbers, emails) before anything reaches Confluence. Redact and mention it.
- On a big file (>20k rows) or a broad target, warn about time before starting rather than halfway through. Prep itself is fast — 50k rows in a few seconds — the cost is in evidence.
- Counts are counts; causes are hypotheses. Keep that distinction visible in every artefact.

## Files

| File | Read it when |
|---|---|
| `scripts/preflight.mjs` | Start of every run — also detects MCPs and CLIs |
| `scripts/prep-incidents.mjs` | Step 1 |
| `scripts/picker.mjs` | Step 2 — launch with `--detach` |
| `scripts/wait-selection.mjs` | Step 2 — poll for the submit |
| `scripts/offenders.mjs` | Step 3 — review table, applies overrides |
| `scripts/evidence-plan.mjs` | Step 4 — bounded query plan |
| `scripts/render-outputs.mjs` | Step 5 |
| `scripts/lib/csv.mjs`, `lib/text.mjs`, `lib/clusters.mjs` | Changing parsing, grouping or override behaviour |
| `assets/picker.template.html` | Restyling the picker (brand tokens at the top) |
| `references/rules.json` | Default categories, offender patterns, evidence hints, DQL templates; copy and tune per team |
| `references/evidence.md` | Step 4 — what to retrieve per category, MCP vs CLI |
| `references/manual-fallback.md` | Node unavailable or too old |
| `references/rollout.md` | Packaging this for other teams / Confluence distribution |
