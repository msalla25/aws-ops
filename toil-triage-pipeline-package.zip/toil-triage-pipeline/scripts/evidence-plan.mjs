#!/usr/bin/env node
/**
 * evidence-plan.mjs - print a compact, bounded plan for the evidence step.
 *
 * The point is token discipline. Instead of improvising a query per offender and
 * pulling back whatever comes, this emits a fixed short list: which offenders, what
 * window, what single fact to get, and the exact DQL to run for it. Work down the
 * list and stop at the end of it.
 *
 *   node scripts/evidence-plan.mjs --run ./toil-run-20260909
 *   node scripts/evidence-plan.mjs --run ./run --max 5 --lookback 14
 *   node scripts/evidence-plan.mjs --run ./run --category control_m,mft_transfer
 *
 * With several categories, --max applies to each one (each toil item gets its own
 * budget). Writes evidence_plan.json and prints the same thing as a short list.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadClusters, parseTargets } from './lib/clusters.mjs';
import { ymd } from './lib/text.mjs';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });

const HERE = path.dirname(fileURLToPath(import.meta.url));

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) o[x.slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
  }
  return o;
}

const a = args(process.argv);
if (!a.run || a.help) {
  console.error('Usage: node evidence-plan.mjs --run <run-dir> [--max N per category] [--lookback DAYS] [--category id[,id]] [--depth quick|standard] [--source name]');
  process.exit(a.help ? 0 : 1);
}

const load = (p, d = null) => (fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : d);
const sel = load(path.join(a.run, 'selection.json'), {}) || {};
const rules = load(a.rules || path.join(HERE, '..', 'references', 'rules.json'), { categories: [], dql_templates: {} });
const cats = Object.fromEntries([...rules.categories, rules.uncategorized || { id: 'uncategorized' }].map((c) => [c.id, c]));
const templates = rules.dql_templates || {};

const targets = parseTargets(a.category || sel.target);
const max = parseInt(a.max || sel.max_clusters || '8', 10);
const lookback = parseInt(a.lookback || sel.lookback_days || '30', 10);
const depth = a.depth || sel.depth || 'quick';
const source = a.source || sel.evidence || 'dynatrace_mcp';
const perOffender = depth === 'standard' ? 3 : 1;

function windowFor(r) {
  // Clamp to lookback days ending at last_seen, so a long-lived cluster doesn't
  // pull a year of telemetry for one line of evidence. Local dates throughout -
  // toISOString() would shift the calendar day for US time zones.
  const last = r.last_seen || '';
  const first = r.first_seen || '';
  if (!last) return { from: first, to: last, clamped: false };
  const lastD = new Date(last + 'T23:59:59');
  const floor = new Date(lastD.getTime() - lookback * 864e5);
  const firstD = first ? new Date(first + 'T00:00:00') : floor;
  const fromD = firstD > floor ? firstD : floor;
  return { from: ymd(fromD), to: last, clamped: firstD < floor };
}

function dqlFor(r, w) {
  const cat = cats[r.category_id] || {};
  const name = cat.dql_template || 'log_signature';
  const tpl = templates[name];
  if (!tpl) return { template: name, dql: '' };
  const ci = (r.sample_ci || r.cmdb_ci || r.offender || '').replace(/"/g, '');
  const dql = tpl
    .replace(/\{from\}/g, w.from).replace(/\{to\}/g, w.to)
    .replace(/\{offender\}/g, String(r.offender_search || r.offender || '').replace(/"/g, ''))
    .replace(/\{ci\}/g, ci)
    .replace(/\{metric\}/g, cat.metric || '<metric key>');
  return { template: name, dql };
}

const { clusters: all, applied } = loadClusters(a.run, { category: 'all' });
const wanted = targets[0] === 'all' ? all : all.filter((c) => targets.includes(c.category_id));
const byCat = new Map();
for (const c of wanted) {
  if (!byCat.has(c.category_id)) byCat.set(c.category_id, []);
  byCat.get(c.category_id).push(c);
}

const offenders = [], skipped = {};
const catOrder = targets[0] === 'all'
  ? [...byCat.keys()].sort((x, y) => (byCat.get(y)[0]?.priority_score || 0) - (byCat.get(x)[0]?.priority_score || 0))
  : targets.filter((t) => byCat.has(t));
for (const cid of catOrder) {
  const list = byCat.get(cid).sort((x, y) => y.priority_score - x.priority_score);
  const take = targets[0] === 'all' ? list : list.slice(0, max); // 'all' is capped below, overall
  skipped[cid] = list.length - take.length;
  for (const r of take) {
    const w = windowFor(r);
    const q = dqlFor(r, w);
    offenders.push({
      cluster_id: r.cluster_id,
      offender: r.offender,
      search_term: r.offender_search || r.offender,
      category_id: r.category_id,
      category_label: r.category_label,
      incidents: r.count,
      hours_per_month: r.hours_per_month,
      hours_basis: r.hours_basis,
      merged_from: r.merged_from || [],
      from: w.from,
      to: w.to,
      window_clamped_to_lookback: w.clamped,
      get_only: (cats[r.category_id] || {}).evidence_hint || 'One aggregate error-count query, then stop.',
      template: q.template,
      suggested_dql: q.dql,
    });
  }
}
let plannedOffenders = offenders;
if (targets[0] === 'all') {
  plannedOffenders = [...offenders].sort((x, y) => (y.hours_per_month || 0) - (x.hours_per_month || 0)).slice(0, max);
  skipped.all = offenders.length - plannedOffenders.length;
}
const queries = plannedOffenders.filter((o) => o.template !== 'none').length * perOffender;
const missing = targets.filter((t) => t !== 'all' && !byCat.has(t));

const plan = {
  run_dir: path.resolve(a.run),
  targets,
  evidence_source: source,
  depth,
  lookback_days: lookback,
  query_budget: { per_offender: perOffender, total: queries },
  offenders: plannedOffenders,
  skipped_offenders: skipped,
  targets_not_found: missing,
};
fs.writeFileSync(path.join(a.run, 'evidence_plan.json'), JSON.stringify(plan, null, 2));

console.log(`# Evidence plan - ${source}, depth "${depth}", targets: ${targets.join(', ')}`);
if (applied.length) console.log(`overrides applied: ${applied.join('; ')}`);
if (missing.length) console.log(`WARNING: no offenders found for: ${missing.join(', ')} (check category ids in summary.json)`);
console.log(`Budget: ${perOffender} quer${perOffender === 1 ? 'y' : 'ies'} per offender, ${queries} total. Work down this list and stop at the end of it.\n`);
let lastCat = null;
plannedOffenders.forEach((o, i) => {
  if (o.category_label !== lastCat) { console.log(`## ${o.category_label}`); lastCat = o.category_label; }
  console.log(`${i + 1}. ${o.offender}  [${o.cluster_id}]  x${o.incidents}  ${o.from} -> ${o.to}  ~${o.hours_per_month} hrs/mo`);
  console.log(`   get only: ${o.get_only}`);
  if (o.template === 'none') console.log('   query: none - not visible in telemetry, use incident text');
  else console.log(`   dql: ${o.suggested_dql}`);
});
const skippedTotal = Object.values(skipped).reduce((s, n) => s + n, 0);
if (skippedTotal > 0) {
  console.log(`\n${skippedTotal} lower-scoring offender(s) not in this plan. Say so in the output rather than quietly dropping them.`);
}
console.log(`\nWrote ${path.join(a.run, 'evidence_plan.json')}`);
