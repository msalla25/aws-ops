#!/usr/bin/env node
/**
 * offenders.mjs - print the offenders for review before any evidence is gathered.
 * Applies overrides.json if present, so you can see the effect of a merge/drop/rename
 * before it flows into the plan and the tickets.
 *
 *   node scripts/offenders.mjs --run ./toil-run-20260909            # category from selection.json
 *   node scripts/offenders.mjs --run ./run --category control_m --max 20
 */

import fs from 'node:fs';
import path from 'node:path';
import { loadClusters, parseTargets } from './lib/clusters.mjs';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) o[x.slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
  }
  return o;
}

const a = args(process.argv);
if (!a.run || a.help) {
  console.error('Usage: node offenders.mjs --run <run-dir> [--category id[,id]|all] [--max N]');
  process.exit(a.help ? 0 : 1);
}
const selPath = path.join(a.run, 'selection.json');
const sel = fs.existsSync(selPath) ? JSON.parse(fs.readFileSync(selPath, 'utf8')) : {};
const targets = parseTargets(a.category || sel.target);
const max = parseInt(a.max || '15', 10);

const { clusters: all, applied } = loadClusters(a.run, { category: 'all' });
const clusters = targets[0] === 'all' ? all : all.filter((c) => targets.includes(c.category_id));
const shown = clusters.slice(0, max);

console.log(`# Offenders - ${targets.join(', ')} (${clusters.length} total, showing ${shown.length})`);
if (applied.length) console.log(`overrides applied: ${applied.join('; ')}`);
console.log('');
console.log('| # | id | category | offender | n | window | hrs/mo | groups | samples |');
console.log('|--:|---|---|---|--:|---|--:|---|---|');
shown.forEach((c, i) => {
  const merged = c.merged_from?.length ? ` (+${c.merged_from.length} merged)` : '';
  console.log(`| ${i + 1} | ${c.cluster_id} | ${c.category_id} | ${c.offender}${merged} | ${c.count} | ${c.first_seen}..${c.last_seen} | ${c.hours_per_month} ${c.hours_basis === 'reported' ? '' : '~'} | ${c.assignment_groups.join(', ')} | ${c.sample_incidents.slice(0, 3).join(' ')} |`);
  console.log(`|   |   |   | _${(c.sample_text || '').slice(0, 110)}_ |  |  |  |  |  |`);
});
if (clusters.length > shown.length) console.log(`\n${clusters.length - shown.length} more not shown (use --max).`);
console.log('\nTo correct grouping, write overrides.json in the run dir: {"merge":[["idA","idB"]],"drop":["idC"],"rename":{"idD":"better name"}}');
console.log('Over-merged? Tighten the offender pattern in the rule pack and re-run prep - a split is not an override.');
