#!/usr/bin/env node
/**
 * wait-selection.mjs - wait a short while for the detached picker to be submitted.
 *
 * Deliberately short-lived. An agent harness will cut a command off after a minute or
 * two, and a person reading the picker often takes longer than that, so this returns
 * quickly and is meant to be run again rather than held open.
 *
 *   node scripts/wait-selection.mjs --run ./toil-run-20260909
 *   node scripts/wait-selection.mjs --run ./run --timeout 30
 *
 * Exit codes: 0 selection found (printed as JSON) | 3 not yet, run again | 4 picker gone.
 */

import fs from 'node:fs';
import path from 'node:path';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) o[x.slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
  }
  return o;
}

const a = args(process.argv);
if (!a.run || a.help) {
  console.error('Usage: node wait-selection.mjs --run <run-dir> [--timeout 40]');
  process.exit(a.help ? 0 : 1);
}

const selPath = path.join(a.run, 'selection.json');
const urlPath = path.join(a.run, 'picker_url.txt');
const waitSec = Math.min(parseInt(a.timeout || '40', 10), 90);
const sleep = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);

const deadline = Date.now() + waitSec * 1000;
while (Date.now() < deadline) {
  if (fs.existsSync(selPath)) {
    // The file may be mid-write on the first glimpse; a bad parse just means try again.
    try {
      const sel = JSON.parse(fs.readFileSync(selPath, 'utf8'));
      console.log('SELECTION:');
      console.log(JSON.stringify(sel, null, 2));
      process.exit(0);
    } catch { /* incomplete write - fall through and retry */ }
  }
  sleep(500);
}

if (!fs.existsSync(urlPath)) {
  console.log('No selection, and the picker is no longer running (it timed out or was closed).');
  console.log(`Relaunch: node scripts/picker.mjs --run ${a.run} --detach`);
  console.log('Or skip the page and ask the three questions in chat, then write selection.json yourself.');
  process.exit(4);
}

console.log(`Still waiting - no submit yet after ${waitSec}s. The picker is up at ${fs.readFileSync(urlPath, 'utf8').trim()}`);
console.log('Run this again to keep waiting. If the person would rather not use the page, ask in chat instead.');
process.exit(3);
