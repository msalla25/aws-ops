#!/usr/bin/env node
/**
 * preflight.mjs - what's actually available on this machine, in well under a second.
 *
 *   node scripts/preflight.mjs                       # check, write ./capabilities.json
 *   node scripts/preflight.mjs --out ./run/capabilities.json
 *   node scripts/preflight.mjs --set jira_mcp=yes,dynatrace_cli=no   # override detection
 *
 * Checks: Node version, skill files intact, a local port can bind, which CLIs are on
 * PATH (dtctl, jira, acli, confluence), and which MCP servers are configured for
 * Claude Code (Dynatrace / Jira / Confluence / Atlassian) by reading the config files.
 *
 * A configured MCP is not the same as a connected one. The script reads config; the
 * agent must confirm against the tools it can actually see in the session, and use
 * --set to correct the record. The picker then offers only what's viable.
 */

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });

const T0 = Date.now();
const HERE = path.dirname(fileURLToPath(import.meta.url));

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) o[x.slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
  }
  return o;
}
const a = args(process.argv);
if (a.help) {
  console.error('Usage: node preflight.mjs [--out capabilities.json] [--set key=yes|no,...]');
  console.error('  keys: dynatrace_mcp dynatrace_cli jira_mcp jira_cli confluence_mcp confluence_cli');
  process.exit(0);
}

// ------------------------------------------------------------- basics
const major = parseInt(process.versions.node.split('.')[0], 10);
console.log('== toil-triage-pipeline preflight ==');
console.log(`node      : v${process.versions.node} ${major >= 16 ? '(ok)' : '(TOO OLD - needs 16+)'}`);
console.log(`platform  : ${process.platform} ${os.arch()}`);
console.log(`cwd       : ${process.cwd()}`);

const files = ['prep-incidents.mjs', 'picker.mjs', 'wait-selection.mjs', 'offenders.mjs', 'evidence-plan.mjs',
  'render-outputs.mjs', 'lib/csv.mjs', 'lib/text.mjs', 'lib/clusters.mjs']
  .map((f) => [f, fs.existsSync(path.join(HERE, f))]);
const tpl = fs.existsSync(path.join(HERE, '..', 'assets', 'picker.template.html'));
const rules = fs.existsSync(path.join(HERE, '..', 'references', 'rules.json'));
const bad = files.filter(([, ok]) => !ok).map(([f]) => f);
console.log(`scripts   : ${bad.length ? 'MISSING ' + bad.join(', ') : 'all present'}`);
console.log(`assets    : picker template ${tpl ? 'ok' : 'MISSING'}, rules.json ${rules ? 'ok' : 'MISSING'}`);

const http = await import('node:http');
const portOk = await new Promise((resolve) => {
  const s = http.createServer(() => {});
  s.on('error', (e) => { console.log(`localhost : cannot bind (${e.code}) - picker will use --static-only`); resolve(false); });
  s.listen(0, '127.0.0.1', () => { console.log(`localhost : bind ok`); s.close(() => resolve(true)); });
});

// ------------------------------------------------------------- CLIs on PATH
function onPath(bin) {
  const r = process.platform === 'win32'
    ? spawnSync('where', [bin], { encoding: 'utf8', windowsHide: true, timeout: 1500 })
    : spawnSync('sh', ['-c', `command -v ${bin}`], { encoding: 'utf8', timeout: 1500 });
  return r.status === 0 ? (r.stdout || '').trim().split(/\r?\n/)[0] : '';
}
const cli = {};
for (const b of ['dtctl', 'jira', 'acli', 'confluence']) cli[b] = onPath(b);

// ------------------------------------------------------------- MCP config files
// Claude Code keeps MCP servers in ~/.claude.json (user scope, and per-project under
// "projects"), and in .mcp.json at a project root (project scope). Read, don't execute.
function readJson(p) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; } }
const home = os.homedir();
const mcpFound = []; // {name, where, blob}
function collect(obj, where) {
  if (!obj || typeof obj !== 'object') return;
  for (const [name, def] of Object.entries(obj.mcpServers || {})) {
    mcpFound.push({ name, where, blob: `${name} ${JSON.stringify(def || {})}`.toLowerCase() });
  }
}
const userCfg = readJson(path.join(home, '.claude.json'));
if (userCfg) {
  collect(userCfg, '~/.claude.json');
  // Per-project entries only apply when we're inside that project.
  const cwdN = path.resolve(process.cwd()).toLowerCase();
  for (const [proj, pc] of Object.entries(userCfg.projects || {})) {
    const pN = path.resolve(proj).toLowerCase();
    if (cwdN === pN || cwdN.startsWith(pN + path.sep)) collect(pc, `~/.claude.json projects[${proj}]`);
  }
}
let dir = process.cwd();
for (let i = 0; i < 12; i++) {
  collect(readJson(path.join(dir, '.mcp.json')), path.join(dir, '.mcp.json'));
  for (const f of ['settings.json', 'settings.local.json']) collect(readJson(path.join(dir, '.claude', f)), path.join(dir, '.claude', f));
  const up = path.dirname(dir); if (up === dir) break; dir = up;
}
collect(readJson(path.join(home, '.claude', 'settings.json')), '~/.claude/settings.json');

const hit = (re) => mcpFound.find((m) => re.test(m.blob));
const dtMcp = hit(/dynatrace|\bdt-?mcp\b|apps\.dynatrace/);
const atlMcp = hit(/atlassian|rovo/);
const jiraMcp = hit(/jira/) || atlMcp;
const confMcp = hit(/confluence/) || atlMcp;

// ------------------------------------------------------------- env hints
const env = (re) => Object.keys(process.env).filter((k) => re.test(k));
const dtEnv = env(/^(DT_|DYNATRACE_)/);
const jiraEnv = env(/^(JIRA_|ATLASSIAN_)/);
const confEnv = env(/^(CONFLUENCE_|ATLASSIAN_)/);

// ------------------------------------------------------------- assemble
const cap = {
  checked_at: new Date().toISOString(),
  node: process.versions.node,
  local_port_ok: portOk,
  dynatrace_mcp: dtMcp ? { available: true, source: `MCP "${dtMcp.name}" in ${dtMcp.where}` } : { available: false, source: 'no Dynatrace MCP in Claude Code config' },
  dynatrace_cli: cli.dtctl ? { available: true, source: `dtctl at ${cli.dtctl}` } : { available: false, source: 'dtctl not on PATH' },
  jira_mcp: jiraMcp ? { available: true, source: `MCP "${jiraMcp.name}" in ${jiraMcp.where}` } : { available: false, source: 'no Jira/Atlassian MCP in Claude Code config' },
  jira_cli: cli.jira || cli.acli ? { available: true, source: cli.jira ? `jira at ${cli.jira}` : `acli at ${cli.acli}` } : { available: false, source: 'no jira or acli on PATH' },
  confluence_mcp: confMcp ? { available: true, source: `MCP "${confMcp.name}" in ${confMcp.where}` } : { available: false, source: 'no Confluence/Atlassian MCP in Claude Code config' },
  confluence_cli: cli.confluence || cli.acli ? { available: true, source: cli.confluence ? `confluence at ${cli.confluence}` : `acli at ${cli.acli} (verify it has Confluence support)` } : { available: false, source: 'no confluence or acli on PATH' },
  env_hints: { dynatrace: dtEnv, jira: jiraEnv, confluence: confEnv },
  overrides: {},
  notes: [
    'MCP entries come from config files. A configured server may not be connected in this session: confirm against the tools you can actually see, and correct with --set.',
    'CLI entries mean the binary is on PATH, not that it is authenticated.',
  ],
};

// --set overrides, applied last and recorded
for (const kv of String(a.set || '').split(',').filter(Boolean)) {
  const [k, v] = kv.split('=').map((s) => s.trim());
  if (cap[k] && typeof cap[k] === 'object' && 'available' in cap[k]) {
    cap[k] = { available: /^(y|yes|true|1)$/i.test(v || ''), source: `set by --set ${kv}` };
    cap.overrides[k] = cap[k].available;
  } else console.log(`(ignored unknown --set key: ${k})`);
}
cap.check_ms = Date.now() - T0;

const out = a.out || path.join(process.cwd(), 'capabilities.json');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify(cap, null, 2));

const mark = (c) => (c.available ? 'yes' : 'no ');
console.log('');
console.log('capabilities (evidence)   dynatrace_mcp: ' + mark(cap.dynatrace_mcp) + '  dynatrace_cli: ' + mark(cap.dynatrace_cli));
console.log('capabilities (publish)    jira_mcp: ' + mark(cap.jira_mcp) + '  jira_cli: ' + mark(cap.jira_cli)
  + '  confluence_mcp: ' + mark(cap.confluence_mcp) + '  confluence_cli: ' + mark(cap.confluence_cli));
for (const k of ['dynatrace_mcp', 'dynatrace_cli', 'jira_mcp', 'jira_cli', 'confluence_mcp', 'confluence_cli']) {
  console.log(`  ${k.padEnd(15)} ${cap[k].source}`);
}
if (mcpFound.length) console.log(`  mcp configured  ${[...new Set(mcpFound.map((m) => m.name))].join(', ')}`);
console.log(`\nWrote ${out} (checked in ${cap.check_ms}ms)`);
console.log('Now reconcile: if a listed MCP is not connected in this session, or one is connected that');
console.log('was not found, re-run with --set (e.g. --set dynatrace_mcp=yes). Then prep-incidents.mjs.');
