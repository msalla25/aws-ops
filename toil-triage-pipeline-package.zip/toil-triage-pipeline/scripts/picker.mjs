#!/usr/bin/env node
/**
 * picker.mjs - show a small local page that says what we're targeting and collects
 * three answers: what to work on, how to gather evidence, what to publish.
 *
 * Nothing is hosted. It binds a random port on 127.0.0.1, opens the browser, waits
 * for one submit, writes selection.json into the run directory and exits. If a
 * browser or local socket isn't usable it still writes picker.html, so the person
 * can open it, choose, and copy the JSON back into chat.
 *
 *   node scripts/picker.mjs --run ./toil-run-20260909
 *   node scripts/picker.mjs --run ./run --static-only     # just write the HTML
 *   node scripts/picker.mjs --run ./run --timeout 900
 */

import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });


const HERE = path.dirname(fileURLToPath(import.meta.url));



function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) {
      const k = x.slice(2);
      o[k] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
    }
  }
  return o;
}

function loadCapabilities(runDir, explicit) {
  for (const cand of [explicit, path.join(runDir, 'capabilities.json'), path.join(process.cwd(), 'capabilities.json')]) {
    if (cand && fs.existsSync(cand)) { try { return JSON.parse(fs.readFileSync(cand, 'utf8')); } catch { /* next */ } }
  }
  return null; // unknown - the page then offers everything and says detection wasn't run
}

function buildHtml(summary, postEnabled, capabilities) {
  const tpl = fs.readFileSync(path.join(HERE, '..', 'assets', 'picker.template.html'), 'utf8');
  const data = { ...summary, source_name: path.basename(summary.source_csv || 'incidents.csv'), capabilities };
  return tpl
    .replace('__DATA__', JSON.stringify(data).replace(/<\//g, '<\\/'))
    .replace('__POST__', postEnabled ? 'true' : 'false');
}

function openBrowser(url) {
  const cmds = process.platform === 'win32'
    ? [['cmd', ['/c', 'start', '', url]]]
    : process.platform === 'darwin'
      ? [['open', [url]]]
      : [['xdg-open', [url]], ['sensible-browser', [url]], ['x-www-browser', [url]]];
  for (const [cmd, cargs] of cmds) {
    try {
      const p = spawn(cmd, cargs, { stdio: 'ignore', detached: true });
      p.on('error', () => {});
      p.unref();
      return true;
    } catch { /* try the next one */ }
  }
  return false;
}

function serve(html, outPath, timeoutSec, urlPath) {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      if (req.method === 'POST' && req.url === '/submit') {
        let body = '';
        req.on('data', (c) => { body += c; if (body.length > 1e6) req.destroy(); });
        req.on('end', () => {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          let sel = null;
          try { sel = JSON.parse(body || '{}'); } catch { /* malformed - treated as no selection */ }
          clearTimeout(timer);
          // Close only once the response has flushed, then drop keep-alive sockets so
          // server.close() returns immediately instead of waiting on the browser tab.
          res.end('{"ok":true}', () => server.closeAllConnections?.());
          server.close(() => {
            if (sel && Object.keys(sel).length) {
              fs.writeFileSync(outPath, JSON.stringify(sel, null, 2));
              console.log('SELECTION:');
              console.log(JSON.stringify(sel, null, 2));
              resolve(true);
            } else resolve(false);
          });
        });
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(html);
    });

    server.on('error', () => resolve(false));

    const timer = setTimeout(() => {
      console.log('No selection received before timeout.');
      server.closeAllConnections?.();
      server.close(() => resolve(false));
    }, timeoutSec * 1000);
    timer.unref?.();

    server.listen(0, '127.0.0.1', () => {
      const url = `http://127.0.0.1:${server.address().port}/`;
      try { fs.writeFileSync(urlPath, url); } catch { /* best effort */ }
      console.log(`Picker open at ${url} (waiting up to ${timeoutSec}s)`);
      if (!openBrowser(url)) console.log('Could not open a browser automatically - open the URL above.');
    });
  });
}

const a = args(process.argv);
if (!a.run || a.help) {
  console.error('Usage: node picker.mjs --run <run-dir> [--detach] [--timeout 600] [--static-only] [--capabilities file]');
  console.error('  --detach  start the page in the background, print the URL, return immediately.');
  console.error('            Then poll: node scripts/wait-selection.mjs --run <run-dir>');
  process.exit(a.help ? 0 : 1);
}

const summaryPath = path.join(a.run, 'summary.json');
if (!fs.existsSync(summaryPath)) {
  console.error(`summary.json not found in ${a.run} - run prep-incidents.mjs first.`);
  process.exit(1);
}
const summary = JSON.parse(fs.readFileSync(summaryPath, 'utf8'));
const htmlPath = path.join(a.run, 'picker.html');
const selPath = path.join(a.run, 'selection.json');
const urlPath = path.join(a.run, 'picker_url.txt');
const timeout = parseInt(a.timeout || '600', 10);
const staticOnly = a['static-only'] === 'true';
const capabilities = loadCapabilities(a.run, a.capabilities);
if (!capabilities) console.log('No capabilities.json found (run preflight.mjs first) - offering every option.');

fs.writeFileSync(htmlPath, buildHtml(summary, !staticOnly, capabilities));
console.log(`Picker page: ${htmlPath}`);

if (staticOnly) {
  console.log("Static mode: open the page, choose, click 'Copy selection', paste the JSON back.");
  process.exit(0);
}

if (a.detach === 'true') {
  // Re-launch detached so the caller's command returns straight away. A person reading
  // the page normally takes longer than an agent harness will hold a command open.
  for (const f of [selPath, urlPath]) { try { fs.unlinkSync(f); } catch { /* fine */ } }
  const child = spawn(process.execPath, [fileURLToPath(import.meta.url), '--run', a.run, '--timeout', String(timeout)],
    { detached: true, stdio: 'ignore' });
  child.unref();
  const sleep = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    if (fs.existsSync(urlPath)) {
      console.log(`Picker running in the background at ${fs.readFileSync(urlPath, 'utf8').trim()}`);
      console.log(`A browser tab should have opened. If not, give the person that URL.`);
      console.log(`It closes after one submit, or after ${timeout}s.`);
      console.log(`Next: node scripts/wait-selection.mjs --run ${a.run}`);
      process.exit(0);
    }
    sleep(150);
  }
  console.log('Picker was launched but did not report a URL within 8s.');
  console.log(`Check for a browser tab, or fall back to: node scripts/picker.mjs --run ${a.run} --static-only`);
  process.exit(0);
}

const ok = await serve(buildHtml(summary, true, capabilities), selPath, timeout, urlPath);
try { fs.unlinkSync(urlPath); } catch { /* already gone */ }
if (!ok) {
  fs.writeFileSync(htmlPath, buildHtml(summary, false, capabilities));
  console.log("Falling back: open picker.html, choose, click 'Copy selection', paste the JSON back.");
  process.exit(2);
}
