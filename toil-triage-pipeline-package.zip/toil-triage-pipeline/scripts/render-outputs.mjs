#!/usr/bin/env node
/**
 * render-outputs.mjs - turn findings.json into Jira drafts, Confluence pages and a
 * dashboard summary. Writes files only; it never calls Jira or Confluence.
 *
 *   node scripts/render-outputs.mjs --run ./toil-run-20260909 --project SRETOIL
 *   node scripts/render-outputs.mjs --run ./run --existing existing_jira.json --issue-type Story
 *
 * Per offender:   drafts/jira/<id>-<offender>.md         Markdown (Jira Cloud editor, most MCPs)
 *                 drafts/jira/<id>-<offender>.jira.txt   Jira wiki markup (Jira Server/DC, REST v2)
 * Per category:   drafts/confluence/<cat>.md             Markdown (Confluence "insert markdown", MCPs)
 *                 drafts/confluence/<cat>.html            Plain HTML - open in a browser, copy, paste into the editor
 *                 drafts/confluence/<cat>.storage.html    Confluence storage format (REST API / MCP body)
 * Plus:           drafts/jira/jira_payload.json, drafts/index.md, dashboard_summary.json
 *
 * existing_jira.json (optional, from querying Jira for label toil-sig-*):
 *   [{"key":"SRETOIL-42","labels":["toil-sig-2dfc2115ec"],"summary":"...","status":"Open"}]
 */

import fs from 'node:fs';
import path from 'node:path';
import { loadClusters } from './lib/clusters.mjs';

// Piping output to head/less closes stdout early; exit quietly instead of throwing.
process.stdout.on('error', (e) => { if (e.code === 'EPIPE') process.exit(0); });

const FIX_LABEL = {
  aap_job_template: 'Automate via AAP job template',
  config_change: 'Configuration change',
  code_change: 'Code change',
  monitoring: 'Monitoring / alerting change',
  process: 'Process or runbook change',
  vendor: 'Vendor / upstream dependency',
  unknown: 'Fix path to be determined',
};

/** Evidence is meant to be a triage signal, not a dump. Trim hard so an oversized
 *  tool payload can never end up pasted into a Jira or a Confluence page. */
const SIG_MAX = 150, OBS_MAX = 400, QUERY_MAX = 200, CAUSE_MAX = 300;
const trim = (s, max) => {
  const one = String(s ?? '').replace(/\s+/g, ' ').trim();
  return one.length > max ? one.slice(0, max - 1).trimEnd() + '…' : one;
};

function args(argv) {
  const o = {};
  for (let i = 2; i < argv.length; i++) {
    const x = argv[i];
    if (x.startsWith('--')) o[x.slice(2)] = argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : 'true';
  }
  return o;
}

const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const slug = (s) => (String(s ?? 'item').replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48) || 'item');
const round = (n) => Math.round(n * 10) / 10;
const load = (p, d = null) => (p && fs.existsSync(p) ? JSON.parse(fs.readFileSync(p, 'utf8')) : d);
const fixLabel = (f) => FIX_LABEL[f.fix_path] || f.fix_path || FIX_LABEL.unknown;

function stamp(withTime = true) {
  const d = new Date(); const p = (n) => String(n).padStart(2, '0');
  const day = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  return withTime ? `${day} ${p(d.getHours())}:${p(d.getMinutes())}` : day;
}

// ------------------------------------------------------------ one data model
// Everything below renders from this so the Markdown, wiki and HTML never drift.
function model(f, summary, cfg) {
  const hrsInScope = (f.technical_hours || f.business_hours)
    ? round((f.technical_hours || 0) + (f.business_hours || 0)) : (f.estimated_hours || 0);
  return {
    id: f.cluster_id,
    offender: f.offender || f.cluster_id,
    category: f.category_label || 'Toil',
    categoryLabelSlug: slug(f.category_id || 'uncategorized').toLowerCase(),
    count: f.count || 0,
    window: `${f.first_seen || '?'} to ${f.last_seen || '?'}`,
    lookback: cfg.lookback_days ?? '?',
    groups: f.assignment_groups || [],
    signature: trim(f.error_signature, SIG_MAX) || 'not established - incident text only',
    evidence: (f.evidence || []).map((e) => ({
      source: e.source || 'source', observed: trim(e.observed, OBS_MAX),
      query: trim(e.query, QUERY_MAX), link: e.link || '',
    })),
    cause: trim(f.root_cause_hypothesis, CAUSE_MAX) || 'Not established.',
    confidence: f.confidence || 'low',
    fix: fixLabel(f),
    fixSummary: trim(f.fix_summary, CAUSE_MAX) || 'To be defined.',
    tech: f.technical_hours || 0,
    biz: f.business_hours || 0,
    basis: f.hours_basis || 'estimated',
    hrsPerMonth: f.hours_per_month ?? null,
    hrsInScope,
    estSaved: f.est_hours_saved_per_month ?? null,
    samples: f.sample_incidents || [],
    merged: f.merged_from || [],
    jiraKey: f.jira_key || '',
    labels: ['toil', 'toil-analyzer', `toil-sig-${f.cluster_id}`, slug(f.category_id || 'uncategorized').toLowerCase()],
    source: path.basename(summary.source_csv || ''),
  };
}

function jiraSummary(m) {
  return `[${m.category}] ${m.offender} - ${m.count} incidents, ${m.fix}`;
}

function jiraMarkdown(m) {
  const L = [
    `# ${m.offender} - ${m.count} incidents`, '',
    `**Suggested summary:** ${jiraSummary(m)}`, '',
    `**Labels:** ${m.labels.join(', ')}`, '',
    '## What is happening',
    `${m.offender} generated **${m.count} incidents** between ${m.window}`
      + (m.groups.length ? `, handled by ${m.groups.join(', ')}` : '') + '.'
      + (m.merged.length ? ` Includes ${m.merged.length} merged grouping(s) confirmed as the same failure.` : ''), '',
    `Common error signature: \`${m.signature}\``, '',
    '## Evidence',
  ];
  if (m.evidence.length) {
    for (const e of m.evidence) {
      L.push(`- **${e.source}**: ${e.observed}` + (e.query ? ` (query: \`${e.query}\`)` : '') + (e.link ? ` [link](${e.link})` : ''));
    }
  } else L.push('- No external evidence gathered; conclusions are from incident text only.');
  L.push('', '## Likely cause', `${m.cause} (confidence: **${m.confidence}**)`, '',
    '## Proposed fix', `**${m.fix}** - ${m.fixSummary}`, '',
    '## Value if fixed',
    `- Incidents removed: ~${m.count} per ${m.lookback} days`,
    `- Hours in scope: technical ${m.tech}, business ${m.biz} (${m.basis})`);
  if (m.hrsPerMonth !== null) L.push(`- Currently costing about **${m.hrsPerMonth} hours per month** (${m.basis})`);
  if (m.estSaved !== null) L.push(`- Estimated hours saved per month if fixed: **${m.estSaved}**`);
  L.push('', '## Sample incidents', m.samples.join(', ') || 'n/a', '',
    `_Generated ${stamp()} from ${m.source} by the toil triage pipeline. Cluster ${m.id}._`);
  return L.join('\n');
}

function jiraWiki(m) {
  const L = [
    `h2. What is happening`,
    `${m.offender} generated *${m.count} incidents* between ${m.window}`
      + (m.groups.length ? `, handled by ${m.groups.join(', ')}` : '') + '.'
      + (m.merged.length ? ` Includes ${m.merged.length} merged grouping(s) confirmed as the same failure.` : ''), '',
    `Common error signature: {{${m.signature.replace(/[{}]/g, '')}}}`, '',
    'h2. Evidence',
  ];
  if (m.evidence.length) {
    for (const e of m.evidence) {
      L.push(`* *${e.source}*: ${e.observed}` + (e.query ? ` (query: {{${e.query.replace(/[{}]/g, '')}}})` : '') + (e.link ? ` [link|${e.link}]` : ''));
    }
  } else L.push('* No external evidence gathered; conclusions are from incident text only.');
  L.push('', 'h2. Likely cause', `${m.cause} (confidence: *${m.confidence}*)`, '',
    'h2. Proposed fix', `*${m.fix}* - ${m.fixSummary}`, '',
    'h2. Value if fixed',
    `* Incidents removed: ~${m.count} per ${m.lookback} days`,
    `* Hours in scope: technical ${m.tech}, business ${m.biz} (${m.basis})`);
  if (m.hrsPerMonth !== null) L.push(`* Currently costing about *${m.hrsPerMonth} hours per month* (${m.basis})`);
  if (m.estSaved !== null) L.push(`* Estimated hours saved per month if fixed: *${m.estSaved}*`);
  L.push('', 'h2. Sample incidents', m.samples.join(', ') || 'n/a', '',
    `_Generated ${stamp()} from ${m.source} by the toil triage pipeline. Cluster ${m.id}._`);
  return L.join('\n');
}

// ---------------------------------------------------------- confluence page
function pageModel(catLabel, models, summary, cfg) {
  return {
    catLabel,
    generated: stamp(false),
    source: path.basename(summary.source_csv || ''),
    total: summary.total_incidents,
    from: summary.date_range?.from || '?',
    to: summary.date_range?.to || '?',
    basis: summary.hours_basis || 'estimated',
    evidence: cfg.evidence || 'none',
    depth: cfg.depth || 'quick',
    mode: summary.mode || 'full',
    incidents: models.reduce((s, m) => s + m.count, 0),
    offenders: models.length,
    tech: round(models.reduce((s, m) => s + m.tech, 0)),
    biz: round(models.reduce((s, m) => s + m.biz, 0)),
    perMonth: round(models.reduce((s, m) => s + (m.hrsPerMonth || 0), 0)),
    saved: round(models.reduce((s, m) => s + (m.estSaved || 0), 0)),
    rows: models,
  };
}

function howProduced(p) {
  return [
    p.mode === 'subset'
      ? 'ToilLens filtered the ServiceNow dump and exported this subset.'
      : 'The full ServiceNow dump was categorised by rule pack; this category was chosen for triage.',
    'Incidents were grouped into offenders by normalised error signature and reviewed by a person.',
    p.evidence === 'skip' || p.evidence === 'none'
      ? 'No external evidence was gathered; findings come from incident text only.'
      : `Error detail was pulled once per offender (${p.evidence}, ${p.depth} depth), not per incident.`,
    'A person reviewed every finding before any ticket was raised.',
  ];
}

function confluenceMarkdown(p) {
  const L = [
    `> Generated ${p.generated} from \`${p.source}\` (${p.total} incidents, ${p.from} to ${p.to}). Hours basis: ${p.basis}. Evidence: ${p.evidence}.`, '',
    `## ${p.catLabel} - repeat offenders`, '',
    `**${p.incidents}** incidents across **${p.offenders}** offenders. Technical hours ${p.tech}, business hours ${p.biz}, `
      + `currently about **${p.perMonth} hours per month**.`
      + (p.saved ? ` Estimated saving if all are fixed: **${p.saved} hours per month**.` : ''), '',
    '| Offender | Incidents | Hrs/month | Common error | Likely cause | Fix path | Jira |',
    '|---|--:|--:|---|---|---|---|',
  ];
  for (const m of p.rows) {
    L.push(`| ${m.offender} | ${m.count} | ${m.hrsPerMonth ?? ''} | \`${trim(m.signature, 90)}\` | ${trim(m.cause, 160)} | ${m.fix} | ${m.jiraKey || 'draft'} |`);
  }
  L.push('', '## How this was produced', '', ...howProduced(p).map((s, i) => `${i + 1}. ${s}`), '',
    '*Counts come from the incident dump. Causes are hypotheses from the evidence listed in each Jira, not confirmed root cause.*');
  return L.join('\n');
}

function confluenceBody(p) {
  const rows = p.rows.map((m) => '<tr>'
    + `<td>${esc(m.offender)}</td>`
    + `<td style="text-align:right">${m.count}</td>`
    + `<td style="text-align:right">${m.hrsPerMonth ?? ''}</td>`
    + `<td><code>${esc(trim(m.signature, 90))}</code></td>`
    + `<td>${esc(trim(m.cause, 160))}</td>`
    + `<td>${esc(m.fix)}</td>`
    + `<td>${esc(m.jiraKey || 'draft')}</td></tr>`).join('\n');
  return `<h2>${esc(p.catLabel)} - repeat offenders</h2>
<p><strong>${p.incidents}</strong> incidents across <strong>${p.offenders}</strong> offenders.
Technical hours ${p.tech}, business hours ${p.biz}, currently about <strong>${p.perMonth} hours per month</strong>.${p.saved ? ` Estimated saving if all are fixed: <strong>${p.saved} hours per month</strong>.` : ''}</p>
<table><tbody>
<tr><th>Offender</th><th>Incidents</th><th>Hrs/month</th><th>Common error</th><th>Likely cause</th><th>Fix path</th><th>Jira</th></tr>
${rows}
</tbody></table>
<h2>How this was produced</h2>
<ol>
${howProduced(p).map((s) => `<li>${esc(s)}</li>`).join('\n')}
</ol>
<p><em>Counts come from the incident dump. Causes are hypotheses from the evidence listed in each Jira, not confirmed root cause.</em></p>`;
}

function confluenceStorage(p) {
  return `<ac:structured-macro ac:name="info"><ac:rich-text-body>
<p>Generated ${p.generated} from <code>${esc(p.source)}</code> (${p.total} incidents, ${esc(p.from)} to ${esc(p.to)}).
Hours basis: ${esc(p.basis)}. Evidence: ${esc(p.evidence)}.</p>
</ac:rich-text-body></ac:structured-macro>
${confluenceBody(p)}
`;
}

function confluencePlainHtml(p) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(p.catLabel)} - toil offenders</title>
<style>body{font:14px/1.5 Arial,sans-serif;max-width:1100px;margin:24px auto;color:#1c1c1c}
table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccc;padding:6px 8px;text-align:left;vertical-align:top}
th{background:#f2f2f2}code{font-size:12px}.note{background:#eef3fb;border-left:4px solid #4c7bd9;padding:8px 12px}</style></head><body>
<p class="note">Generated ${p.generated} from <code>${esc(p.source)}</code> (${p.total} incidents, ${esc(p.from)} to ${esc(p.to)}).
Hours basis: ${esc(p.basis)}. Evidence: ${esc(p.evidence)}.</p>
${confluenceBody(p)}
</body></html>
`;
}

// ---------------------------------------------------------------------- main
const a = args(process.argv);
if (!a.run || a.help) {
  console.error('Usage: node render-outputs.mjs --run <run-dir> [--project KEY] [--issue-type Task] [--existing existing_jira.json] [--findings f]');
  process.exit(a.help ? 0 : 1);
}
const run = a.run;
const project = a.project || 'PROJECT';
const issueType = a['issue-type'] || 'Task';
const summary = load(path.join(run, 'summary.json'), {}) || {};
const sel = load(path.join(run, 'selection.json'), {}) || {};
const fpath = a.findings || path.join(run, 'findings.json');
const fdoc = load(fpath);
if (!fdoc) { console.error(`No findings file at ${fpath}. Write findings.json first (schema is in SKILL.md).`); process.exit(1); }
const findings = Array.isArray(fdoc) ? fdoc : (fdoc.findings || []);
if (!findings.length) { console.error('findings.json has no findings.'); process.exit(1); }

// What was actually done (findings.json) beats what was planned (selection.json).
const cfg = {
  lookback_days: fdoc.lookback_days ?? sel.lookback_days ?? '?',
  evidence: fdoc.evidence_source ?? sel.evidence ?? 'none',
  depth: fdoc.depth ?? sel.depth ?? 'quick',
  target: fdoc.target ?? sel.target ?? 'all',
};

// Enrich from clusters (with overrides applied) so counts, windows and hours are the
// pipeline's numbers, not whatever was typed into the finding.
const { clusters, applied } = loadClusters(run);
const byId = new Map(clusters.map((c) => [c.cluster_id, c]));
const empty = (v) => v === undefined || v === null || v === '' || (Array.isArray(v) && !v.length);
const unknownIds = [];
for (const f of findings) {
  const base = byId.get(f.cluster_id);
  if (!base) { unknownIds.push(f.cluster_id); continue; }
  for (const k of ['category_label', 'category_id', 'first_seen', 'last_seen', 'technical_hours', 'business_hours',
    'estimated_hours', 'hours_basis', 'hours_per_month', 'sample_incidents', 'assignment_groups', 'merged_from']) {
    if (empty(f[k]) || f[k] === 0) f[k] = base[k];
  }
  if (!f.count) f.count = base.count;
  if (!f.offender) f.offender = base.offender;
}
if (unknownIds.length) {
  console.error(`WARNING: cluster_id not found in clusters.csv (or dropped by overrides): ${unknownIds.join(', ')}. `
    + 'Those findings render with only what the finding itself contains.');
}

const existing = a.existing ? (load(a.existing, []) || []) : [];
const seen = new Map();
for (const e of existing) for (const lab of e.labels || []) if (lab.startsWith('toil-sig-')) seen.set(lab.slice(9), e);

const jdir = path.join(run, 'drafts', 'jira');
const cdir = path.join(run, 'drafts', 'confluence');
fs.mkdirSync(jdir, { recursive: true });
fs.mkdirSync(cdir, { recursive: true });

const payload = [], dupes = [], toCreate = [], models = [];
for (const f of findings) {
  const dup = seen.get(f.cluster_id);
  if (dup) f.jira_key = dup.key;
  const m = model(f, summary, cfg);
  models.push(m);
  const base = `${m.id}-${slug(m.offender)}`;
  fs.writeFileSync(path.join(jdir, `${base}.md`), jiraMarkdown(m));
  fs.writeFileSync(path.join(jdir, `${base}.jira.txt`), jiraWiki(m));
  const rec = {
    cluster_id: m.id,
    project,
    issue_type: issueType,
    summary: jiraSummary(m),
    labels: m.labels,
    description_markdown: path.join('drafts', 'jira', `${base}.md`),
    description_wiki: path.join('drafts', 'jira', `${base}.jira.txt`),
    duplicate_of: dup ? dup.key : null,
    action: dup ? 'skip-duplicate' : 'create',
  };
  payload.push(rec);
  (dup ? dupes : toCreate).push(rec);
}
fs.writeFileSync(path.join(jdir, 'jira_payload.json'), JSON.stringify(payload, null, 2));

const byCat = new Map();
for (const m of models) {
  if (!byCat.has(m.category)) byCat.set(m.category, []);
  byCat.get(m.category).push(m);
}
const pages = [];
for (const [cat, ms] of byCat) {
  const p = pageModel(cat, ms, summary, cfg);
  const base = path.join(cdir, slug(cat).toLowerCase());
  fs.writeFileSync(`${base}.md`, confluenceMarkdown(p));
  fs.writeFileSync(`${base}.html`, confluencePlainHtml(p));
  fs.writeFileSync(`${base}.storage.html`, confluenceStorage(p));
  pages.push(base);
}

const dash = {
  generated_at: stamp(false),
  source_csv: path.basename(summary.source_csv || ''),
  mode: summary.mode,
  target: cfg.target,
  window: summary.date_range || {},
  observation_days: summary.observation_days,
  total_incidents_in_file: summary.total_incidents,
  hours_basis: summary.hours_basis,
  evidence_source: cfg.evidence,
  depth: cfg.depth,
  categories: (summary.categories || []).map((c) => ({
    category_id: c.category_id, label: c.label, incidents: c.incidents, share_pct: c.share_pct,
    technical_hours: c.technical_hours, business_hours: c.business_hours,
    estimated_hours: c.estimated_hours, hours_per_month: c.hours_per_month, priority_score: c.priority_score,
  })),
  offenders_investigated: models.length,
  incidents_in_scope: models.reduce((s, m) => s + m.count, 0),
  technical_hours_in_scope: round(models.reduce((s, m) => s + m.tech, 0)),
  business_hours_in_scope: round(models.reduce((s, m) => s + m.biz, 0)),
  hours_per_month_in_scope: round(models.reduce((s, m) => s + (m.hrsPerMonth || 0), 0)),
  hours_saved_per_month_if_fixed: round(models.reduce((s, m) => s + (m.estSaved || 0), 0)),
  jira_to_create: toCreate.length,
  jira_duplicates_skipped: dupes.length,
  overrides_applied: applied,
};
fs.writeFileSync(path.join(run, 'dashboard_summary.json'), JSON.stringify(dash, null, 2));

const idx = [`# Drafts - ${stamp()}`, '',
  `- Offenders investigated: ${models.length}  (${dash.incidents_in_scope} incidents, ~${dash.hours_per_month_in_scope} hrs/month in scope)`,
  `- Jira to create: ${toCreate.length}   |   duplicates skipped: ${dupes.length}`,
  `- Estimated hours saved per month if all fixed: ${dash.hours_saved_per_month_if_fixed}`];
if (applied.length) idx.push(`- Overrides applied: ${applied.join('; ')}`);
idx.push('', '## Jira drafts (Markdown + wiki markup for each)', '');
for (const r of payload) {
  idx.push(`- [${r.duplicate_of ? `SKIP (dup of ${r.duplicate_of})` : 'CREATE'}] ${r.summary}  ->  \`${r.description_markdown}\``);
}
idx.push('', '## Confluence drafts (.md / .html preview / .storage.html)', '', ...pages.map((p) => `- \`${p}.*\``));
fs.writeFileSync(path.join(run, 'drafts', 'index.md'), idx.join('\n') + '\n');

console.log(idx.join('\n'));
console.log(`\nDashboard summary: ${path.join(run, 'dashboard_summary.json')}`);
