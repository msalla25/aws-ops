# assets

`sample_incidents_synthetic.csv` — 60 fully synthetic incidents (Control-M, MFT, filesystem,
credential, certificate, plus deliberate uncategorised noise) with ToilLens-style
`toil_score` / `technical_hours` / `business_hours` columns.

Use it to smoke-test the pipeline, to rehearse a demo, or to onboard a team without
touching real incident data. No customer or production data is in this file.
